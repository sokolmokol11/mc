"""
Шаг 3: коробки.
  GET  /api/boxes       — коробки, шансы, счётчики гаранта, таймер бесплатной коробки
  POST /api/boxes/open  — открыть: {"box_id": 0..4, "count": 1 | 10, "free": false}
"""
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import economy as eco
import levels
from config import ADSGRAM_BLOCK_ID, BOXES, FREE_BOX_HOURS
from db import get_db
from deps import telegram_data
from models import BoxOpening, User, UserPity, utcnow
from routers.player import add_cat, get_user, spend, state

router = APIRouter(prefix="/api/boxes", tags=["boxes"])


class OpenRequest(BaseModel):
    box_id: int
    count: int = 1
    free: bool = False


def pity_row(db: Session, user_id: int, box_id: int) -> UserPity:
    row = db.get(UserPity, (user_id, box_id))
    if row is None:
        row = UserPity(user_id=user_id, box_id=box_id, leg_count=0, myth_count=0)
        db.add(row)
    return row


def free_box_in(user: User, now: datetime) -> int:
    """Через сколько секунд снова доступна бесплатная коробка (0 = уже можно)."""
    if user.free_box_at is None:
        return 0
    ready = eco.as_utc(user.free_box_at) + timedelta(hours=FREE_BOX_HOURS)
    return max(0, int((ready - eco.as_utc(now)).total_seconds()))


def boxes_view(db: Session, user: User, now: datetime) -> dict:
    items = []
    for i, (name, price, chances, leg_pity, myth_pity) in enumerate(BOXES):
        row = db.get(UserPity, (user.tg_id, i))
        items.append({
            "id": i, "name": name, "price": price, "chances": eco.box_chances(i, user.tables_level or 1),
            "leg_pity": leg_pity, "myth_pity": myth_pity,
            "leg_count": row.leg_count if row else 0,
            "myth_count": row.myth_count if row else 0,
        })
    return {"boxes": items, "free_box_in": free_box_in(user, now)}


@router.get("")
def list_boxes(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    return {**state(user, now), **boxes_view(db, user, now)}


@router.post("/open")
def open_boxes(req: OpenRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if not 0 <= req.box_id < len(BOXES) or req.count not in (1, 10):
        raise HTTPException(status_code=400, detail="Неверная коробка или количество")
    user = get_user(db, tg)
    now = utcnow()
    if req.free and ADSGRAM_BLOCK_ID:
        raise HTTPException(status_code=400, detail="Бесплатная коробка — за просмотр рекламы")
    results = open_boxes_core(db, user, req.box_id, req.count, req.free, now)
    levels.add(user, "box", req.count)
    db.commit()
    return {"results": results, **state(user, now), **boxes_view(db, user, now)}


def give_box(db: Session, user: User, box, now: datetime) -> list[dict]:
    """Коробка в подарок (серия входов, задания): номер обычной коробки или "leg" — легендарная коробка."""
    if box is None:
        return []
    if box == "leg":
        from config import LEG_BOX_CHANCES
        cat_id = eco.roll_cat(LEG_BOX_CHANCES)
        info = add_cat(db, user, cat_id, now)
        info["was_pity"] = False
        db.add(BoxOpening(user_id=user.tg_id, box_id=-1, cat_id=cat_id, was_pity=False, was_free=True, created_at=now))
        return [info]
    return open_boxes_core(db, user, int(box), 1, False, now, gift=True)


def open_boxes_core(db: Session, user: User, box_id: int, count: int, free: bool, now: datetime,
                    gift: bool = False) -> list[dict]:
    """
    Открыть коробки: проверки, списание, броски с гарантом, журнал. Коммит делает вызывающий.
    gift=True — подарок (промокод): любая коробка бесплатно, без таймера бесплатной коробки.
    """
    if gift:
        cost = 0
    elif free:
        if box_id != 0 or count != 1:
            raise HTTPException(status_code=400, detail="Бесплатной бывает только одна картонная коробка")
        if free_box_in(user, now) > 0:
            raise HTTPException(status_code=400, detail="Бесплатная коробка ещё не готова")
        user.free_box_at = now
        cost = 0
    else:
        cost = BOXES[box_id][1] * count
    spend(db, user, cost, now)

    chances = eco.box_chances(box_id, user.tables_level or 1)
    pity = pity_row(db, user.tg_id, box_id)
    results = []
    for _ in range(count):
        cat_id, pity.leg_count, pity.myth_count, was_pity = eco.open_box_roll(
            box_id, pity.leg_count, pity.myth_count, chances=chances)
        info = add_cat(db, user, cat_id, now)
        info["was_pity"] = was_pity
        results.append(info)
        db.add(BoxOpening(user_id=user.tg_id, box_id=box_id, cat_id=cat_id,
                          was_pity=was_pity, was_free=free or gift, created_at=now))
    return results
