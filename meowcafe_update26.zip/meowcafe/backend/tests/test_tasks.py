"""Тесты заданий: серия ежедневного входа, награды, квесты."""
import sys
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import quests as qs  # noqa: E402
from config import CENTS, DAILY_REWARDS  # noqa: E402


def test_daily_streak_goes_on_and_resets():
    assert qs.daily_next(0, 0, 100) == (1, False)      # первый вход
    assert qs.daily_next(1, 100, 100) == (1, True)     # уже забрал сегодня
    assert qs.daily_next(1, 100, 101) == (2, False)    # пришёл на следующий день
    assert qs.daily_next(3, 100, 102) == (1, False)    # пропустил день — заново
    assert qs.daily_next(7, 100, 101) == (1, False)    # после 7-го снова 1-й
    assert len(DAILY_REWARDS) == 7


def test_day_changes_at_moscow_midnight():
    before = datetime(2026, 10, 17, 20, 59, tzinfo=timezone.utc)  # 23:59 МСК
    after = datetime(2026, 10, 17, 21, 1, tzinfo=timezone.utc)    # 00:01 МСК
    assert qs.day_index(after) == qs.day_index(before) + 1
    assert qs.seconds_to_next_day(before) == 60


def test_reward_has_floor_and_grows_with_income():
    assert qs.scaled_reward(0.5, (1_000, 20)) == 1_000 * CENTS     # новичок получает минимум
    assert qs.scaled_reward(10, (1_000, 20)) == 12_000 * CENTS     # 10/с × 20 мин


def test_quests_progress_and_status():
    cats = [SimpleNamespace(cat_id=i) for i in (0, 1, 4, 8)]  # 4 кота, лучший эпик
    user = SimpleNamespace(cats=cats, barista_cat_id=None, guests_served=3, games_played=0, game_best=0,
                           cash_level=1, bank_level=1, locations_open=1)
    view = {q["id"]: q for q in qs.quests_view(qs.progress_values(user, 12), {"q_box1"}, 1.0)}
    assert view["q_box1"]["status"] == "claimed"
    assert view["q_box10"]["status"] == "ready"
    assert view["q_box50"]["have"] == 12 and view["q_box50"]["status"] == "progress"
    assert view["q_col5"]["have"] == 4
    assert view["q_epic"]["status"] == "ready" and view["q_leg"]["status"] == "progress"
    assert view["q_guest3"]["status"] == "ready"
    assert view["q_barista"]["status"] == "progress"
    assert len(qs.QUEST_IDS) == len(qs.QUESTS)  # id не повторяются


def test_friend_quest_counts_active_friends():
    user = SimpleNamespace(cats=[], barista_cat_id=None, guests_served=0, games_played=0, game_best=0,
                           cash_level=1, bank_level=1, locations_open=1)
    view = {q["id"]: q for q in qs.quests_view(qs.progress_values(user, 0, 1), set(), 1.0)}
    assert view["q_friend1"]["status"] == "ready"
    assert view["q_friend5"]["have"] == 1 and view["q_friend5"]["status"] == "progress"
    assert view["q_friend20"]["box"] == "leg" and view["q_friend20"]["box_name"] == "Легендарная"


def test_daily_boxes_on_3_5_7():
    boxes = [b for _c, b in DAILY_REWARDS]
    assert boxes[2] == 0 and boxes[4] == 2 and boxes[6] == "leg"
    assert qs.scaled_reward(5.0, DAILY_REWARDS[4][0]) == 0   # 5-й день — только коробка
