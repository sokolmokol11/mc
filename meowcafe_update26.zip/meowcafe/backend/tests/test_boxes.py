"""Тесты коробок и гаранта. Запуск из папки backend:  python -m pytest -q"""
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import economy as eco  # noqa: E402
from config import BOXES  # noqa: E402

CARDBOARD, WOOD, SILVER, GOLD, COSMIC = range(5)


def open_many(box_id, n, seed=1):
    rng = random.Random(seed)
    leg = myth = 0
    out = []
    for _ in range(n):
        cat, leg, myth, pity = eco.open_box_roll(box_id, leg, myth, rng)
        out.append((eco.cat_rarity(cat), pity))
    return out


def test_cheap_boxes_have_no_pity_and_no_mythic():
    for box in (CARDBOARD, WOOD):
        res = open_many(box, 20_000)
        assert not any(p for _, p in res)
        assert not any(r == 4 for r, _ in res)


def test_silver_never_mythic():
    assert not any(r == 4 for r, _ in open_many(SILVER, 20_000))


def test_legendary_pity_never_exceeded():
    """Между легендарными (и выше) не больше порога гаранта коробок подряд."""
    for box in (SILVER, GOLD, COSMIC):
        limit = BOXES[box][3]
        gap = longest = 0
        for r, _ in open_many(box, 20_000, seed=box):
            gap = 0 if r >= 3 else gap + 1
            longest = max(longest, gap)
        assert longest < limit, (box, longest, limit)


def test_mythic_pity_never_exceeded():
    for box in (GOLD, COSMIC):
        limit = BOXES[box][4]
        gap = longest = 0
        for r, _ in open_many(box, 30_000, seed=box + 10):
            gap = 0 if r == 4 else gap + 1
            longest = max(longest, gap)
        assert longest < limit, (box, longest, limit)


def test_forced_pity_on_threshold():
    """Счётчик серебряной на 29 — следующая коробка точно легендарная."""
    class AlwaysCommon(random.Random):
        def random(self):
            return 0.0  # всегда самая частая редкость
    cat, leg, myth, pity = eco.open_box_roll(SILVER, 29, 0, AlwaysCommon())
    assert eco.cat_rarity(cat) == 3 and pity and leg == 0


def test_cardboard_chances_close_to_table():
    res = open_many(CARDBOARD, 50_000, seed=3)
    share = [sum(1 for r, _ in res if r == k) / len(res) * 100 for k in range(5)]
    for k, expected in enumerate(BOXES[CARDBOARD][2]):
        assert abs(share[k] - expected) < 1.0


def test_tables_bonus_shifts_to_rare_only():
    base = eco.box_chances(CARDBOARD, 1)
    up = eco.box_chances(CARDBOARD, 6)  # +10 п.п.
    assert base == BOXES[CARDBOARD][2]
    assert abs(sum(up) - 100) < 0.01
    assert abs(up[0] - (base[0] - 10)) < 0.01 and up[1] > base[1] and up[3] > base[3]
    assert up[4] == 0  # мифик из картонной так и не появляется


def test_tables_bonus_capped_and_no_negative():
    up = eco.box_chances(COSMIC, 11)  # +20 п.п., но у редкого в космической всего 12% — берём не больше половины
    assert min(up) >= 0 and abs(sum(up) - 100) < 0.01
    assert abs(up[1] - BOXES[COSMIC][2][1] / 2) < 0.01


def test_upgrade_cost_grows():
    assert eco.upgrade_cost("cash", 1) == 10_000
    assert eco.upgrade_cost("cash", 2) == 22_000
    assert eco.upgrade_cost("cash", 3) > eco.upgrade_cost("cash", 2)
