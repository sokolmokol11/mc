"""
Запуск сервера MeowCafe.
    cd backend
    uvicorn main:app --host 127.0.0.1 --port 8000
API живёт на /api/..., а фронт (папка ../frontend) отдаётся с корня сайта.
"""
import hashlib
import time
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text

from db import SessionLocal, auto_migrate, engine
import models  # noqa: F401  — регистрирует таблицы
from routers import ads, boxes, cafe, friends, game, player, profile, progress, promo, rating, tasks

# Создаём новые таблицы и добавляем новые колонки — старую базу удалять больше не нужно.
_added = auto_migrate()
if _added:
    print("База обновлена, добавлены колонки:", ", ".join(_added))

# Локации стали комнатами (их 4 вместо 5): коты из бывших Пляжа/Космокафе уходят в запас.
with SessionLocal() as _db:
    from sqlalchemy import text as _t
    from config import LOCATIONS as _L
    _db.execute(_t("UPDATE user_cats SET location = NULL WHERE location >= :n"), {"n": len(_L)})
    _db.execute(_t("UPDATE users SET locations_open = :n WHERE locations_open > :n"), {"n": len(_L)})
    _db.commit()

# Сезон создаём при старте, а не на первом запросе — чтобы два процесса не создали два сезона.
with SessionLocal() as _db:
    from routers.rating import current_season
    current_season(_db)

# /docs и /openapi.json наружу не показываем: незачем раздавать карту всех запросов.
app = FastAPI(title="MeowCafe API", docs_url=None, redoc_url=None, openapi_url=None)
app.include_router(player.router)
app.include_router(boxes.router)
app.include_router(cafe.router)
app.include_router(progress.router)
app.include_router(game.router)
app.include_router(tasks.router)
app.include_router(friends.router)
app.include_router(rating.router)
app.include_router(ads.router)
app.include_router(promo.router)
app.include_router(profile.router)


# ---------- ограничение частоты запросов ----------
# Ведро токенов на каждого игрока (по подписи Telegram) или, без подписи, на IP: 6 запросов в секунду, запас 40.
# Обычный игрок до этого никогда не дойдёт, а скрипт, долбящий сервер, получит 429.
RATE, BURST = 6.0, 40.0
_buckets: dict[str, list[float]] = {}


def _client_key(request: Request) -> str:
    auth = request.headers.get("authorization", "")
    if auth:
        return "a" + hashlib.sha1(auth.encode()).hexdigest()
    fwd = request.headers.get("x-forwarded-for", "")
    ip = fwd.split(",")[-1].strip() if fwd else (request.client.host if request.client else "?")
    return "i" + ip


@app.middleware("http")
async def rate_limit(request: Request, call_next):
    if request.url.path.startswith("/api/") and request.url.path != "/api/health":
        now = time.monotonic()
        key = _client_key(request)
        tokens, last = _buckets.get(key, (BURST, now))
        tokens = min(BURST, tokens + (now - last) * RATE)
        if tokens < 1:
            _buckets[key] = [tokens, now]
            return JSONResponse({"detail": "Слишком часто, подожди секунду"}, status_code=429)
        _buckets[key] = [tokens - 1, now]
        if len(_buckets) > 50_000:            # не даём словарю расти бесконечно
            for k in [k for k, (t, l) in _buckets.items() if now - l > 60]:
                _buckets.pop(k, None)
    return await call_next(request)


@app.middleware("http")
async def no_cache_pages(request: Request, call_next):
    """Telegram сильно кэширует страницы. Просим его каждый раз проверять, не вышла ли новая версия."""
    response = await call_next(request)
    p = request.url.path
    if p.startswith(("/music/", "/cats/", "/items/")):
        # музыку и картинки телефон держит у себя сутки — не качает трек заново при каждом входе
        response.headers["Cache-Control"] = "public, max-age=86400"
    elif not p.startswith("/api/"):
        response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


@app.get("/api/health")
def health():
    """Для мониторинга (UptimeRobot): отвечает 200, только если жива и база."""
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
    except Exception as e:  # noqa: BLE001
        return JSONResponse({"ok": False, "error": type(e).__name__}, status_code=503)
    return {"ok": True}


FRONTEND = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
