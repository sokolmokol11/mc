"""
Коллекция игрока: рецепты (новые блюда в меню), декор (встаёт в свои места в комнатах) и воспоминания котов.
Хранится одной JSON-строкой в users.collection: {"rec": {"tea": 2}, "decor": ["monstera"], "mem": {"5": 2}}.
Каждая коробка, кроме кота, кладёт одну такую вещь (или мяуконы).
"""
import json
import random

from config import BOX_EXTRA_COINS, BOX_EXTRA_WEIGHTS, DECOR, DECOR_BONUS, DISH_MAX, DISHES, MEMORY_MAX, RECIPE_BOX
import story


def load(user) -> dict:
    try:
        d = json.loads(user.collection or "{}")
    except ValueError:
        d = {}
    d.setdefault("rec", {}); d.setdefault("decor", []); d.setdefault("mem", {})
    return d


def save(user, d: dict) -> None:
    user.collection = json.dumps(d, separators=(",", ":"))


def dish_levels(user) -> dict[str, int]:
    rec = load(user)["rec"]
    out = {"coffee": 1 if user.dish_coffee is None else user.dish_coffee, "bun": 1 if user.dish_bun is None else user.dish_bun}
    for k in RECIPE_BOX:
        out[k] = int(rec.get(k, 0))
    return out


def decor_bonus(user) -> float:
    return sum(DECOR_BONUS[DECOR[k][2]] for k in load(user)["decor"] if k in DECOR)


def friendship(user, cat_id: int) -> int:
    return int(load(user)["mem"].get(str(cat_id), 0))


def roll_extra(user, box_id: int, box_price: int, rng: random.Random | None = None) -> dict:
    """Что ещё лежит в коробке. Меняет коллекцию игрока; мяуконы возвращает в "coins" — начисляет вызывающий."""
    rng = rng or random
    d = load(user)
    kinds, weights = zip(*BOX_EXTRA_WEIGHTS.items())
    kind = rng.choices(kinds, weights)[0]
    out = None
    if kind == "recipe":
        pool = [k for k, b in RECIPE_BOX.items() if b <= box_id]
        new = [k for k in pool if not d["rec"].get(k)]
        if new:
            k = rng.choice(new); d["rec"][k] = 1
            out = {"kind": "recipe", "key": k, "name": DISHES[k][0], "new": True, "level": 1}
        else:
            ups = [k for k in pool if d["rec"].get(k, 0) < DISH_MAX]
            if ups:
                k = rng.choice(ups); d["rec"][k] += 1
                out = {"kind": "recipe", "key": k, "name": DISHES[k][0], "new": False, "level": d["rec"][k]}
    elif kind == "decor":
        new = [k for k, v in DECOR.items() if v[3] <= box_id and k not in d["decor"]]
        if new:
            k = rng.choice(new); d["decor"].append(k)
            name, room, rar, _ = DECOR[k]
            out = {"kind": "decor", "key": k, "name": name, "room": room, "rarity": rar, "bonus": round(DECOR_BONUS[rar] * 100)}
    elif kind == "memory":
        cats = [c.cat_id for c in user.cats if int(d["mem"].get(str(c.cat_id), 0)) < MEMORY_MAX]
        if cats:
            placed = [c.cat_id for c in user.cats if c.location is not None and c.cat_id in cats]
            cid = rng.choice(placed or cats)
            n = int(d["mem"].get(str(cid), 0)) + 1
            d["mem"][str(cid)] = n
            out = {"kind": "memory", "cat_id": cid, "n": n, "max": MEMORY_MAX, "text": story.memory(cid, n)}
    if out is None:   # нечего дать (всё собрано) — мяуконы
        out = {"kind": "coins", "amount": max(100, int(round(box_price * BOX_EXTRA_COINS, -2)))}
    save(user, d)
    return out


def view(user) -> dict:
    d = load(user)
    return {
        "decor": [{"key": k, "name": v[0], "room": v[1], "rarity": v[2], "bonus": round(DECOR_BONUS[v[2]] * 100), "have": k in d["decor"]}
                  for k, v in DECOR.items()],
        "decor_bonus": round(decor_bonus(user) * 100),
        "mem": {c.cat_id: {"n": int(d["mem"].get(str(c.cat_id), 0)), "max": MEMORY_MAX,
                           "texts": [story.memory(c.cat_id, i) for i in range(1, int(d["mem"].get(str(c.cat_id), 0)) + 1)]}
                for c in user.cats},
        "recipes_left": sum(1 for k in RECIPE_BOX if not d["rec"].get(k)),
    }
