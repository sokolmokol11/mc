"""
Бот MeowCafe.
  /start — приветствие с меню: Играть, Как играть, Сезон и призы, Пригласить друга, Наш канал, Помощь.
           Сообщение закрепляется в чате (старые откреплаются). Само /start больше не удаляем.
  /help  — то же меню.
При запуске бот сам ставит кнопку меню «Играть», команды и описание бота — в BotFather это делать не нужно.
Запуск:  python bot.py   (токен, адрес и прокси берутся из ../backend/.env)

Настройки в backend/.env (все необязательные):
  CHANNEL_URL=https://t.me/твой_канал     — кнопка «Наш канал»
  SUPPORT_URL=https://t.me/твой_ник        — кнопка «Написать в поддержку»
  SEASON_NAME, PRIZE_POOL_USD               — те же, что у сервера
"""
import asyncio
import logging
import os
from html import escape
from pathlib import Path
from urllib.parse import quote

from aiogram import Bot, Dispatcher, F
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import (BotCommand, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, MenuButtonWebApp,
                           Message, WebAppInfo)
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / "backend" / ".env")
BOT_TOKEN = os.environ["BOT_TOKEN"]          # имя переменной, само значение — в .env
WEBAPP_URL = os.environ["WEBAPP_URL"]
PROXY_URL = os.getenv("PROXY_URL", "")       # пусто = без прокси
CHANNEL_URL = os.getenv("CHANNEL_URL", "").strip()
SUPPORT_URL = os.getenv("SUPPORT_URL", "").strip()
SEASON_NAME = os.getenv("SEASON_NAME", "Тестовый сезон")
PRIZE_POOL_USD = float(os.getenv("PRIZE_POOL_USD", "0") or 0)

logging.basicConfig(level=logging.INFO)
dp = Dispatcher()
BOT_NAME = ""   # узнаём при запуске (getMe)

# ---------------- тексты ----------------
WELCOME = (
    "🐱 <b>MeowCafe</b> — неоновое кошачье кафе в киберпанк-городе под дождём.\n\n"
    "Собирай котов из коробок, ставь их за столики — они зарабатывают мяуконы, даже когда ты не в игре. "
    "Развивай кафе, открывай новые локации и соревнуйся с другими игроками в сезоне.\n\n"
    "👇 Жми «Играть» — первый кот уже ждёт тебя."
)

HOW = (
    "📖 <b>Как играть</b>\n\n"
    "1. <b>Коты зарабатывают сами.</b> Каждый кот в кафе приносит мяуконы каждую секунду. "
    "Они копятся в копилке — заходи и жми «Собрать».\n"
    "2. <b>Копилка не бесконечная.</b> Сначала она копит 4 часа, потом останавливается. Улучши её, чтобы копила дольше.\n"
    "3. <b>Коробки.</b> На мяуконы открывай коробки с котами. Чем дороже коробка, тем выше шанс редкого кота. "
    "Повторный кот не пропадает — он повышает уровень и зарабатывает больше.\n"
    "4. <b>Улучшения.</b> Касса — больше дохода, копилка — дольше копит, кофемашина — больше награда в мини-играх, "
    "столики — выше шанс редких котов.\n"
    "5. <b>Локации.</b> Терраса, Крыша, Пляж и Космическое кафе: там коты зарабатывают в 1,5–5 раз больше.\n"
    "6. <b>Гости с заказом.</b> Иногда в кафе приходит гость и просит кота определённой редкости — обслужи его и получи бонус.\n"
    "7. <b>Мини-игра «Десертопад».</b> 30 секунд лови десерты, не трогай камни. Очки превращаются в мяуконы.\n"
    "8. <b>Задания.</b> Ежедневная награда за вход, задания и промокоды из нашего канала."
)


def season_text() -> str:
    prize = (f"Призовой фонд сезона: <b>${PRIZE_POOL_USD:,.0f}</b> — делится между топами трёх рейтингов.\n\n"
             if PRIZE_POOL_USD > 0 else
             "В этом сезоне денежных призов нет, но участники получат эксклюзивную награду.\n\n")
    return (
        f"🏆 <b>{escape(SEASON_NAME)}</b>\n\n"
        "В игре три рейтинга:\n"
        "• <b>Игроки</b> — сколько мяуконов заработал за сезон\n"
        "• <b>Мини-игры</b> — сумма очков в Десертопаде\n"
        "• <b>Друзья</b> — сколько приглашённых стали активными (3 дня в игре и 1 мини-игра)\n\n"
        + prize +
        "⚖️ <b>Честная игра.</b> Боты, фермы аккаунтов и накрутка друзей видны в статистике — такие игроки "
        "убираются из рейтинга и не получают призы. Перед выплатой каждый призёр проверяется вручную."
    )


def invite_text(uid: int) -> str:
    link = invite_link(uid)
    return (
        "👥 <b>Пригласи друга</b>\n\n"
        "Когда друг собирает доход, тебе в «Банк друзей» падает <b>5%</b> от собранного — у друга при этом ничего не отнимается.\n"
        "Друг, который заходил 3 разных дня и сыграл 1 мини-игру, становится <b>активным</b> и засчитывается "
        "в рейтинг «Друзья».\n\n"
        "🎁 За 1, 3, 5, 10 и 20 активных друзей — награды в «Заданиях», за 20 друзей — <b>легендарная коробка</b>.\n\n"
        f"Твоя ссылка:\n<code>{escape(link)}</code>" if link else "Ссылка появится чуть позже — бот ещё запускается."
    )


def help_text() -> str:
    return (
        "❓ <b>Помощь</b>\n\n"
        "<b>Игра не открывается или белый экран.</b> Обнови Telegram и попробуй ещё раз. "
        "На компьютере лучше играть в приложении Telegram Desktop.\n\n"
        "<b>Реклама не показывается.</b> С компьютера рекламы бывает мало — попробуй с телефона.\n\n"
        "<b>Пропали мяуконы или кот.</b> Все покупки и открытия коробок записываются — напиши нам, разберёмся.\n\n"
        + ("Есть вопрос или нашёл баг? Жми кнопку ниже 👇" if SUPPORT_URL else "")
    )


# ---------------- клавиатуры ----------------
def invite_link(uid: int) -> str:
    return f"https://t.me/{BOT_NAME}?startapp=ref_{uid}" if BOT_NAME else ""


def play_button(ref: str = "") -> InlineKeyboardButton:
    # Если человек пришёл по ссылке друга (t.me/бот?start=ref_123), «Играть» открывает игру с той же меткой,
    # чтобы друг засчитался. Иначе — обычная кнопка мини-приложения.
    if ref and BOT_NAME:
        return InlineKeyboardButton(text="🎮 Играть", url=f"https://t.me/{BOT_NAME}?startapp={ref}")
    return InlineKeyboardButton(text="🎮 Играть", web_app=WebAppInfo(url=WEBAPP_URL))


def main_kb(ref: str = "") -> InlineKeyboardMarkup:
    rows = [[play_button(ref)],
            [InlineKeyboardButton(text="📖 Как играть", callback_data="how"),
             InlineKeyboardButton(text="🏆 Сезон и призы", callback_data="season")],
            [InlineKeyboardButton(text="👥 Пригласить друга", callback_data="invite")]]
    if CHANNEL_URL:
        rows[2].append(InlineKeyboardButton(text="📢 Наш канал", url=CHANNEL_URL))
    rows.append([InlineKeyboardButton(text="❓ Помощь", callback_data="help")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back_kb(*extra: list[InlineKeyboardButton]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[*extra, [play_button(), InlineKeyboardButton(text="« Назад", callback_data="menu")]])


# ---------------- обработчики ----------------
@dp.message(CommandStart())
async def start(message: Message, bot: Bot, command: CommandObject):
    ref = command.args if command.args and command.args.startswith("ref_") and command.args[4:].isdigit() else ""
    sent = await message.answer(WELCOME, reply_markup=main_kb(ref), parse_mode="HTML")
    # Чтобы в чате не копились старые меню: открепляем прежние и закрепляем свежее.
    for action in (lambda: bot.unpin_all_chat_messages(message.chat.id),
                   lambda: bot.pin_chat_message(message.chat.id, sent.message_id, disable_notification=True)):
        try:
            await action()
        except Exception as e:  # нет прав — не страшно
            logging.info("skip: %s", e)


@dp.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer(WELCOME, reply_markup=main_kb(), parse_mode="HTML")


async def show(cb: CallbackQuery, text: str, kb: InlineKeyboardMarkup):
    try:
        await cb.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    except Exception as e:  # «message is not modified» при повторном нажатии
        logging.info("edit skip: %s", e)
    await cb.answer()


@dp.callback_query(F.data == "menu")
async def cb_menu(cb: CallbackQuery):
    await show(cb, WELCOME, main_kb())


@dp.callback_query(F.data == "how")
async def cb_how(cb: CallbackQuery):
    await show(cb, HOW, back_kb())


@dp.callback_query(F.data == "season")
async def cb_season(cb: CallbackQuery):
    await show(cb, season_text(), back_kb())


@dp.callback_query(F.data == "invite")
async def cb_invite(cb: CallbackQuery):
    link = invite_link(cb.from_user.id)
    extra = []
    if link:
        share = "https://t.me/share/url?url=" + quote(link) + "&text=" + quote("Заходи в MeowCafe — котики, кафе и призы 🐱")
        extra.append([InlineKeyboardButton(text="📨 Отправить другу", url=share)])
    await show(cb, invite_text(cb.from_user.id), back_kb(*extra))


@dp.callback_query(F.data == "help")
async def cb_help(cb: CallbackQuery):
    extra = [[InlineKeyboardButton(text="✉️ Написать в поддержку", url=SUPPORT_URL)]] if SUPPORT_URL else []
    await show(cb, help_text(), back_kb(*extra))


async def main():
    global BOT_NAME
    session = AiohttpSession(proxy=PROXY_URL) if PROXY_URL else None
    bot = Bot(BOT_TOKEN, session=session)
    # Нет связи с Telegram (умер прокси, сеть) — не падаем, а ждём и пробуем снова:
    # иначе systemd перезапускает бота по кругу и съедает весь процессор.
    delay = 10
    while True:
        try:
            BOT_NAME = (await bot.get_me()).username or ""
            break
        except Exception as e:
            logging.error("Нет связи с Telegram (%s). Проверь PROXY_URL. Повтор через %s с", type(e).__name__, delay)
            await asyncio.sleep(delay)
            delay = min(delay * 2, 300)
    await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(text="Играть", web_app=WebAppInfo(url=WEBAPP_URL)))
    for call in (lambda: bot.set_my_commands(commands=[BotCommand(command="start", description="Главное меню"),
                                              BotCommand(command="help", description="Как играть и помощь")]),
                 lambda: bot.set_my_short_description(short_description="Неоновое кошачье кафе: собирай котов, развивай кафе, выигрывай призы сезона 🐱"),
                 lambda: bot.set_my_description(description="MeowCafe — idle-игра про кошачье кафе в киберпанк-городе. "
                                                "Коты зарабатывают, даже когда тебя нет. Жми «Запустить» 👇")):
        try:
            await call()
        except Exception as e:
            logging.info("bot setup skip: %s", e)
    print("Бот запущен, кнопка меню →", WEBAPP_URL, "| @" + BOT_NAME)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
