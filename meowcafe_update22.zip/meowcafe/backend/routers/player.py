"""
Шаг 2: вход игрока, подарок новичку, коты, доход и копилка.
  POST /api/auth     — вход (новичку: 20K мяуконов + стартовый кот)
  GET  /api/state    — состояние для главного экрана
  POST /api/collect  — забрать копилку
"""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
import re

from sqlalchemy import update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, object_session

import economy as eco
from config import (ACTIVE_CATS, ADS_TEST_MODE, ADSGRAM_BLOCK_ID, BANK_START_HOURS, BOT_TOKEN, CASH_PER_LEVEL, CATS, CENTS, COFFEE_PER_LEVEL, GIFT_CHANCES,
                    GUEST_REWARD_SEC, GUEST_WINDOW_MIN, LOCATIONS, MAX_LEVEL, RARITY_NAMES, REF_ACTIVE_DAYS,
                    REF_ACTIVE_GAMES, REF_SHARE, START_COINS, TABLES_PER_LEVEL, UPGRADE_MAX)
from db import get_db
from deps import telegram_data
from models import User, UserCat, utcnow

router = APIRouter(prefix="/api", tags=["player"])


# ---------- помощники ----------
_BAD_CHARS = re.compile(r"[<>&\"'`\x00-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]")


def clean_name(s: str | None, limit: int) -> str:
    """Имя из Telegram может содержать HTML и «невидимые» символы. Убираем их и обрезаем по длине."""
    return _BAD_CHARS.sub("", s or "").strip()[:limit]


def display_name(u: User) -> str:
    name = clean_name(u.first_name, 32)
    if name:
        return name
    un = clean_name(u.username, 32)
    return "@" + un if un else "Игрок"


def parse_referrer(start_param: str, my_id: int) -> int | None:
    """Ссылка вида t.me/<бот>/<приложение>?startapp=ref_123456 → 123456. Себя пригласить нельзя."""
    if start_param and start_param.startswith("ref_"):
        try:
            ref = int(start_param[4:])
            return ref if ref != my_id else None
        except ValueError:
            return None
    return None


def income_of(user: User) -> float:
    return eco.total_income([(c.cat_id, c.level, c.location) for c in user.cats], user.cash_level)


def collect(user: User, now: datetime) -> int:
    """Переводит копилку на баланс. Возвращает сумму в сотых."""
    got = eco.pending_cents(income_of(user), user.last_collect_at, now, user.bank_level)
    user.coins += got
    user.coins_earned_season += got
    user.last_collect_at = now
    share_with_referrer(user, got)
    return got


def share_with_referrer(user: User, got: int) -> None:
    """
    5% собранного дохода падает в банк пригласившего. У самого игрока ничего не отнимается.
    Одна команда UPDATE с прибавлением — даже если пригласивший в этот момент сам забирает банк, ничего не потеряется.
    """
    share = int(got * REF_SHARE)
    db = object_session(user)
    if not user.referrer_id or share <= 0 or db is None:
        return
    db.execute(update(User).where(User.tg_id == user.referrer_id)
               .values(ref_bank=User.ref_bank + share).execution_options(synchronize_session=False))
    user.ref_given = (user.ref_given or 0) + share


def mark_activity(user: User, now: datetime) -> None:
    """Считаем дни, в которые игрок заходил, и отмечаем «активного друга»: 3 разных дня + 3 игры."""
    import quests as qs  # здесь, чтобы не было круговой зависимости модулей
    today = qs.day_index(now)
    if (user.last_active_day or 0) != today:
        user.days_active = (user.days_active or 0) + 1
        user.last_active_day = today
    if not user.is_active_ref and (user.days_active or 0) >= REF_ACTIVE_DAYS \
            and (user.games_played or 0) >= REF_ACTIVE_GAMES:
        user.is_active_ref = True
        user.ref_active_at = now


def add_cat(db: Session, user: User, cat_id: int, now: datetime) -> dict:
    """Выдать кота. Сначала собираем копилку по СТАРОМУ доходу, иначе новый кот «задним числом» умножит накопленное."""
    collect(user, now)
    existing = next((c for c in user.cats if c.cat_id == cat_id), None)
    if existing:
        was_max = existing.level >= MAX_LEVEL
        existing.level = min(MAX_LEVEL, existing.level + 1)
        return {**eco.cat_info(cat_id), "is_new": False, "level": existing.level, "maxed": was_max}

    user.cats.append(UserCat(cat_id=cat_id, level=1, location=place_new_cat(user, cat_id)))
    db.flush()
    return {**eco.cat_info(cat_id), "is_new": True, "level": 1, "maxed": False}


def location_counts(user: User) -> dict[int, int]:
    counts = {i: 0 for i in range(user.locations_open)}
    for c in user.cats:
        if c.location is not None:
            counts[c.location] = counts.get(c.location, 0) + 1
    return counts


def place_new_cat(user: User, cat_id: int) -> int | None:
    """
    Куда сесть новому коту: в свободное место самой «дорогой» открытой локации.
    Всё занято — встаёт на место самого слабого кота, если он лучше; слабый уходит в запас.
    """
    counts = location_counts(user)
    free = [loc for loc, n in counts.items() if n < LOCATIONS[loc][2]]
    if free:
        return max(free, key=lambda loc: LOCATIONS[loc][3])
    placed = [c for c in user.cats if c.location is not None]
    if not placed:
        return None
    weakest = min(placed, key=lambda c: eco.cat_income(c.cat_id, c.level, 0))
    if eco.cat_income(cat_id, 1, 0) > eco.cat_income(weakest.cat_id, weakest.level, 0):
        loc = weakest.location
        weakest.location = None
        if user.barista_cat_id == weakest.cat_id:
            user.barista_cat_id = None
        return loc
    return None


def spend(db: Session, user: User, cost_coins: int, now: datetime) -> None:
    """
    Списать мяуконы: сначала копилка падает на баланс, потом списание одной командой с проверкой баланса —
    два одновременных запроса не потратят деньги дважды. Не хватает — 400.
    """
    collect(user, now)
    db.flush()
    cost = cost_coins * CENTS
    if cost <= 0:
        return
    res = db.execute(update(User).where(User.tg_id == user.tg_id, User.coins >= cost)
                     .values(coins=User.coins - cost).execution_options(synchronize_session=False))
    if res.rowcount == 0:
        db.rollback()
        raise HTTPException(status_code=400, detail="Не хватает мяуконов")
    db.refresh(user)


UPGRADE_INFO = {
    "cash": ("Касса", "Общий доход всех котов"),
    "bank": ("Копилка", "Сколько часов копится доход"),
    "coffee": ("Кофемашина", "Награда в мини-играх"),
    "tables": ("Столики", "Шанс редких котов в коробках"),
}


def upgrade_effect(kind: str, level: int) -> str:
    if kind == "cash":
        return f"+{round(CASH_PER_LEVEL * 100 * (level - 1))}% к доходу"
    if kind == "bank":
        return f"{BANK_START_HOURS + level - 1} ч накопления"
    if kind == "coffee":
        return f"+{round(COFFEE_PER_LEVEL * 100 * (level - 1))}% к награде"
    return f"+{round(TABLES_PER_LEVEL * 100 * (level - 1))}% к шансу редких котов"


def upgrades_view(user: User) -> list[dict]:
    out = []
    for kind, (name, what) in UPGRADE_INFO.items():
        lvl = getattr(user, f"{kind}_level") or 1
        maxed = lvl >= UPGRADE_MAX[kind]
        out.append({"kind": kind, "name": name, "what": what, "level": lvl, "max": UPGRADE_MAX[kind],
                    "maxed": maxed, "effect": upgrade_effect(kind, lvl),
                    "next_effect": None if maxed else upgrade_effect(kind, lvl + 1),
                    "cost": None if maxed else eco.upgrade_cost(kind, lvl)})
    return out


def locations_view(user: User) -> list[dict]:
    counts = location_counts(user)
    return [{"id": i, "name": name, "price": price, "slots": slots, "mult": mult,
             "open": i < user.locations_open, "next": i == user.locations_open, "count": counts.get(i, 0)}
            for i, (name, price, slots, mult) in enumerate(LOCATIONS)]


def catalog(user: User | None = None) -> list[dict]:
    """Коллекция: коты, которые сейчас есть в игре, плюс те, что уже есть у игрока (если кота убрали из коробок)."""
    ids = set(ACTIVE_CATS) | ({c.cat_id for c in user.cats} if user else set())
    return [eco.cat_info(i) for i in sorted(ids)]


def current_order(user: User, now: datetime) -> dict | None:
    """Гость с заказом в текущем окне, если он есть и ещё не обслужен."""
    w = eco.guest_window(now)
    if w <= (user.last_served_window or 0):
        return None
    want = eco.guest_order(user.tg_id, w, BOT_TOKEN)
    if want is None:
        return None
    window_end = (w + 1) * GUEST_WINDOW_MIN * 60
    best = max((eco.cat_rarity(c.cat_id) for c in user.cats if c.location == 0), default=-1)
    return {
        "key": f"w{w}", "want": want, "want_name": RARITY_NAMES[want],
        "reward": int(income_of(user) * GUEST_REWARD_SEC[want]),
        "expires_in": max(0, int(window_end - eco.as_utc(now).timestamp())),
        "can_serve": best >= want,
    }


def state(user: User, now: datetime) -> dict:
    inc = income_of(user)
    cap = eco.cap_seconds(user.bank_level)
    elapsed = max(0.0, (eco.as_utc(now) - eco.as_utc(user.last_collect_at)).total_seconds())
    cats = []
    for c in sorted(user.cats, key=lambda c: (c.location is None, -eco.cat_income(c.cat_id, c.level, 0))):
        cats.append({**eco.cat_info(c.cat_id), "level": c.level, "location": c.location,
                     "income": round(eco.cat_income(c.cat_id, c.level, c.location), 3)})
    return {
        "id": user.tg_id,
        "name": display_name(user),
        "coins": user.coins / CENTS,
        "income": round(inc, 3),                       # мяуконов в секунду
        "pending": eco.pending_cents(inc, user.last_collect_at, now, user.bank_level) / CENTS,
        "elapsed_sec": int(min(elapsed, cap)),
        "cap_sec": cap,
        "cafe_slots": LOCATIONS[0][2],
        "cats": cats,
        "locations": locations_view(user),
        "upgrades": upgrades_view(user),
        "barista_cat_id": user.barista_cat_id,
        "order": current_order(user, now),
        "ads": {"block_id": ADSGRAM_BLOCK_ID, "test": ADS_TEST_MODE},
        "tutorial_done": bool(user.tutorial_done),
        "avatar": {"cat_id": user.avatar_cat_id if user.avatar_cat_id in {c.cat_id for c in user.cats}
                   else max((c.cat_id for c in user.cats), default=None), "decor": user.avatar_decor or ""},
    }


# ---------- запросы ----------
def get_user(db: Session, tg: dict) -> User:
    """
    Игрок с блокировкой строки до конца запроса (PostgreSQL: SELECT ... FOR UPDATE).
    Два одновременных запроса одного игрока выполняются по очереди — нельзя, например, открыть коробку
    и в ту же миллисекунду «собрать копилку», чтобы сбор перезаписал баланс до покупки.
    """
    user = db.get(User, tg["user"]["id"], with_for_update=True)
    if user is None:  # на /state и /collect без /auth — пусть фронт сначала войдёт
        raise HTTPException(status_code=404, detail="Игрок не найден, сначала /api/auth")
    return user


@router.post("/auth")
def auth(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    u = tg["user"]
    user = db.get(User, u["id"], with_for_update=True)
    now = utcnow()
    gift = None
    username, first_name = clean_name(u.get("username"), 64) or None, clean_name(u.get("first_name"), 128)

    if user is None:
        referrer = parse_referrer(tg.get("start_param", ""), u["id"])
        if referrer is not None and db.get(User, referrer) is None:
            referrer = None
        user = User(tg_id=u["id"], username=username, first_name=first_name,
                    is_premium=bool(u.get("is_premium", False)), referrer_id=referrer,
                    coins=START_COINS, last_collect_at=now, created_at=now, last_seen_at=now)
        db.add(user)
        try:
            db.flush()
        except IntegrityError:          # два первых входа одновременно: второй просто берёт уже созданного
            db.rollback()
            return auth(tg, db)
        gift = add_cat(db, user, eco.roll_cat(GIFT_CHANCES), now)  # подарок новичку
        mark_activity(user, now)
    else:
        user.username = username
        user.first_name = first_name or user.first_name
        user.is_premium = bool(u.get("is_premium", False))
        user.last_seen_at = now
        mark_activity(user, now)

    db.commit()
    from routers.tasks import tasks_view  # здесь, чтобы не было круговой зависимости модулей
    return {**state(user, now), "gift": gift, "catalog": catalog(user), "tasks": tasks_view(db, user, now)}


@router.get("/state")
def get_state(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    return state(get_user(db, tg), utcnow())


@router.post("/collect")
def post_collect(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    got = collect(user, now)
    db.commit()
    return {**state(user, now), "collected": got / CENTS}


@router.post("/tutorial/done")
def tutorial_done(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    """Обучение пройдено или пропущено — больше не показываем (на любом устройстве)."""
    user = get_user(db, tg)
    user.tutorial_done = True
    db.commit()
    return {"ok": True}
