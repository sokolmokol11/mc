"""
Чистая математика экономики: без базы и без FastAPI, поэтому её легко тестировать.
Сервер НЕ «тикает» каждую секунду: он хранит время последнего сбора
и пересчитывает накопленное в момент запроса.
"""
import random
import secrets
from datetime import datetime, timezone

from config import ACTIVE_CATS, BANK_START_HOURS, CATS, CENTS, RARITY_NAMES, UPGRADE_GROWTH, UPGRADES

RNG = secrets.SystemRandom()  # честный генератор, клиент на него не влияет
CATS_PER_RARITY = 4


# ---------- время ----------
def as_utc(dt: datetime) -> datetime:
    """SQLite теряет часовой пояс при сохранении — возвращаем его обратно."""
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


# ---------- коты ----------
def cat_rarity(cat_id: int) -> int:
    return cat_id // CATS_PER_RARITY


def pool(rarity: int) -> list[int]:
    """Коты этой редкости, которые сейчас выпадают. Если в .env забыли редкость — берём всех её котов."""
    ids = [c for c in ACTIVE_CATS if cat_rarity(c) == rarity]
    return ids or [rarity * CATS_PER_RARITY + i for i in range(CATS_PER_RARITY)]


def cat_info(cat_id: int) -> dict:
    r = cat_rarity(cat_id)
    return {"cat_id": cat_id, "name": CATS[r][cat_id % CATS_PER_RARITY], "rarity": r, "rarity_name": RARITY_NAMES[r]}


# ---------- копилка ----------
def cap_seconds(bank_level: int) -> int:
    return (BANK_START_HOURS + bank_level - 1) * 3600


def pending_cents(income_per_sec: float, last_collect_at: datetime, now: datetime, bank_level: int) -> int:
    """Сколько накопилось с последнего сбора (в сотых мяукона), но не больше лимита копилки."""
    elapsed = max(0.0, (as_utc(now) - as_utc(last_collect_at)).total_seconds())
    return int(income_per_sec * min(elapsed, cap_seconds(bank_level)) * CENTS)


# ---------- случайности ----------
def roll_rarity(chances: list[float], rng: random.Random = RNG) -> int:
    x = rng.random() * sum(chances)
    for r, c in enumerate(chances):
        if x < c:
            return r
        x -= c
    return max(r for r, c in enumerate(chances) if c > 0)


# ---------- коробки ----------
def upgrade_cost(kind: str, level: int) -> int:
    """Цена следующего уровня (в мяуконах) для улучшения текущего уровня level."""
    return int(round(UPGRADES[kind] * UPGRADE_GROWTH ** (level - 1), -2))


# ---------- гости с заказами ----------
