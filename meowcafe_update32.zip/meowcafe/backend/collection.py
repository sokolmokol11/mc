"""
Коллекция игрока: открытые рецепты и декор. Одна JSON-строка в users.collection:
{"rec": {"donut": 2}, "decor": ["monstera"]}
Воспоминания котов не хранятся: кот уровня N помнит первые N кусочков своей истории.
"""
import json

from config import DECOR, DECOR_SLOTS, MEMORY_MAX, RECIPES, ROOM_DECOR_SLOTS
import story


def load(user) -> dict:
    try:
        d = json.loads(user.collection or "{}")
    except ValueError:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("rec", {}); d.setdefault("decor", []); d.setdefault("style", {})
    return d


def save(user, d: dict) -> None:
    user.collection = json.dumps(d, separators=(",", ":"))


def dish_levels(user) -> dict[str, int]:
    rec = load(user)["rec"]
    out = {"coffee": 1 if user.dish_coffee is None else user.dish_coffee, "bun": 1 if user.dish_bun is None else user.dish_bun}
    for k in RECIPES:
        out[k] = int(rec.get(k, 0))
    return out


def memories(cat_id: int, level: int) -> dict:
    n = min(MEMORY_MAX, max(1, level))
    return {"n": n, "max": MEMORY_MAX, "texts": [story.memory(cat_id, i) for i in range(1, n + 1)]}


def view(user) -> dict:
    d = load(user)
    return {
        "decor": [{"key": k, "name": v[0], "slot": v[1], "rarity": v[2], "have": k in d["decor"]} for k, v in DECOR.items()],
        "decor_slots": DECOR_SLOTS, "room_slots": {str(r): s for r, s in ROOM_DECOR_SLOTS.items()},
        "style": {r: {sl: k for sl, k in st.items() if k in d["decor"]} for r, st in d["style"].items()},
        "recipes_left": sum(1 for k in RECIPES if not d["rec"].get(k)),
    }
