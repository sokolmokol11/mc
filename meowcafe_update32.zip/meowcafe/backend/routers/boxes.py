"""
Коробка (ядро v2): одна на всю игру.
  GET  /api/boxes       — цена, сколько можно купить сегодня, таймер коробки за рекламу, шансы
  POST /api/boxes/open  — купить и открыть одну коробку

Внутри одна вещь: кот, вкусняшки, рецепт, декор или мяуконы.
Купить можно BOX_DAILY_LIMIT коробок в сутки, ещё одну — раз в сутки за рекламу.
Кот гарантирован хотя бы в каждой BOX_CAT_PITY-й коробке. Коты уникальные: если выпал тот, что уже есть, — вкусняшки.
"""
import random
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import collection
import economy as eco
import levels
from config import (ACTIVE_CATS, ADSGRAM_BLOCK_ID, BOX_CAT_PITY, BOX_COINS_SHARE, BOX_DAILY_LIMIT, BOX_PRICE_MINUTES,
                    BOX_TREATS, BOX_WEIGHTS, BOXES, CENTS, DECOR, DISHES, FREE_BOX_HOURS, LEG_BOX_CHANCES, RARITY_NAMES, RECIPES)
from db import get_db
from deps import telegram_data
from models import BoxOpening, User, utcnow
from routers.player import add_cat, get_user, income_of, spend, state

router = APIRouter(prefix="/api/boxes", tags=["boxes"])
RNG = eco.RNG
KIND_NAMES = {"cat": "Кот", "treats": "Вкусняшки", "recipe": "Рецепт", "decor": "Декор", "coins": "Мяуконы"}


class OpenRequest(BaseModel):
    box_id: int = 0
    count: int = 1
    free: bool = False


def free_box_in(user: User, now: datetime) -> int:
    """Через сколько секунд снова доступна коробка за рекламу (0 = уже можно)."""
    if user.free_box_at is None:
        return 0
    ready = eco.as_utc(user.free_box_at) + timedelta(hours=FREE_BOX_HOURS)
    return max(0, int((ready - eco.as_utc(now)).total_seconds()))


def box_price(user: User, box_id: int = 0) -> int:
    """Цена растёт вместе с доходом: не меньше базовой и не меньше BOX_PRICE_MINUTES минут дохода."""
    return max(BOXES[0][1], int(round(income_of(user) * BOX_PRICE_MINUTES * 60, -2)))


def buys_left(user: User, now: datetime) -> int:
    import quests as qs
    today = qs.day_index(now)
    used = (user.box_buy_count or 0) if (user.box_buy_day or 0) == today else 0
    return max(0, BOX_DAILY_LIMIT - used)


def missing_cats(user: User) -> list[int]:
    have = {c.cat_id for c in user.cats}
    return [c for c in ACTIVE_CATS if c not in have]


def weights(user: User) -> dict[str, float]:
    """Что может выпасть сейчас: рецептов/декора/котов, которых уже нет, не предлагаем."""
    d = collection.load(user)
    w = dict(BOX_WEIGHTS)
    if not [k for k in RECIPES if not d["rec"].get(k)]:
        w["treats"] += w.pop("recipe")
    if not [k for k in DECOR if k not in d["decor"]]:
        w["coins"] += w.pop("decor")
    return w


def boxes_view(db: Session, user: User, now: datetime) -> dict:
    w = weights(user)
    total = sum(w.values())
    left = buys_left(user, now)
    return {
        "box": {"name": BOXES[0][0], "price": box_price(user), "chances": [{"kind": k, "name": KIND_NAMES[k], "pct": round(v * 100 / total)}
                                                                            for k, v in w.items()],
                "cat_rarity": [{"name": RARITY_NAMES[i], "pct": p} for i, p in enumerate(BOXES[0][2]) if p],
                "pity": BOX_CAT_PITY, "pity_left": max(1, BOX_CAT_PITY - (user.box_pity or 0)),
                "cats_left": len(missing_cats(user))},
        "free_box_in": free_box_in(user, now), "buys_left": left, "buys_limit": BOX_DAILY_LIMIT,
        # для старого фронта
        "boxes": [{"id": 0, "name": BOXES[0][0], "price": box_price(user), "chances": BOXES[0][2], "leg_pity": 0, "myth_pity": 0,
                   "leg_count": 0, "myth_count": 0}],
    }


@router.get("")
def list_boxes(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    return {**state(user, now), **boxes_view(db, user, now)}


@router.post("/open")
def open_boxes(req: OpenRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    if req.free:
        raise HTTPException(status_code=400, detail="Бесплатная коробка — за просмотр рекламы")
    results = open_boxes_core(db, user, 0, 1, False, now)
    db.commit()
    return {"results": results, **state(user, now), **boxes_view(db, user, now)}


def give_box(db: Session, user: User, box, now: datetime) -> list[dict]:
    """Коробка в подарок (серия входов, задания, уровни). "leg" — редкая коробка: точно кот, редкость от легендарной."""
    if box is None:
        return []
    if box == "leg":
        return [roll_one(db, user, now, force_cat=True, cat_chances=LEG_BOX_CHANCES, free=True)]
    return open_boxes_core(db, user, 0, 1, False, now, gift=True)


def open_boxes_core(db: Session, user: User, box_id: int, count: int, free: bool, now: datetime,
                    gift: bool = False) -> list[dict]:
    """
    Открыть коробку: проверки, списание, бросок, журнал. Коммит делает вызывающий.
    free=True — за рекламу (раз в FREE_BOX_HOURS), gift=True — подарок (промокод, задание, уровень).
    """
    if gift:
        cost = 0
    elif free:
        if free_box_in(user, now) > 0:
            raise HTTPException(status_code=400, detail="Коробка за рекламу ещё не готова")
        user.free_box_at = now
        cost = 0
    else:
        import quests as qs
        if buys_left(user, now) <= 0:
            raise HTTPException(status_code=400, detail="На сегодня коробки закончились — приходи завтра")
        today = qs.day_index(now)
        if (user.box_buy_day or 0) != today:
            user.box_buy_day, user.box_buy_count = today, 0
        user.box_buy_count = (user.box_buy_count or 0) + 1
        cost = box_price(user)
    spend(db, user, cost, now)
    out = [roll_one(db, user, now, free=free or gift, price=box_price(user)) for _ in range(max(1, min(count, 1)))]
    levels.add(user, "box")
    return out


def roll_one(db: Session, user: User, now: datetime, force_cat: bool = False, cat_chances=None,
             free: bool = False, price: int | None = None, rng: random.Random = RNG) -> dict:
    """Одна вещь из коробки. Возвращает {"kind": ..., ...}; для кота — ещё и данные кота."""
    price = price if price is not None else box_price(user)
    pity_hit = (user.box_pity or 0) + 1 >= BOX_CAT_PITY and missing_cats(user)
    w = weights(user)
    kind = "cat" if (force_cat or pity_hit) else rng.choices(list(w), list(w.values()))[0]
    if kind == "cat" and not missing_cats(user) and not force_cat:
        kind = "treats"
    res: dict
    if kind == "cat":
        missing = missing_cats(user)
        r = eco.roll_rarity(cat_chances or BOXES[0][2], rng)
        pool = [c for c in missing if eco.cat_rarity(c) == r] or missing or ACTIVE_CATS
        cat_id = rng.choice(pool)
        info = add_cat(db, user, cat_id, now)
        res = {"kind": "cat", **info, "was_pity": bool(pity_hit and not force_cat)}
        user.box_pity = 0
    else:
        user.box_pity = (user.box_pity or 0) + 1
        cat_id = -1
        d = collection.load(user)
        if kind == "recipe":
            k = rng.choice([k for k in RECIPES if not d["rec"].get(k)])
            d["rec"][k] = 1
            res = {"kind": "recipe", "key": k, "name": DISHES[k][0], "rarity": 1}
        elif kind == "decor":
            k = rng.choice([k for k in DECOR if k not in d["decor"]])
            d["decor"].append(k)
            name, slot, rar = DECOR[k]
            res = {"kind": "decor", "key": k, "name": name, "slot": slot, "rarity": rar}
        elif kind == "treats":
            n = rng.randint(*BOX_TREATS)
            user.treats = (user.treats or 0) + n
            res = {"kind": "treats", "amount": n, "name": f"{n} вкусняшек", "rarity": 0}
        else:
            amount = max(100, int(round(price * BOX_COINS_SHARE, -2)))
            user.coins += amount * CENTS
            user.coins_earned_season += amount * CENTS
            res = {"kind": "coins", "amount": amount, "name": f"{amount} мяуконов", "rarity": 0}
        collection.save(user, d)
    db.add(BoxOpening(user_id=user.tg_id, box_id=0, cat_id=cat_id, was_pity=bool(res.get("was_pity")),
                      was_free=free, created_at=now))
    return res
