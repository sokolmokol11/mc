"""
Шаг 2: вход игрока, подарок новичку, коты, доход и копилка.
  POST /api/auth     — вход (новичку: 20K мяуконов + стартовый кот)
  GET  /api/state    — состояние для главного экрана
  POST /api/collect  — забрать копилку
"""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
import re

from sqlalchemy import update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, object_session

import economy as eco
import collection
import levels
import service
from config import (CAT_STATS, CORE_VERSION, DUP_TREATS, ROOM_ROLES, START_ROOMS, STAT_KEYS, STAT_NAMES, TREAT_COST)
from config import (ACTIVE_CATS, ADS_TEST_MODE, ADSGRAM_BLOCK_ID, BANK_START_HOURS, CASH_PER_LEVEL, CENTS, LOCATIONS,
                    MAX_LEVEL, REF_ACTIVE_DAYS, REF_ACTIVE_GAMES, REF_SHARE, START_COINS, UPGRADE_MAX)
from db import get_db
from deps import telegram_data
from models import User, UserCat, utcnow

router = APIRouter(prefix="/api", tags=["player"])


# ---------- помощники ----------
_BAD_CHARS = re.compile(r"[<>&\"'`\x00-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]")


def clean_name(s: str | None, limit: int) -> str:
    """Имя из Telegram может содержать HTML и «невидимые» символы. Убираем их и обрезаем по длине."""
    return _BAD_CHARS.sub("", s or "").strip()[:limit]


def display_name(u: User) -> str:
    name = clean_name(u.first_name, 32)
    if name:
        return name
    un = clean_name(u.username, 32)
    return "@" + un if un else "Игрок"


def parse_referrer(start_param: str, my_id: int) -> int | None:
    """Ссылка вида t.me/<бот>/<приложение>?startapp=ref_123456 → 123456. Себя пригласить нельзя."""
    if start_param and start_param.startswith("ref_"):
        try:
            ref = int(start_param[4:])
            return ref if ref != my_id else None
        except ValueError:
            return None
    return None


def cafe_math(user: User) -> dict:
    """Весь расчёт кафе (места, гости, кухня, чек) — см. service.breakdown."""
    return service.breakdown(user, collection.dish_levels(user))


def income_of(user: User) -> float:
    """Доход в секунду: продажи гостям + игровая. Коты сами не зарабатывают — они работают на своих местах."""
    return cafe_math(user)["total"]


def collect(user: User, now: datetime) -> int:
    """Переводит копилку на баланс. Возвращает сумму в сотых."""
    got = eco.pending_cents(income_of(user), user.last_collect_at, now, user.bank_level)
    user.coins += got
    user.coins_earned_season += got
    user.last_collect_at = now
    share_with_referrer(user, got)
    return got


def share_with_referrer(user: User, got: int) -> None:
    """
    5% собранного дохода падает в банк пригласившего. У самого игрока ничего не отнимается.
    Одна команда UPDATE с прибавлением — даже если пригласивший в этот момент сам забирает банк, ничего не потеряется.
    """
    share = int(got * REF_SHARE)
    db = object_session(user)
    if not user.referrer_id or share <= 0 or db is None:
        return
    db.execute(update(User).where(User.tg_id == user.referrer_id)
               .values(ref_bank=User.ref_bank + share).execution_options(synchronize_session=False))
    user.ref_given = (user.ref_given or 0) + share


def mark_activity(user: User, now: datetime) -> None:
    """Считаем дни, в которые игрок заходил, и отмечаем «активного друга»: 3 разных дня + 3 игры."""
    import quests as qs  # здесь, чтобы не было круговой зависимости модулей
    today = qs.day_index(now)
    if (user.last_active_day or 0) != today:
        user.days_active = (user.days_active or 0) + 1
        user.last_active_day = today
    if not user.is_active_ref and (user.days_active or 0) >= REF_ACTIVE_DAYS \
            and (user.games_played or 0) >= REF_ACTIVE_GAMES:
        user.is_active_ref = True
        user.ref_active_at = now


def add_cat(db: Session, user: User, cat_id: int, now: datetime, place: bool = True) -> dict:
    """
    Выдать кота. Коты уникальны: если такой уже есть — вместо него вкусняшки.
    Сначала собираем копилку по СТАРОМУ доходу, иначе новый работник «задним числом» умножит накопленное.
    """
    collect(user, now)
    if any(c.cat_id == cat_id for c in user.cats):
        treats = DUP_TREATS[eco.cat_rarity(cat_id)]
        user.treats = (user.treats or 0) + treats
        return {**eco.cat_info(cat_id), "is_new": False, "level": next(c.level for c in user.cats if c.cat_id == cat_id),
                "maxed": False, "treats": treats}
    room, slot = auto_slot(user, cat_id) if place else (None, None)
    user.cats.append(UserCat(cat_id=cat_id, level=1, location=room, slot=slot))
    db.flush()
    levels.add(user, "newcat")
    return {**eco.cat_info(cat_id), "is_new": True, "level": 1, "maxed": False, "room": room, "slot": slot}


def location_counts(user: User) -> dict[int, int]:
    counts = {i: 0 for i in range(user.locations_open or 2)}
    for c in user.cats:
        if c.location is not None:
            counts[c.location] = counts.get(c.location, 0) + 1
    return counts


def slot_usable(user: User, room: int, slot: int) -> str | None:
    """Почему на это место нельзя поставить кота (None — можно)."""
    if room not in ROOM_ROLES or not 0 <= slot < len(ROOM_ROLES[room]):
        return "Нет такого места"
    if room >= (user.locations_open or 2):
        return f"Сначала открой комнату «{LOCATIONS[room][0]}»"
    t = service.table_of_slot(room, slot)
    if t is not None and service.parse_tables(user.tables)[room][t] <= 0:
        return "Сначала купи этот столик"
    return None


def auto_slot(user: User, cat_id: int) -> tuple[int | None, int | None]:
    """Новый кот сам встаёт на свободное место, где он сильнее всего. Мест нет — в запас."""
    taken = service.placement(user)
    stats = service.cat_stats(cat_id, 1)
    best, best_val = (None, None), -1.0
    for room, roles in ROOM_ROLES.items():
        for slot, role in enumerate(roles):
            if (room, slot) in taken or slot_usable(user, room, slot):
                continue
            if stats[role] > best_val:
                best, best_val = (room, slot), stats[role]
    return best


def spend(db: Session, user: User, cost_coins: int, now: datetime) -> None:
    """
    Списать мяуконы: сначала копилка падает на баланс, потом списание одной командой с проверкой баланса —
    два одновременных запроса не потратят деньги дважды. Не хватает — 400.
    """
    collect(user, now)
    db.flush()
    cost = cost_coins * CENTS
    if cost <= 0:
        return
    res = db.execute(update(User).where(User.tg_id == user.tg_id, User.coins >= cost)
                     .values(coins=User.coins - cost).execution_options(synchronize_session=False))
    if res.rowcount == 0:
        db.rollback()
        raise HTTPException(status_code=400, detail="Не хватает мяуконов")
    db.refresh(user)


UPGRADE_INFO = {
    "cash": ("Касса", "Прибыль с каждой продажи"),
    "bank": ("Копилка", "Сколько часов копится доход"),
}


def upgrade_effect(kind: str, level: int) -> str:
    if kind == "cash":
        return f"+{round(CASH_PER_LEVEL * 100 * (level - 1))}% к продажам"
    return f"{BANK_START_HOURS + level - 1} ч накопления"


def upgrades_view(user: User) -> list[dict]:
    out = []
    for kind, (name, what) in UPGRADE_INFO.items():
        lvl = getattr(user, f"{kind}_level") or 1
        maxed = lvl >= UPGRADE_MAX[kind]
        out.append({"kind": kind, "name": name, "what": what, "level": lvl, "max": UPGRADE_MAX[kind],
                    "maxed": maxed, "effect": upgrade_effect(kind, lvl),
                    "next_effect": None if maxed else upgrade_effect(kind, lvl + 1),
                    "cost": None if maxed else eco.upgrade_cost(kind, lvl)})
    return out


def service_view(user: User, m: dict | None = None) -> dict:
    m = m or cafe_math(user)
    dishes = collection.dish_levels(user)
    eq = m["equip"]
    return {
        "slots": m["slots"],
        "tables": {str(r): [{"level": l, "per_min": round(service.table_rate(l) * 60, 2),
                             "cost": service.table_up_cost(l) if 0 < l < service.TABLE_MAX else None} for l in lv]
                   for r, lv in m["tables"].items()},
        "buy_cost": service.table_buy_cost(m["tables"]), "table_max": service.TABLE_MAX,
        "guests_min": round(m["guests"] * 60, 2), "kitchen_min": round(m["kitchen"] * 60, 2), "check": round(m["check"], 1),
        "cash_mult": round(m["cash_mult"], 2), "sales": round(m["sales"], 3), "play": round(m["play"], 3), "neck": m["neck"],
        "kitchen": {"cats_bonus": round(m["cook_bonus"] * 100), "per_min": round(m["kitchen"] * 60, 2),
                    "equip": [{"key": k, "name": service.EQUIP[k][0], "level": l, "max": service.EQUIP_MAX,
                               "per_min": round(service.equip_rate(k, l) * 60, 2),
                               "next_per_min": round(service.equip_rate(k, max(1, l + 1)) * 60, 2),
                               "cost": service.equip_cost(k, l) if l < service.EQUIP_MAX else None} for k, l in eq.items()]},
        "playroom": {"level": m["play_level"], "max": service.PLAY_MAX, "ticket": round(service.play_ticket(m["play_level"]), 1),
                     "cost": service.play_up_cost(m["play_level"]) if m["play_level"] < service.PLAY_MAX else None},
        "menu": [{"key": key, "name": name, "level": dishes[key], "price": round(service.dish_price(key, max(1, dishes[key])), 1),
                  "next_price": round(service.dish_price(key, dishes[key] + 1), 1), "max": service.DISH_MAX,
                  "cost": service.dish_up_cost(key, dishes[key]) if 0 < dishes[key] < service.DISH_MAX else None}
                 for key, (name, _p) in service.DISHES.items() if dishes.get(key, 0) > 0],
        "menu_locked": [name for key, (name, _p) in service.DISHES.items() if dishes.get(key, 0) <= 0],
        **collection.view(user),
    }


def locations_view(user: User) -> list[dict]:
    counts = location_counts(user)
    lvl = levels.level_of(user.xp or 0)
    return [{"id": i, "name": name, "price": price, "slots": slots, "mult": mult, "need_level": need, "level_ok": lvl >= need,
             "open": i < user.locations_open, "next": i == user.locations_open, "count": counts.get(i, 0)}
            for i, (name, price, slots, mult, need) in enumerate(LOCATIONS)]


def catalog(user: User | None = None) -> list[dict]:
    """Коллекция: коты, которые сейчас есть в игре, плюс те, что уже есть у игрока (если кота убрали из коробок)."""
    ids = set(ACTIVE_CATS) | ({c.cat_id for c in user.cats} if user else set())
    return [eco.cat_info(i) for i in sorted(ids)]


def cat_view(c: UserCat) -> dict:
    lvl = c.level or 1
    return {**eco.cat_info(c.cat_id), "level": lvl, "max_level": MAX_LEVEL, "location": c.location, "slot": c.slot,
            "role": service.role_of(c.location, c.slot) if c.location is not None and c.slot is not None else None,
            "stats": service.cat_stats(c.cat_id, lvl), "base_stats": dict(zip(STAT_KEYS, CAT_STATS.get(c.cat_id, (3, 3, 3, 3)))),
            "feed_cost": TREAT_COST[lvl] if lvl < MAX_LEVEL else None, "memories": collection.memories(c.cat_id, lvl)}


def state(user: User, now: datetime) -> dict:
    m = cafe_math(user)
    inc = m["total"]
    cap = eco.cap_seconds(user.bank_level)
    elapsed = max(0.0, (eco.as_utc(now) - eco.as_utc(user.last_collect_at)).total_seconds())
    place = service.placement(user)
    cashier = place.get((0, 0))
    cats = [cat_view(c) for c in sorted(user.cats, key=lambda c: (c.location is None, c.location or 0, c.slot or 0))]
    return {
        "id": user.tg_id,
        "name": display_name(user),
        "coins": user.coins / CENTS,
        "treats": user.treats or 0,
        "income": round(inc, 3),                       # мяуконов в секунду
        "pending": eco.pending_cents(inc, user.last_collect_at, now, user.bank_level) / CENTS,
        "elapsed_sec": int(min(elapsed, cap)),
        "cap_sec": cap,
        "cafe_slots": LOCATIONS[0][2],
        "cats": cats,
        "stat_names": STAT_NAMES,
        "locations": locations_view(user),
        "upgrades": upgrades_view(user),
        "level": levels.view(user, inc),
        "service": service_view(user, m),
        "barista_cat_id": cashier.cat_id if cashier else None,
        "intro_step": user.intro_step or 0,
        "ads": {"block_id": ADSGRAM_BLOCK_ID, "test": ADS_TEST_MODE},
        "tutorial_done": bool(user.tutorial_done),
        "avatar": {"cat_id": user.avatar_cat_id if user.avatar_cat_id in {c.cat_id for c in user.cats}
                   else max((c.cat_id for c in user.cats), default=None), "decor": user.avatar_decor or ""},
    }


def reset_progress(db: Session, user: User, now: datetime) -> None:
    """Новая экономика (ядро v2): прогресс кафе начинается заново. Друзья, задания и профиль остаются."""
    for c in list(user.cats):
        db.delete(c)
    user.cats.clear()
    db.flush()
    user.coins = START_COINS
    user.coins_earned_season = 0
    user.last_collect_at = now
    user.bank_level = user.cash_level = 1
    user.kitchen_level = user.coffee_level = 1
    user.fridge_level = 0
    user.play_level = 1
    user.tables_level = 1
    user.locations_open = START_ROOMS
    user.tables = service.DEFAULT_TABLES
    user.dish_coffee = user.dish_bun = 1
    user.collection = "{}"
    user.xp, user.level_claimed, user.xp_game_today = 0, 1, 0
    user.treats = 0
    user.box_buy_count = 0
    user.box_pity = 0
    user.free_box_at = None
    user.intro_step = 0
    user.tutorial_done = True          # старое обучение заменила история в начале игры
    user.core_v = CORE_VERSION


# ---------- запросы ----------
def get_user(db: Session, tg: dict) -> User:
    """
    Игрок с блокировкой строки до конца запроса (PostgreSQL: SELECT ... FOR UPDATE).
    Два одновременных запроса одного игрока выполняются по очереди — нельзя, например, открыть коробку
    и в ту же миллисекунду «собрать копилку», чтобы сбор перезаписал баланс до покупки.
    """
    user = db.get(User, tg["user"]["id"], with_for_update=True)
    if user is None:  # на /state и /collect без /auth — пусть фронт сначала войдёт
        raise HTTPException(status_code=404, detail="Игрок не найден, сначала /api/auth")
    if (user.core_v or 0) < CORE_VERSION:
        reset_progress(db, user, utcnow())
    return user


@router.post("/auth")
def auth(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    u = tg["user"]
    user = db.get(User, u["id"], with_for_update=True)
    now = utcnow()
    gift = None
    username, first_name = clean_name(u.get("username"), 64) or None, clean_name(u.get("first_name"), 128)

    if user is None:
        referrer = parse_referrer(tg.get("start_param", ""), u["id"])
        if referrer is not None and db.get(User, referrer) is None:
            referrer = None
        user = User(tg_id=u["id"], username=username, first_name=first_name,
                    is_premium=bool(u.get("is_premium", False)), referrer_id=referrer,
                    coins=START_COINS, last_collect_at=now, created_at=now, last_seen_at=now)
        db.add(user)
        try:
            db.flush()
        except IntegrityError:          # два первых входа одновременно: второй просто берёт уже созданного
            db.rollback()
            return auth(tg, db)
        reset_progress(db, user, now)   # новое кафе: пустое, первого кота игрок найдёт сам
        mark_activity(user, now)
    else:
        if (user.core_v or 0) < CORE_VERSION:
            reset_progress(db, user, now)
        user.username = username
        user.first_name = first_name or user.first_name
        user.is_premium = bool(u.get("is_premium", False))
        user.last_seen_at = now
        mark_activity(user, now)

    db.commit()
    from routers.tasks import tasks_view  # здесь, чтобы не было круговой зависимости модулей
    return {**state(user, now), "gift": gift, "catalog": catalog(user), "tasks": tasks_view(db, user, now)}


@router.get("/state")
def get_state(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    return state(get_user(db, tg), utcnow())


@router.post("/collect")
def post_collect(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    got = collect(user, now)
    db.commit()
    return {**state(user, now), "collected": got / CENTS}


@router.post("/tutorial/done")
def tutorial_done(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    """Обучение пройдено или пропущено — больше не показываем (на любом устройстве)."""
    user = get_user(db, tg)
    user.tutorial_done = True
    db.commit()
    return {"ok": True}
