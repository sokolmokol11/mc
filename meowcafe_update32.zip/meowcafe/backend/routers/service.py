"""
Обслуживание гостей.
  POST /api/tables/buy      — купить столик на свободное место: {"room": 0 | 2, "seat": 0..}
  POST /api/tables/upgrade  — прокачать столик: {"room": 0 | 2, "seat": 0..}
  POST /api/equip/upgrade   — оборудование: {"item": "oven" | "coffee" | "fridge" | "play"}
  POST /api/menu/upgrade    — прокачать блюдо: {"dish": "coffee" | ...}
  POST /api/cats/place      — поставить кота на место: {"cat_id": 4, "room": 0, "slot": 0} (room=null — в запас)
  POST /api/cats/feed       — покормить кота вкусняшками: {"cat_id": 4} → уровень +1
  POST /api/intro/team      — после пролога: Коробкин, Батон и Сосиска сразу в команде
  POST /api/decor/set       — интерьер: {"room": 0, "slot": "wall", "key": "wall_mint" | null}
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import collection
import levels
import service as sv
from config import DECOR, ROOM_DECOR_SLOTS, START_DECOR, INTRO_FIRST_CAT, INTRO_POSTER_CATS, LOCATIONS, MAX_LEVEL, TREAT_COST
from db import get_db
from deps import telegram_data
from models import utcnow
from routers.player import add_cat, collect, get_user, slot_usable, spend, state

router = APIRouter(prefix="/api", tags=["service"])


class SeatRequest(BaseModel):
    room: int
    seat: int


class DishRequest(BaseModel):
    dish: str


def _seat(user, req: SeatRequest):
    tables = sv.parse_tables(user.tables)
    if req.room not in tables or not 0 <= req.seat < len(tables[req.room]):
        raise HTTPException(status_code=400, detail="Нет такого места")
    if req.room >= (user.locations_open or 2):
        raise HTTPException(status_code=400, detail=f"Сначала открой комнату «{LOCATIONS[req.room][0]}»")
    return tables


@router.post("/tables/buy")
def buy_table(req: SeatRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    tables = _seat(user, req)
    if tables[req.room][req.seat] > 0:
        raise HTTPException(status_code=400, detail="Здесь уже стоит столик")
    spend(db, user, sv.table_buy_cost(tables), now)   # spend сначала собирает копилку по старому доходу
    tables[req.room][req.seat] = 1
    user.tables = sv.dump_tables(tables)
    levels.add(user, "table")
    db.commit()
    return state(user, now)


@router.post("/tables/upgrade")
def upgrade_table(req: SeatRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    tables = _seat(user, req)
    lvl = tables[req.room][req.seat]
    if lvl <= 0:
        raise HTTPException(status_code=400, detail="Сначала купи столик")
    if lvl >= sv.TABLE_MAX:
        raise HTTPException(status_code=400, detail="Максимальный уровень")
    spend(db, user, sv.table_up_cost(lvl), now)
    tables[req.room][req.seat] = lvl + 1
    user.tables = sv.dump_tables(tables)
    levels.add(user, "upgrade")
    db.commit()
    return state(user, now)


class EquipRequest(BaseModel):
    item: str


class PlaceRequest(BaseModel):
    cat_id: int
    room: int | None = None
    slot: int | None = None


class CatRequest(BaseModel):
    cat_id: int


@router.post("/equip/upgrade")
def upgrade_equip(req: EquipRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    if req.item == "play":
        if (user.locations_open or 2) < 4:
            raise HTTPException(status_code=400, detail="Сначала открой Игровую")
        lvl = user.play_level or 1
        if lvl >= sv.PLAY_MAX:
            raise HTTPException(status_code=400, detail="Максимальный уровень")
        spend(db, user, sv.play_up_cost(lvl), now)
        user.play_level = lvl + 1
    elif req.item in sv.EQUIP:
        lvl = sv.equip_levels(user)[req.item]
        if lvl >= sv.EQUIP_MAX:
            raise HTTPException(status_code=400, detail="Максимальный уровень")
        spend(db, user, sv.equip_cost(req.item, lvl), now)
        field = {"oven": "kitchen_level", "coffee": "coffee_level", "fridge": "fridge_level"}[req.item]
        setattr(user, field, lvl + 1)
    else:
        raise HTTPException(status_code=400, detail="Нет такого оборудования")
    levels.add(user, "upgrade")
    db.commit()
    return state(user, now)


@router.post("/menu/upgrade")
def upgrade_dish(req: DishRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if req.dish not in sv.DISHES:
        raise HTTPException(status_code=400, detail="Нет такого блюда")
    user = get_user(db, tg)
    now = utcnow()
    lvl = collection.dish_levels(user)[req.dish]
    if lvl <= 0:
        raise HTTPException(status_code=400, detail="Рецепт ещё не открыт")
    if lvl >= sv.DISH_MAX:
        raise HTTPException(status_code=400, detail="Максимальный уровень")
    spend(db, user, sv.dish_up_cost(req.dish, lvl), now)
    if req.dish in ("coffee", "bun"):
        setattr(user, f"dish_{req.dish}", lvl + 1)
    else:
        d = collection.load(user); d["rec"][req.dish] = lvl + 1; collection.save(user, d)
    levels.add(user, "upgrade")
    db.commit()
    return state(user, now)


@router.post("/cats/place")
def place_cat(req: PlaceRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    """Поставить кота на место. Если место занято — коты меняются местами."""
    user = get_user(db, tg)
    now = utcnow()
    cat = next((c for c in user.cats if c.cat_id == req.cat_id), None)
    if cat is None:
        raise HTTPException(status_code=404, detail="У тебя нет такого кота")
    collect(user, now)   # доход меняется — сначала собираем по старому
    if req.room is None:
        cat.location = cat.slot = None
    else:
        why = slot_usable(user, req.room, req.slot if req.slot is not None else -1)
        if why:
            raise HTTPException(status_code=400, detail=why)
        other = next((c for c in user.cats if c.location == req.room and c.slot == req.slot and c is not cat), None)
        if other is not None:
            other.location, other.slot = cat.location, cat.slot
        cat.location, cat.slot = req.room, req.slot
    db.commit()
    return state(user, now)


@router.post("/cats/feed")
def feed_cat(req: CatRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    """Вкусняшки → уровень кота: показатели +15%, опыт кафе, новый кусочек истории."""
    user = get_user(db, tg)
    now = utcnow()
    cat = next((c for c in user.cats if c.cat_id == req.cat_id), None)
    if cat is None:
        raise HTTPException(status_code=404, detail="У тебя нет такого кота")
    lvl = cat.level or 1
    if lvl >= MAX_LEVEL:
        raise HTTPException(status_code=400, detail="Максимальный уровень")
    cost = TREAT_COST[lvl]
    if (user.treats or 0) < cost:
        raise HTTPException(status_code=400, detail="Не хватает вкусняшек")
    collect(user, now)
    user.treats -= cost
    cat.level = lvl + 1
    levels.add(user, "cat")
    db.commit()
    return {**state(user, now), "fed": cat.cat_id, "cat_level": cat.level}


@router.post("/intro/team")
def intro_team(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    """После пролога: объявления уже висят — команда сразу в сборе (Коробкин на кассе, Батон на кухне, Сосиска у столика)."""
    user = get_user(db, tg)
    now = utcnow()
    if (user.intro_step or 0) >= 2:
        raise HTTPException(status_code=400, detail="Команда уже в сборе")
    got = []
    for cid, (room, slot) in [(INTRO_FIRST_CAT, (0, 0))] + list(zip(INTRO_POSTER_CATS, [(1, 0), (0, 1)])):
        info = add_cat(db, user, cid, now, place=False)
        cat = next(c for c in user.cats if c.cat_id == cid)
        if info["is_new"]:
            cat.location, cat.slot = room, slot
        got.append(info)
    d = collection.load(user)
    for k in START_DECOR:
        if k not in d["decor"]:
            d["decor"].append(k)
    d["style"].setdefault("0", {})["art"] = START_DECOR[0]
    collection.save(user, d)
    user.intro_step = 2
    db.commit()
    return {**state(user, now), "new_cats": got}


class DecorRequest(BaseModel):
    room: int
    slot: str
    key: str | None = None


@router.post("/decor/set")
def set_decor(req: DecorRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    """Поставить вещь интерьера в слот комнаты (key=null — вернуть как было)."""
    if req.slot not in ROOM_DECOR_SLOTS.get(req.room, []):
        raise HTTPException(status_code=400, detail="В этой комнате такого места нет")
    user = get_user(db, tg)
    d = collection.load(user)
    if req.key is not None:
        if req.key not in DECOR or DECOR[req.key][1] != req.slot:
            raise HTTPException(status_code=400, detail="Эта вещь сюда не подходит")
        if req.key not in d["decor"]:
            raise HTTPException(status_code=400, detail="Этой вещи у тебя ещё нет")
    st = d["style"].setdefault(str(req.room), {})
    if req.key is None:
        st.pop(req.slot, None)
    else:
        st[req.slot] = req.key
    collection.save(user, d)
    db.commit()
    return state(user, utcnow())
