// MeowCafe: весь код интерфейса. Загружается с defer — после того, как заставка уже нарисована.
    const tg = window.Telegram ? window.Telegram.WebApp : null;
    if (tg) { tg.ready(); tg.expand(); }
    // initData: сначала из Telegram, потом из адреса (#tgWebAppData=...), потом из сохранённого в этой вкладке.
    // Telegram Desktop иногда не отдаёт его через WebApp (после перезагрузки страницы или из кэша).
    function findInitData() {
      if (tg && tg.initData) return tg.initData;
      try {
        const h = new URLSearchParams(location.hash.slice(1)).get("tgWebAppData");
        if (h) return h;
      } catch (e) {}
      try { return sessionStorage.getItem("mc_init") || ""; } catch (e) { return ""; }
    }
    const initData = findInitData() || "dev";
    if (initData !== "dev") { try { sessionStorage.setItem("mc_init", initData); } catch (e) {} }
    const COLORS = ["#B7C0D6", "#5EC8FF", "#B388FF", "#FFB74D", "#FF5CA8"];
    const RARITY = ["Обычный", "Редкий", "Эпический", "Легендарный", "Мифический"];
    const BOX_LOOK = [
      { light: "#E2B98A", base: "#C89B6A", dark: "#9E7448", ribbon: "#8A5A33" },
      { light: "#C08A5E", base: "#9A6640", dark: "#74482A", ribbon: "#FFC94D" },
      { light: "#E8EEF7", base: "#C2CCDC", dark: "#8F9AB0", ribbon: "#5EC8FF" },
      { light: "#FFE08A", base: "#FFC94D", dark: "#D49A1E", ribbon: "#FF5CA8" },
      { light: "#B6F6FF", base: "#5EE7FF", dark: "#2AA9C4", ribbon: "#FF5CA8" },
    ];

    let S = null, loadedAt = 0;    // состояние игрока
    let B = null, boxesAt = 0;     // коробки
    let view = "cafe", sel = 0, lastOpen = null, busy = false;
    let curLoc = 0, CATALOG = [], catsTab = "mine";
    let T = null, showDone = false;   // задания
    let F = null, Fat = 0;            // друзья
    const LOC_LOOK = [{ sign: ["MEOW", "CAFE"] }, { sign: ["MEOW", "KITCHEN"] }, { sign: ["MEOW", "HALL"] }, { sign: ["MEOW", "PLAY"] }];
    // На экране комнаты идут так: Кухня ← Кафе → Зал → Игровая (номера — как на сервере: 0 Кафе, 1 Кухня, 2 Зал, 3 Игровая)
    const ROOM_ORDER = [1, 0, 2, 3];

    async function api(method, path, body) {
      const res = await fetch(path, {
        method, headers: { "Authorization": "tma " + initData, "Content-Type": "application/json" },
        body: body ? JSON.stringify(body) : undefined,
      });
      const data = await res.json().catch(() => ({ detail: "сервер недоступен (" + res.status + ")" }));
      if (!res.ok) throw new Error(data.detail || res.status);
      if (data.tasks) { T = data.tasks; setBadge(); }
      else if (method === "POST") pingTasks();   // действие могло выполнить квест — обновим значок «Задания»
      return data;
    }
    let pingTimer = null;
    function pingTasks() {
      clearTimeout(pingTimer);
      pingTimer = setTimeout(() => fetch("/api/tasks", { headers: { "Authorization": "tma " + initData } })
        .then(r => r.ok ? r.json() : null).then(d => { if (d && d.tasks) { T = d.tasks; setBadge(); if (view === "tasks") render(); } }).catch(() => {}), 1500);
    }

    function fmt(n) {
      n = Math.floor(n);
      const cut = (x, d) => x.toFixed(d).replace(".", ",").replace(/,0$/, "");
      if (n >= 1e6) return cut(n / 1e6, n >= 1e7 ? 0 : 1) + "M";
      if (n >= 1e4) return cut(n / 1e3, n >= 1e5 ? 0 : 1) + "K";
      return n.toLocaleString("ru-RU");
    }
    const dec = (x) => String(Math.round(x * 100) / 100).replace(".", ",");
    const d1 = (x) => String(Math.round(x * 10) / 10).replace(".", ",");
    const hm = (s) => Math.floor(s / 3600) + "ч " + String(Math.floor(s % 3600 / 60)).padStart(2, "0") + "м";
    const hms = (s) => Math.floor(s / 3600) + ":" + String(Math.floor(s % 3600 / 60)).padStart(2, "0") + ":" + String(Math.floor(s % 60)).padStart(2, "0");

    function catSvg(color, size) {
      return `<svg width="${size}" height="${size * 0.9}" viewBox="0 0 62 56" aria-hidden="true">
        <path d="M10 26 L8 4 L24 16 Z" fill="${color}"/><path d="M52 26 L54 4 L38 16 Z" fill="${color}"/>
        <ellipse cx="31" cy="32" rx="23" ry="21" fill="${color}"/>
        <circle cx="22" cy="30" r="3.5" fill="#140F2A"/><circle cx="40" cy="30" r="3.5" fill="#140F2A"/>
        <path d="M27 39 Q31 43 35 39" fill="none" stroke="#140F2A" stroke-width="2.4" stroke-linecap="round"/></svg>`;
    }
    function boxSvg(i, size) {
      const id = "bx" + Math.random().toString(36).slice(2, 7);
      return `<svg width="${size}" height="${size}" viewBox="0 0 120 120" aria-hidden="true" style="overflow:visible">
        <defs><linearGradient id="${id}t" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#F3D3A2"/><stop offset="1" stop-color="#E2B47A"/></linearGradient>
          <linearGradient id="${id}l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#D9A464"/><stop offset="1" stop-color="#B98549"/></linearGradient>
          <linearGradient id="${id}r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#B98243"/><stop offset="1" stop-color="#946332"/></linearGradient>
          <radialGradient id="${id}g" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#21E6FF" stop-opacity=".9"/><stop offset="1" stop-color="#21E6FF" stop-opacity="0"/></radialGradient></defs>
        <ellipse cx="60" cy="110" rx="46" ry="7" fill="#000" opacity=".28"/>
        <polygon points="14,40 60,60 60,108 14,88" fill="url(#${id}l)"/><polygon points="60,60 106,40 106,88 60,108" fill="url(#${id}r)"/>
        <polygon points="60,20 106,40 60,60 14,40" fill="url(#${id}t)"/>
        <polygon points="14,40 60,60 60,63 14,43" fill="#000" opacity=".12"/>
        <path d="M60 20 L60 60" stroke="#21E6FF" stroke-width="1.6" opacity=".9"/><ellipse cx="60" cy="40" rx="10" ry="22" fill="url(#${id}g)" opacity=".55"/>
        <polygon points="40,29 49,25 80,51 71,55" fill="#FF5CA8"/><polygon points="71,55 80,51 80,99 71,103" fill="#E04A92"/>
        ${[0, 1, 2].map(k => `<g transform="translate(${46 + k * 9.5} ${30 + k * 8.2}) rotate(24)" fill="#FFE3F0"><circle r="1.6"/><circle cx="-2.4" cy="-2.6" r=".9"/><circle cx="0" cy="-3.4" r=".9"/><circle cx="2.4" cy="-2.6" r=".9"/></g>`).join("")}
        <polygon points="14,40 18,30 25,37" fill="#E2B47A"/><polygon points="106,40 102,30 95,37" fill="#C99558"/>
        <g transform="translate(36 76) skewY(24)"><path d="M-10 4 L-10 -8 L-5 -3 L5 -3 L10 -8 L10 4 Q10 12 0 12 Q-10 12 -10 4 Z" fill="#6B4226"/>
          <circle cx="-4" cy="3" r="1.8" fill="#FFD23F"/><circle cx="4" cy="3" r="1.8" fill="#FFD23F"/>
          <text x="0" y="22" text-anchor="middle" font-size="7" font-weight="900" fill="#6B4226" font-family="system-ui,sans-serif">MEOW</text></g>
        <g transform="translate(90 68) skewY(-24)" fill="#6B4226" opacity=".75"><path d="M-4 0 l4 -5 l4 5 M0 -5 v10"/><path d="M-4 0 l4 -5 l4 5" stroke="#6B4226" stroke-width="1.6" fill="none"/><path d="M0 -4 v10" stroke="#6B4226" stroke-width="1.6"/>
          <text x="0" y="16" text-anchor="middle" font-size="5" font-weight="800" font-family="system-ui,sans-serif">FRAGILE</text></g></svg>`;
    }
    // ---- «?» — короткая справка на каждом экране ----
    const HELP = {
      cafe: ["Как работает кафе", [
        "🐱 Кафе работает руками котов. У каждого места своя работа: касса, столики, плита, игровая.",
        "🪑 Столик приводит гостей, только если за ним стоит кот-официант. Кухне нужен хотя бы один повар, а без кассира продаж нет.",
        "📊 У каждого кота 4 навыка: официант, повар, кассир, игрок. Ставь кота туда, где он сильнее, — тап по пустому месту или по коту.",
        "🍳 Гостей больше, чем успевает кухня? Прокачай печь и кофемашину в «Меню». Кухня простаивает — купи столик.",
        "🐷 Доход копится в копилке до предела, потом останавливается — заходи и жми «Собрать».",
        "‹ › Комнаты: слева кухня, справа доп. зал и игровая. Они открываются с уровнем кафе."]],
      boxes: ["Коробка", [
        "📦 В коробке одна вещь: кот, вкусняшки, рецепт, декор или мяуконы.",
        "🐱 Кот гарантирован хотя бы в каждой 5-й коробке. Коты не повторяются: если такой уже есть — вместо него вкусняшки.",
        "🛒 Купить можно 3 коробки в день, ещё одну — раз в сутки за рекламу. Цена растёт вместе с доходом."]],
      cats: ["Коты", [
        "Каждый кот уникален: у него своя история и 4 навыка — официант, повар, кассир, игрок.",
        "🍬 Вкусняшки поднимают уровень кота: все навыки +15%, кафе получает опыт, а кот вспоминает новый кусочек своей истории.",
        "Вкусняшки дают коробки и Десертопад. Силуэты в коллекции — коты, которых ещё нет."]],
      games: ["Мини-игры", [
        "🍰 Десертопад: 30 секунд лови десерты, камни отнимают очки.",
        "⚡ 3 попытки, новая — каждые 3 часа. Ещё одну можно получить за рекламу.",
        "💰 1 очко = 15 секунд дохода кафе, а каждые 8 очков — вкусняшка для котов (до 10 за игру).",
        "🏆 Очки идут в рейтинг «Мини-игры»."]],
      tasks: ["Задания", [
        "📅 Заходи каждый день — награда растёт к 7-му дню. Пропустил день — серия начинается заново.",
        "✅ Задания выполняются сами, когда ты дошёл до цели. Осталось нажать «Забрать».",
        "🎟 Промокоды публикуем в нашем канале."]],
      friends: ["Друзья", [
        "🔗 Отправь другу свою ссылку.",
        "💸 Когда друг собирает доход, тебе в банк падает 5% — у него ничего не отнимается. Забирай банк целиком, когда хочешь.",
        "⭐ Активный друг — заходил 3 разных дня и сыграл 1 мини-игру. Только такие идут в рейтинг «Друзья».",
        "🚫 Фейковые аккаунты и боты видны в статистике — их убираем из рейтинга."]],
      rating: ["Рейтинг", [
        "👑 Игроки — сколько мяуконов заработал за сезон.",
        "🎮 Мини-игры — сумма очков в Десертопаде.",
        "👥 Друзья — сколько активных друзей пригласил.",
        "Рейтинг обновляется раз в минуту. Читеры и фермы убираются из рейтинга."]],
    };
    function helpBtn(key) { return `<button class="helpq" onclick="event.stopPropagation();showHelp('${key}')" aria-label="Справка">?</button>`; }
    function showHelp(key) {
      const [title, lines] = HELP[key], m = document.getElementById("modal");
      m.innerHTML = `<div class="dialog helpdlg"><b style="font-size:20px">${title}</b>
        <div class="helplist">${lines.map(l => `<div>${l}</div>`).join("")}</div>
        <button class="main" onclick="closeModal()">Понятно</button>
        ${key === "cafe" && window.Prolog ? `<button class="ghost" style="min-height:40px;border:none;background:none;color:var(--muted)" onclick="watchProlog()">🎬 Посмотреть пролог ещё раз</button>` : ""}</div>`;
      m.classList.add("on");
    }

    function header(title) {
      const a = S.avatar || {};
      return `<div class="top">
        <div class="wallet"><div class="coins"><span class="coin"></span><span id="coins">${fmt(S.coins)}</span></div>
             <div class="inc"><svg width="11" height="11" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2 4 14h7l-1 8 9-12h-7z" fill="#FFC94D"/></svg>+${dec(S.income)} / сек <span class="treats" title="Вкусняшки">🍬 ${S.treats || 0}</span></div></div>
        <div class="hright">
          ${levelBadge()}
          <button class="cup ${view === "rating" ? "on" : ""}" onclick="go('rating')" aria-label="Рейтинг сезона">${CUP}</button>
          <button class="avabtn" onclick="go('profile')" aria-label="Профиль">${a.cat_id != null ? avatarHtml(a.cat_id, a.decor, 50) : ""}</button></div></div>
        ${title ? `<div class="ptitle">${title}${HELP[view] ? helpBtn(view) : ""}</div>` : ""}`;
    }

    // ---------- Кафе ----------
    function renderCafe() {
      const storage = S.cats.filter(c => c.location === null);
      const L = S.locations[curLoc];
      return header() + `
        <div class="bankcard" id="bank" onclick="openUpgrades('bank')">
          <div class="pig">${piggySvg(tierOf("bank"))}</div>
          <div class="bc">
            <div class="row"><b id="bankTitle">Копилка</b><span id="bankTime"></span></div>
            <div class="bbar"><div id="bankBar"></div></div>
            <div class="row" style="align-items:baseline"><span style="color:var(--muted)">Накопилось</span><b id="bankSum"></b></div>
          </div>
          <button class="bkcollect" id="collectBtn" onclick="event.stopPropagation(); doCollect()">Собрать</button>
        </div>
        ${flowHtml()}
        <div id="roomSlot"></div>
        <div class="locbar2">
          <button class="arr" onclick="switchLoc(-1)" aria-label="Комната слева" ${ROOM_ORDER.indexOf(curLoc) === 0 ? "disabled" : ""}>‹</button>
          <div class="mid"><b>${L.name}</b><div class="dots">${ROOM_ORDER.map(i => `<i class="${i === curLoc ? "on" : ""}"></i>`).join("")}</div></div>
          <button class="arr" onclick="switchLoc(1)" aria-label="Комната справа" ${ROOM_ORDER.indexOf(curLoc) === ROOM_ORDER.length - 1 ? "disabled" : ""}>›</button>
          <button class="ib" onclick="openMenu()" aria-label="Меню"><span>📜</span><small>Меню</small></button>
          <button class="ib" onclick="openInterior()" aria-label="Интерьер"><span>🛋</span><small>Интерьер</small></button>
          <button class="ib" onclick="openCity()" aria-label="Карта города"><span>🗺</span><small>Карта</small></button>
          <button class="ib" onclick="showHelp('cafe')" aria-label="Справка"><span>❔</span><small>Помощь</small></button>
        </div>`;
    }
    // Комната занимает всё свободное место: всё до кнопок видно без прокрутки
    function fitRoom() {
      if (!roomEl || view !== "cafe") return;
      const app = document.getElementById("app"), nav = document.getElementById("nav");
      const cur = roomEl.offsetHeight, spare = innerHeight - (app.scrollHeight - 96) - (nav ? nav.offsetHeight + 12 : 0);
      const h = Math.max(300, Math.min(540, Math.round(cur + spare)));
      if (Math.abs(h - cur) > 2) { roomEl.style.height = h + "px"; requestAnimationFrame(fitCityWindow); }
    }
    addEventListener("resize", () => fitRoom());

    // ---------- Интерьер: выбор вещей для слотов текущей комнаты ----------
    function openInterior() {
      const sv = S.service, room = curLoc, L = S.locations[room], body = document.getElementById("sheetBody");
      const slots = sv.room_slots[String(room)] || [];
      const RC = ["#B7C0D6", "#5EC8FF", "#B388FF"];
      body.innerHTML = `<div class="row" style="align-items:center"><h3>Интерьер · ${L.name}</h3>
          <button onclick="closeSheet()" aria-label="Закрыть" style="width:44px;height:44px;border-radius:12px;border:none;background:#241D45;color:var(--text);font-size:18px">×</button></div>
        <div style="font-size:12.5px;color:var(--muted)">Вещи для интерьера выпадают из коробки. Только для красоты — меняй сколько хочешь.</div>
        ${slots.map(slot => {
          const items = sv.decor.filter(d => d.slot === slot), mine = items.filter(d => d.have), cur = styleOf(room, slot);
          return `<div class="islot"><b>${sv.decor_slots[slot]}</b><div class="ichips">
            <button class="${!cur ? "on" : ""}" onclick="setDecor(${room},'${slot}',null)">Обычные</button>
            ${mine.map(d => `<button class="${cur === d.key ? "on" : ""}" style="--rc:${RC[d.rarity]}" onclick="setDecor(${room},'${slot}','${d.key}')">${d.name}</button>`).join("")}
            ${items.length - mine.length ? `<span class="ilock">ещё ${items.length - mine.length} в коробках</span>` : ""}</div></div>`;
        }).join("")}`;
      document.getElementById("sheet").classList.add("on");
    }
    async function setDecor(room, slot, key) {
      if (busy) return; busy = true;
      try { const d = await api("POST", "/api/decor/set", { room, slot, key }); S = d; loadedAt = Date.now(); render(); openInterior(); }
      catch (e) { toast(e.message); }
      finally { busy = false; }
    }

    // ---------- Панель «откуда доход»: гости и кухня → обслужено → × чек = доход ----------
    function flowHtml() {
      const sv = S.service; if (!sv) return "";
      const n = sv.neck, served = Math.min(sv.guests_min, sv.kitchen_min);
      const pct = (v) => Math.round(v / Math.max(sv.guests_min, sv.kitchen_min, .01) * 100);
      const warn = { cashier: "нет кассира", cook: "нет повара", waiter: "нет официанта" }[n];
      return `<button class="flow" id="flow" onclick="openIncome()" aria-label="Откуда доход">
        <div class="fcol"><div class="frow ${n === "guests" ? "neck" : ""}"><span class="fi">🚶</span><span class="fl">Гости</span><span class="fb"><i style="width:${pct(sv.guests_min)}%"></i></span><b>${dec(sv.guests_min)}<small>/мин</small></b></div>
          <div class="frow ${n === "kitchen" ? "neck" : ""}"><span class="fi">🍳</span><span class="fl">Кухня</span><span class="fb k"><i style="width:${pct(sv.kitchen_min)}%"></i></span><b>${dec(sv.kitchen_min)}<small>/мин</small></b></div></div>
        <div class="fx">×</div>
        <div class="fbox"><small>чек</small><b>${fmt(sv.check)}</b></div>
        <div class="fx">=</div>
        <div class="fbox gold ${warn ? "bad" : ""}"><small>${warn || "доход"}</small><b>+${dec(S.income)}</b><small>/сек</small></div></button>`;
    }
    function openIncome(first) {
      const sv = S.service, m = document.getElementById("modal");
      const served = Math.min(sv.guests_min, sv.kitchen_min);
      const tables = svcSlots().filter(s => s.role === "wait" && s.table_level > 0);
      const cashier = S.cats.find(c => c.cat_id === S.barista_cat_id);
      m.innerHTML = `<div class="dialog incdlg"><b style="font-size:19px">${first ? "Как зарабатывает кафе" : "Откуда доход"}</b>
        <div class="istep"><span class="in">1</span><div><b>Гости приходят к столикам</b>
          ${tables.map(s => { const c = s.cat_id != null ? catById(s.cat_id) : null; return `<div class="isub">${slotName(s.room, s.slot)} · ${c ? "🍽 " + c.name : "<i>нет официанта</i>"}<span>${dec(s.per_min)}/мин</span></div>`; }).join("")}
          <div class="isum">Всего: <b>${dec(sv.guests_min)}</b> гостя в минуту</div></div></div>
        <div class="istep"><span class="in">2</span><div><b>Кухня готовит заказы</b>
          ${sv.kitchen.equip.filter(e => e.level).map(e => `<div class="isub">${e.name} ур. ${e.level}<span>${dec(e.per_min)}/мин</span></div>`).join("")}
          <div class="isub">Повара на кухне<span>+${sv.kitchen.cats_bonus}%</span></div>
          <div class="isum">Всего: <b>${dec(sv.kitchen_min)}</b> заказа в минуту</div></div></div>
        <div class="istep hl"><span class="in">3</span><div><b>Обслужено — меньшее из двух: ${dec(served)}/мин</b>
          <div class="isub" style="display:block">${sv.neck === "kitchen" ? "Кухня не успевает — лишние гости уходят. Прокачай печь и кофемашину или поставь второго повара." : sv.neck === "guests" ? "Кухня простаивает — гостей мало. Купи столик и поставь к нему официанта." : sv.neck === "ok" ? "Кухня и зал в балансе — отлично!" : neckText()}</div></div></div>
        <div class="istep"><span class="in">4</span><div><b>Каждый гость платит средний чек: ${fmt(sv.check)}</b><div class="isub" style="display:block">Он растёт от числа блюд в меню и уровня рецептов.</div></div></div>
        <div class="istep"><span class="in">5</span><div><b>Касса ×${dec(sv.cash_mult)}</b><div class="isub" style="display:block">${cashier ? "Кассир " + cashier.name + " (💰 " + d1(cashier.stats.cash) + ") и уровень кассы." : "Без кассира продаж нет!"}</div></div></div>
        <div class="iform">${dec(served)} гостя/мин × ${fmt(sv.check)} × ${dec(sv.cash_mult)} ÷ 60 = <b>+${dec(sv.sales)}/сек</b>${sv.play ? `<br>+ игровая <b>${dec(sv.play)}/сек</b>` : ""}</div>
        <button class="main" onclick="closeModal()">${first ? "Понятно, работаем!" : "Понятно"}</button></div>`;
      m.classList.add("on");
    }

    // ---------- Коробки ----------
    const KIND_ICO = { cat: "🐱", treats: "🍬", recipe: "📜", decor: "🛋", coins: "🪙" };
    function renderBoxes() {
      if (!B || !B.box) return header("Коробка") + `<div class="err" style="color:var(--muted)">Загрузка…</div>`;
      const box = B.box, freeLeft = Math.max(0, B.free_box_in - (Date.now() - boxesAt) / 1000);
      const maxP = Math.max(...box.chances.map(c => c.pct));
      return header("Коробка") + `
        <div class="hero"><div class="float" style="filter:drop-shadow(0 0 26px rgba(255,92,168,.45))">${boxSvg(0, 160)}</div></div>
        <div class="panel"><div class="row" style="color:var(--muted)"><span>Что внутри</span><span>шанс</span></div>
          ${box.chances.map(c => `<div class="chance"><span style="font-weight:700">${KIND_ICO[c.kind]} ${c.name}</span>
            <div class="bar"><div style="width:${c.pct / maxP * 100}%;background:var(--pink)"></div></div><b style="text-align:right">${c.pct}%</b><span></span></div>`).join("")}
          <div style="font-size:12px;color:var(--muted);line-height:1.45">Кот: ${box.cat_rarity.map(r => r.name.toLowerCase() + " " + r.pct + "%").join(" · ")}. Ещё не найдено котов: <b style="color:var(--text)">${box.cats_left}</b>.</div></div>
        <div class="panel"><div class="row"><b style="color:var(--pink)">Кот гарантирован</b><span style="color:var(--muted)">не позже чем через ${box.pity_left} ${plural(box.pity_left, "коробку", "коробки", "коробок")}</span></div>
          <div class="bar" style="height:6px"><div style="width:${(box.pity - box.pity_left) / box.pity * 100}%;background:var(--pink)"></div></div></div>
        <div class="btns">
          <button class="pink" style="grid-column:1/-1" onclick="openBox(1,false)" ${busy || B.buys_left === 0 ? "disabled" : ""}>${B.buys_left === 0 ? "На сегодня всё" : "Открыть"}<small>${fmt(box.price)} мяуконов</small></button>
          <div class="buysleft">Купить сегодня: <b>${B.buys_left}</b> из ${B.buys_limit}. Цена растёт вместе с доходом.</div>
          <button class="free" id="freeBtn" onclick="${adsOn() ? "freeBoxAd()" : "openBox(1,true)"}" ${freeLeft > 0 || busy ? "disabled" : ""}>
            ${freeLeft > 0 ? "Коробка за рекламу через " + hms(freeLeft) : freeLabel()}</button>
        </div>`;
    }

    const freeLabel = () => adsOn() ? "Ещё коробка · смотреть рекламу" : "Ещё коробка (раз в сутки)";

    async function openBox(count, free) {
      if (busy) return;
      busy = true;
      showShake();
      try {
        const [data] = await Promise.all([
          api("POST", "/api/boxes/open", { box_id: 0, count: 1, free }),
          new Promise(r => setTimeout(r, 1100)),   // даём коробке потрястись
        ]);
        S = data; loadedAt = Date.now(); B = data; boxesAt = Date.now();
        lastOpen = { count, free };
        await chargeReveal(data.results);
        showResults(data.results);
      } catch (e) { closeModal(); toast(e.message); }
      finally { busy = false; render(); }
    }

    // Коробка в подарок (серия входов, задания): то же шоу открытия
    async function giftReveal(results, boxName, coins) {
      const idx = { "Картонная": 0, "Деревянная": 1, "Серебряная": 2, "Золотая": 3, "Космическая": 4, "Легендарная": 3 }[boxName] ?? 0;
      lastOpen = { count: 1, free: true };
      showShake(idx);
      await new Promise(r => setTimeout(r, 900));
      await chargeReveal(results);
      showResults(results);
      if (coins) toast("+" + fmt(coins) + " мяуконов");
    }
    function showShake(bi = sel) {
      const m = document.getElementById("modal");
      m.innerHTML = `<div class="rvbox shake" id="rvBox" style="--c:${BOX_LOOK[bi].base}">${boxSvg(bi, 180)}</div>
                     <div class="rvhint" id="rvHint">Открываем…</div>`;
      m.classList.add("on");
    }

    // ---- Шоу выпадения: коробка «заряжается» цветами редкостей до выпавшей, потом взрыв света ----
    const haptic = (k) => { try { tg && tg.HapticFeedback && tg.HapticFeedback.impactOccurred(k); } catch (e) {} };
    const RARE_SHOUT = ["", "", "ЭПИЧЕСКИЙ!", "ЛЕГЕНДАРНЫЙ!", "МИФИЧЕСКИЙ!"];
    function chargeReveal(res) {
      const best = Math.max(...res.map(x => x.rarity || 0));
      const box = document.getElementById("rvBox"), hint = document.getElementById("rvHint");
      if (!box) return Promise.resolve();
      return new Promise(resolve => {
        let step = 0, done = false, timer = null;
        const m = document.getElementById("modal");
        const finish = () => {
          if (done) return; done = true; clearTimeout(timer); m.onclick = null;
          burst(COLORS[best], best);
          resolve();
        };
        m.onclick = finish;                                   // тап — пропустить ожидание
        const tick = () => {
          const c = COLORS[step];
          box.className = "rvbox charging r" + step;
          box.style.setProperty("--c", c);
          if (hint) { hint.textContent = step === 0 ? "Открываем…" : step === 1 ? "Что-то светится…" : step === 2 ? "Ого…" : step === 3 ? "НЕ МОЖЕТ БЫТЬ…" : "ЭТО ЖЕ…"; hint.style.color = c; }
          haptic(step >= 3 ? "heavy" : step >= 1 ? "medium" : "light"); window.Snd && Snd.play("charge", step);
          if (step >= best) { timer = setTimeout(finish, best >= 3 ? 650 : 380); return; }
          step++;
          timer = setTimeout(tick, best >= 3 ? 520 : 400);
        };
        tick();
      });
    }
    function burst(col, rarity) {
      window.Snd && Snd.play("burst", rarity);
      const fl = document.createElement("div");
      fl.className = "rvflash"; fl.style.setProperty("--c", col);
      const n = 18 + rarity * 10;
      let parts = "";
      for (let i = 0; i < n; i++) {
        const ang = Math.random() * 360, dist = 120 + Math.random() * (140 + rarity * 40), sz = 4 + Math.random() * (5 + rarity * 2);
        const pc = i % 3 === 0 ? "#fff" : i % 3 === 1 ? col : (rarity >= 4 ? "#5EE7FF" : "#FFC94D");
        parts += `<i style="--a:${ang}deg;--d:${dist}px;width:${sz}px;height:${sz}px;background:${pc};animation-delay:${(Math.random() * 0.12).toFixed(2)}s"></i>`;
      }
      fl.innerHTML = `<div class="rvparts">${parts}</div>`;
      document.body.appendChild(fl);
      setTimeout(() => fl.remove(), 1400);
      if (rarity >= 3) { const m = document.getElementById("modal"); m.classList.remove("quake"); void m.offsetWidth; m.classList.add("quake"); }
      try { tg && tg.HapticFeedback && tg.HapticFeedback.notificationOccurred(rarity >= 3 ? "success" : "warning"); } catch (e) {}
    }

    function statusOf(x) {
      if (x.is_new) return { text: "Новый кот в команде!", bg: "var(--pink)", fg: "#1A0614" };
      return { text: "Уже в команде → +" + (x.treats || 0) + " 🍬 вкусняшек", bg: "#241D45", fg: "#D6CCFF" };
    }
    function itemArt(x, size) {
      if (x.kind === "cat" || x.kind == null) return CatArt.svg(x.cat_id, "sit", size);
      return `<span style="font-size:${Math.round(size * .62)}px;line-height:1">${KIND_ICO[x.kind] || "🎁"}</span>`;
    }
    function itemText(x) {
      if (x.kind === "recipe") return ["Новый рецепт", x.name, "Блюдо появилось в меню — гости заказывают больше"];
      if (x.kind === "decor") return ["Интерьер", x.name, "Поставь в любую комнату кнопкой «Интерьер»"];
      if (x.kind === "treats") return ["Вкусняшки", "+" + x.amount + " 🍬", "Покорми ими кота во вкладке «Коты»"];
      if (x.kind === "coins") return ["Мяуконы", "+" + fmt(x.amount), "Уже на счету"];
      return null;
    }
    function showResults(res) {
      const m = document.getElementById("modal");
      let body;
      if (res.length === 1 && (res[0].kind === "cat" || res[0].kind == null)) {
        const x = res[0], col = COLORS[x.rarity], st = statusOf(x), stats = (S.cats.find(c => c.cat_id === x.cat_id) || {}).stats;
        body = `${x.rarity >= 2 ? `<div class="rvshout r${x.rarity}" style="color:${col}">${RARE_SHOUT[x.rarity]}</div>` : ""}
          <div class="rvhero r${x.rarity}" style="--c:${col}"><div class="rvrays"></div>
            <div class="big rvcat" style="border-color:${col};box-shadow:0 0 40px ${col}">${CatArt.svg(x.cat_id, "sit", 108)}</div></div>
          <div class="rar" style="color:${col}">${x.rarity_name}${x.was_pity ? " · гарант" : ""}</div>
          <div style="font-size:28px;font-weight:800">${x.name}</div>
          ${stats ? statChips(stats) : ""}
          <div class="tag" style="background:${st.bg};color:${st.fg}">${st.text}</div>`;
      } else if (res.length === 1) {
        const x = res[0], [kind, title, sub] = itemText(x);
        body = `<div class="rvhero" style="--c:#FF5CA8"><div class="rvrays"></div><div class="big rvcat" style="border-color:#FF5CA8;box-shadow:0 0 40px #FF5CA8">${itemArt(x, 100)}</div></div>
          <div class="rar" style="color:#FF8FC4">${kind}</div><div style="font-size:26px;font-weight:800">${title}</div>
          <div style="font-size:14px;color:#D6CCFF">${sub}</div>`;
      } else {
        body = `<div style="font-size:20px;font-weight:800">${res.length} подарков</div>
          <div class="grid10">${res.map((x, i) => `<div style="border-color:${x.kind === "cat" ? COLORS[x.rarity] : "#FF5CA8"};animation-delay:${i * 0.08}s">
            ${itemArt(x, 40)}<span>${x.kind === "cat" ? x.name : (itemText(x) || ["", ""])[1]}</span>
            <span style="font-size:9px;color:${x.is_new ? "var(--pink)" : "#8A80B5"}">${x.kind === "cat" ? (x.is_new ? "новый" : "+" + (x.treats || 0) + " 🍬") : (itemText(x) || [""])[0]}</span></div>`).join("")}</div>`;
      }
      const again = lastOpen && !lastOpen.free && B && B.buys_left > 0;
      m.innerHTML = `<div class="dialog">${body}
        <div class="btns" style="width:100%;margin-top:8px">
          <button class="ghost" style="border-color:var(--line);color:var(--text)" onclick="closeModal()">Забрать</button>
          ${again ? `<button class="pink" onclick="closeModal();openBox(1,false)">Ещё одну</button>` : `<button class="pink" onclick="closeModal();go('cafe')">В кафе</button>`}
        </div></div>`;
    }
    function closeModal() { const m = document.getElementById("modal"); m.classList.remove("on", "quake"); m.onclick = null; }


    // ================= Живая комната =================
    // Всё, что здесь, — только картинка: экономику считает сервер.
    // Когда будут арты, достаточно поменять catSprite(): вернуть <img src="/assets/cats/ID_pose.png">.
    // Гости собираются из частей случайно: ~10 причёсок × 6 аксессуаров × цвета — каждый раз новый человек.
    const G_SKIN = ["#F2C9A6", "#C98E6A", "#F0D2B8", "#8E5E44", "#F6DCC6", "#5C3A28", "#E8B48A", "#D9A07A"];
    const G_HAIR = ["#FF5CA8", "#1E1A2E", "#5EE7FF", "#2A1F3A", "#B388FF", "#FFC94D", "#E8E4F2", "#7A3A1E", "#3BE08C", "#FF7A45"];
    const G_COAT = ["#2A2F5A", "#5A2E4E", "#1F3A44", "#3A2A20", "#2E2650", "#44203A", "#1E3A2A", "#3A3A48", "#4A1F2A", "#20324A"];
    const G_NEON = ["#5EE7FF", "#FF5CA8", "#FFC94D", "#B388FF", "#3BE08C"];
    const G_STYLE = ["bob", "spiky", "hood", "cap", "bun", "long", "mohawk", "afro", "pony", "beanie", "buzz"];
    const G_EXTRA = ["", "", "glasses", "visor", "phones", "mask", "earring", "beard"];
    function randomGuestLook(seed) {
      const r = seed != null ? cwRnd(seed) : Math.random, p = (arr) => arr[Math.floor(r() * arr.length)];
      return [p(G_SKIN), p(G_HAIR), p(G_COAT), p(G_NEON), p(G_STYLE), p(G_EXTRA)];
    }
    const GUEST_LOOKS = [
      ["#F2C9A6", "#FF5CA8", "#2A2F5A", "#5EE7FF", "bob"],
      ["#C98E6A", "#1E1A2E", "#5A2E4E", "#FF5CA8", "hood"],
      ["#F0D2B8", "#5EE7FF", "#1F3A44", "#FFC94D", "spiky"],
      ["#8E5E44", "#2A1F3A", "#3A2A20", "#5EE7FF", "cap"],
      ["#F6DCC6", "#B388FF", "#2E2650", "#FF5CA8", "bun"],
    ];

    // ================= Интерьеры локаций =================
    // У каждой локации своя сцена (фон за «стеной»), пол и мебель. seats — где сидят гости.
    const stars = (n, h) => { let d = ""; for (let i = 0; i < n; i++) d += `<circle cx="${(i * 37.3) % 400}" cy="${(i * 23.7) % h}" r="${0.6 + (i % 3) * 0.5}" fill="#fff" opacity="${0.3 + (i % 4) * 0.18}"/>`; return d; };
    const scene = (svg) => `<svg style="position:absolute;left:0;top:0;width:100%;height:42%" viewBox="0 0 400 200" preserveAspectRatio="xMidYMax slice" aria-hidden="true">${svg}</svg>`;
    // k — во сколько раз крупнее рисовать (viewBox тот же): мебель локаций стала больше, под крупных котов и гостей
    const piece = (x, y, w, h, svg, extra = "", k = 1.3) => `<div class="table" style="left:${x}%;top:${y}%;z-index:${Math.round(y)};${extra}"><svg width="${Math.round(w * k)}" height="${Math.round(h * k)}" viewBox="0 0 ${w} ${h}" aria-hidden="true">${svg}</svg></div>`;
    const big = (html) => html;

    const plant = (x, y) => piece(x, y, 30, 44, `<path d="M15 22 Q4 10 6 0 Q14 8 15 22 Q16 6 24 2 Q26 14 15 22" fill="#3DDC97"/><path d="M15 24 Q2 18 0 10 Q10 12 15 24 Q20 12 30 12 Q26 20 15 24" fill="#2AA87A"/><path d="M6 24 H24 L21 44 H9 Z" fill="#B85C3A"/>`);
    const stool = (x, y) => piece(x, y, 30, 40, `<ellipse cx="15" cy="6" rx="13" ry="5" fill="#FF5CA8"/><rect x="13" y="8" width="4" height="26" fill="#8A80B5"/><ellipse cx="15" cy="36" rx="9" ry="3" fill="#8A80B5"/>`);

    // мебель кухни и игровой (вид спереди)
    const arcadeF = (x, y, c) => piece(x, y, 40, 84, `<rect x="2" y="4" width="36" height="80" rx="4" fill="#2B1A58"/><rect x="6" y="12" width="28" height="24" rx="3" fill="#05030D"/><rect x="8" y="14" width="24" height="20" rx="2" fill="${c}" opacity=".85"/>
      <rect x="4" y="40" width="32" height="8" fill="#1E1240"/><circle cx="13" cy="44" r="2.5" fill="#FFC94D"/><circle cx="25" cy="44" r="2.5" fill="#3DFFB0"/><rect x="2" y="0" width="36" height="6" rx="2" fill="${c}"/>`);
    const catTowerF = (x, y) => piece(x, y, 50, 96, `<rect x="21" y="10" width="8" height="84" fill="#D9B27A"/><rect x="8" y="88" width="34" height="8" rx="3" fill="#B46AD0"/><rect x="4" y="46" width="42" height="7" rx="3" fill="#FF8FC4"/><rect x="10" y="6" width="32" height="7" rx="3" fill="#21E6FF"/><circle cx="40" cy="62" r="5" fill="#FFC94D"/><path d="M40 57 v-4" stroke="#ccc"/>`);
    const poufF = (x, y, c) => piece(x, y, 44, 26, `<ellipse cx="22" cy="18" rx="21" ry="8" fill="${c}" opacity=".7"/><ellipse cx="22" cy="12" rx="21" ry="10" fill="${c}"/><ellipse cx="17" cy="9" rx="8" ry="3" fill="#fff" opacity=".3"/>`);

    // ================= Интерьер: вещи из коробок встают в слоты комнаты =================
    const styleOf = (room, slot) => ((S.service && S.service.style && S.service.style[String(room)]) || {})[slot] || null;
    const WALL_CSS = {
      wall_mint: "background-color:#2C6A60;background-image:repeating-linear-gradient(90deg,rgba(255,255,255,.07) 0 14px,transparent 14px 28px)",
      wall_wood: "background-color:#5A3524;background-image:repeating-linear-gradient(90deg,#5E3826 0 22px,#4A2A1C 22px 24px)",
      wall_neon: "background-color:#160E30;background-image:repeating-linear-gradient(90deg,transparent 0 30px,rgba(255,92,168,.55) 30px 32px,transparent 32px 62px,rgba(33,230,255,.5) 62px 64px)",
      wall_stars: "background-color:#10123A;background-image:radial-gradient(#FFF 1px,transparent 1.5px),radial-gradient(rgba(255,201,77,.9) 1px,transparent 1.5px);background-size:38px 38px,57px 57px;background-position:0 0,19px 23px",
    };
    const FLOOR_CSS = {
      floor_check: "background-color:#D9DEEA;background-image:linear-gradient(45deg,#3A3060 25%,transparent 25%,transparent 75%,#3A3060 75%),linear-gradient(45deg,#3A3060 25%,transparent 25%,transparent 75%,#3A3060 75%);background-size:36px 36px;background-position:0 0,18px 18px;filter:brightness(.55)",
      floor_wood: "background-color:#7A4A2E;background-image:repeating-linear-gradient(45deg,#8A5636 0 10px,#6A3E26 10px 20px),repeating-linear-gradient(-45deg,rgba(0,0,0,.18) 0 10px,transparent 10px 20px);filter:brightness(.7)",
      floor_neon: "background-color:#0C0A20;background-image:linear-gradient(rgba(33,230,255,.35) 1px,transparent 1px),linear-gradient(90deg,rgba(255,92,168,.3) 1px,transparent 1px);background-size:30px 30px",
    };
    const WALL_H = { 0: "60.5%", 1: "42%", 2: "42%", 3: "42%" };
    function wallSkin(room) { const k = styleOf(room, "wall"); return k ? `<div style="position:absolute;left:0;right:0;top:0;height:${WALL_H[room]};${WALL_CSS[k]}"></div>` : ""; }
    function floorSkin(room) { const k = styleOf(room, "floor"); return k ? `<div style="position:absolute;left:0;right:0;top:${WALL_H[room]};bottom:0;${FLOOR_CSS[k]}"></div>` : ""; }
    function lamp(kind, x, len, delay) {
      if (!kind) return edison(x, len, delay);
      const body = {
        lamp_paper: `<ellipse cx="20" cy="${len + 14}" rx="12" ry="14" fill="#FF8FC4"/><path d="M8 ${len + 10} h24 M8 ${len + 18} h24" stroke="#C2316E" stroke-width="1"/><rect x="16" y="${len - 2}" width="8" height="4" fill="#2A1A10"/>`,
        lamp_neon: `<circle cx="20" cy="${len + 14}" r="11" fill="none" stroke="#21E6FF" stroke-width="3"/><circle cx="20" cy="${len + 14}" r="5" fill="none" stroke="#FF5CA8" stroke-width="2"/>`,
        lamp_moon: `<circle cx="20" cy="${len + 14}" r="12" fill="#F4F0FF"/><circle cx="16" cy="${len + 10}" r="2.5" fill="#D8D0F0"/><circle cx="24" cy="${len + 18}" r="2" fill="#D8D0F0"/>`,
      }[kind];
      const glow = { lamp_paper: "#FF8FC4", lamp_neon: "#21E6FF", lamp_moon: "#E8E4FF" }[kind];
      return `<div class="table" style="left:${x}%;top:0;z-index:5;transform:translateX(-50%)"><svg width="40" height="${len + 30}" viewBox="0 0 40 ${len + 30}" aria-hidden="true" style="overflow:visible">
        <defs><radialGradient id="lmG${x}"><stop offset="0" stop-color="${glow}" stop-opacity=".45"/><stop offset="1" stop-color="${glow}" stop-opacity="0"/></radialGradient></defs>
        <g class="lampglow" style="animation-delay:${delay}s"><circle cx="20" cy="${len + 16}" r="60" fill="url(#lmG${x})"/></g><rect x="19" y="0" width="2" height="${len}" fill="#1A0E0E"/>${body}</svg></div>`;
    }
    const lampsFor = (room, list) => list.map(([x, len, d]) => lamp(styleOf(room, "lamp"), x, len, d)).join("");
    const ART = {
      art_cat: `<rect x="2" y="2" width="56" height="66" rx="4" fill="#C9963E"/><rect x="7" y="7" width="46" height="56" fill="#2A1E3A"/><ellipse cx="30" cy="40" rx="15" ry="13" fill="#9AA3B5"/><path d="M17 33 L15 18 L25 27 M43 33 L45 18 L35 27" fill="#9AA3B5"/><circle cx="25" cy="38" r="2.4" fill="#FFD23F"/><circle cx="35" cy="38" r="2.4" fill="#FFD23F"/><path d="M28 44 h4 l-2 2z" fill="#FF8FC4"/><path d="M14 63 Q30 50 46 63" fill="#7A4AA0"/>`,
      art_wave: `<rect x="2" y="2" width="56" height="66" rx="4" fill="#3A2A22"/><rect x="7" y="7" width="46" height="56" fill="#F1E6CC"/><path d="M7 48 Q16 26 30 38 Q22 30 30 24 Q44 18 53 34 L53 63 L7 63 Z" fill="#2D5A8C"/><path d="M12 46 Q18 34 26 40 M30 30 Q38 24 46 32" stroke="#fff" stroke-width="2" fill="none"/><circle cx="44" cy="16" r="5" fill="#E04A4A"/>`,
      art_moon: `<rect x="2" y="2" width="56" height="66" rx="4" fill="#1A1430" stroke="#FFC94D" stroke-width="2"/><rect x="7" y="7" width="46" height="56" fill="#0E0A28"/><circle cx="30" cy="44" r="16" fill="#F4F0D8"/><circle cx="24" cy="40" r="3" fill="#D8D2B0"/><circle cx="36" cy="50" r="2" fill="#D8D2B0"/><path d="M25 28 L23 18 L29 24 L33 24 L37 18 L35 28 Q35 34 30 34 Q25 34 25 28Z" fill="#2A2236"/><circle cx="14" cy="15" r="1" fill="#fff"/><circle cx="46" cy="20" r="1" fill="#fff"/>`,
    };
    const ART_POS = { 0: "left:9%;top:26%", 1: "left:5%;top:23%", 2: "left:4%;top:14%", 3: "left:44%;top:26%" };
    function artFor(room) { const k = styleOf(room, "art"); return k ? `<div class="table" style="${ART_POS[room]};z-index:6;transform:none"><svg width="52" height="61" viewBox="0 0 60 70" aria-hidden="true" style="filter:drop-shadow(0 4px 6px rgba(0,0,0,.5))">${ART[k]}</svg></div>` : ""; }
    function windowFor(room) {
      const k = room === 0 ? styleOf(0, "window") : null; if (!k) return "";
      if (k === "window_plants") return `<div class="table" style="left:40%;top:44%;width:56%;z-index:7;transform:none"><svg width="100%" height="34" viewBox="0 0 200 34" preserveAspectRatio="none" aria-hidden="true">${[14, 60, 108, 156].map((x, i) => `<path d="M${x} 20 h22 l-3 14 h-16z" fill="#B85C3A"/><path d="M${x + 11} 20 Q${x + 2} 6 ${x + 4} 0 Q${x + 12} 8 ${x + 11} 20 Q${x + 14} 4 ${x + 22} 2 Q${x + 20} 12 ${x + 11} 20" fill="${i % 2 ? "#3DDC97" : "#2AA87A"}"/>`).join("")}</svg></div>`;
      return `<div class="table" style="left:40%;top:7%;width:56%;z-index:7;transform:none"><svg width="100%" height="40" viewBox="0 0 200 40" preserveAspectRatio="none" aria-hidden="true"><path d="M0 4 Q50 30 100 6 Q150 30 200 4" stroke="#2A1A10" stroke-width="1.2" fill="none"/>${Array.from({ length: 16 }, (_, i) => { const x = i * 12.5 + 6, y = 4 + Math.sin(i / 15 * Math.PI * 2) * 0 + (i < 8 ? Math.sin(i / 8 * Math.PI) * 16 : Math.sin((i - 8) / 8 * Math.PI) * 16); return `<circle class="bulb" cx="${x}" cy="${y + 4}" r="3" fill="${["#FFC94D", "#FF5CA8", "#21E6FF", "#7FE0B5"][i % 4]}" style="animation-delay:-${(i * .3).toFixed(1)}s"/>`; }).join("")}</svg></div>`;
    }
    const decorFor = room => artFor(room) + windowFor(room);

    // ---- детали кухни ----
    const kWindow = () => `<div class="table" style="left:4%;top:5%;width:24%;height:21%;transform:none;z-index:3;border:5px solid #4A3226;border-radius:4px;overflow:hidden;background:linear-gradient(#060B1C,#14284A)">
      <svg width="100%" height="100%" viewBox="0 0 100 80" preserveAspectRatio="none" aria-hidden="true"><path d="M0 80 V52 H14 V40 H26 V58 H40 V34 H54 V50 H70 V44 H84 V60 H100 V80Z" fill="#0C1830"/>
      ${[[18, 46], [44, 40], [48, 44], [74, 50], [88, 64]].map(([x, y]) => `<rect x="${x}" y="${y}" width="3" height="3" fill="#FFC94D"/>`).join("")}<rect x="48" y="0" width="4" height="80" fill="#4A3226"/></svg>
      <div style="position:absolute;inset:0;background:repeating-linear-gradient(100deg,transparent 0 9px,rgba(170,200,255,.18) 9px 10px)"></div></div>`;
    const kShelves = () => `<div class="table" style="left:66%;top:6%;width:31%;transform:none;z-index:3"><svg width="100%" viewBox="0 0 110 80" aria-hidden="true">
      <rect x="0" y="30" width="110" height="5" fill="#7A5236"/><rect x="0" y="72" width="110" height="5" fill="#7A5236"/>
      ${[[6, "#FF8FC4"], [20, "#FFC94D"], [34, "#7FE0B5"], [48, "#B388FF"]].map(([x, c]) => `<rect x="${x}" y="12" width="11" height="18" rx="3" fill="${c}" opacity=".85"/><rect x="${x}" y="9" width="11" height="4" rx="1" fill="#E8E0D0"/>`).join("")}
      <rect x="66" y="18" width="38" height="12" rx="2" fill="#E8E0D0"/><rect x="68" y="14" width="34" height="5" rx="2" fill="#F4EDE4"/>
      <ellipse cx="18" cy="68" rx="14" ry="5" fill="#B0606A"/><rect x="5" y="56" width="26" height="13" rx="3" fill="#C9707A"/><rect x="40" y="52" width="9" height="20" fill="#5A7A9A"/><rect x="51" y="48" width="9" height="24" fill="#B85C3A"/><rect x="62" y="54" width="9" height="18" fill="#3DA77A"/>
      <path d="M80 72 q4 -18 14 -20 q8 8 4 20z" fill="#3DDC97"/><rect x="82" y="64" width="14" height="8" fill="#B85C3A"/></svg></div>`;
    const kRail = () => `<div class="table" style="left:32%;top:4%;width:30%;transform:none;z-index:3"><svg width="100%" viewBox="0 0 110 56" aria-hidden="true">
      <rect x="0" y="2" width="110" height="3" rx="1.5" fill="#9AA0B8"/>
      <path d="M12 5 v8" stroke="#9AA0B8" stroke-width="1.5"/><circle cx="12" cy="24" r="11" fill="#2A2A36"/><circle cx="12" cy="24" r="8" fill="#3A3A48"/><rect x="11" y="34" width="2" height="16" fill="#5A3A26"/>
      <path d="M38 5 v6" stroke="#9AA0B8" stroke-width="1.5"/><rect x="37" y="11" width="2" height="22" fill="#B8BED4"/><ellipse cx="38" cy="38" rx="6" ry="5" fill="#B8BED4"/>
      <path d="M58 5 v8" stroke="#9AA0B8" stroke-width="1.5"/><path d="M52 14 q6 30 12 0" stroke="#B8BED4" stroke-width="2" fill="none"/><path d="M55 14 q3 26 6 0" stroke="#B8BED4" stroke-width="1.5" fill="none"/>
      <path d="M82 5 v8" stroke="#9AA0B8" stroke-width="1.5"/><circle cx="82" cy="28" r="14" fill="#C27A3A"/><circle cx="82" cy="28" r="10" fill="#D98A44"/><rect x="81" y="42" width="2" height="12" fill="#5A3A26"/>
      <path d="M102 5 v10" stroke="#9AA0B8" stroke-width="1.5"/><path d="M96 15 h12 l-2 20 h-8z" fill="#E8E0D0"/></svg></div>`;
    const kTickets = (n, hot) => `<div class="table ktick" style="left:34%;top:21%;width:30%;transform:none;z-index:4" title="Заказы на кухне">
      <div class="kbar"></div>${Array.from({ length: n }, (_, i) => `<i style="left:${4 + i * 13}%;transform:rotate(${(i % 2 ? 4 : -5)}deg);${hot && i > 3 ? "border-color:#FF5C7A" : ""}"></i>`).join("")}<span>заказы</span></div>`;
    const kCounter = () => `<div style="position:absolute;left:0;right:0;top:57%;height:3%;background:linear-gradient(#E9E2D4,#BDB2A0);z-index:8"></div>
      <div style="position:absolute;left:18%;right:28%;top:60%;height:13%;background:repeating-linear-gradient(90deg,#6E4630 0 46px,#5A3826 46px 48px);z-index:8;box-shadow:inset 0 6px 8px rgba(0,0,0,.35)">
      ${[12, 40, 68].map(x => `<span style="position:absolute;left:${x}%;top:22%;width:14%;height:4px;border-radius:2px;background:#C9A06A"></span>`).join("")}</div>
      <div class="table" style="left:47%;top:57.4%;z-index:9"><svg width="58" height="22" viewBox="0 0 58 22" aria-hidden="true"><rect x="2" y="12" width="34" height="9" rx="2" fill="#B07A4A"/><circle cx="12" cy="11" r="5" fill="#E04A4A"/><circle cx="22" cy="12" r="4" fill="#7FE0B5"/><path d="M28 12 l6 -9 l2 9z" fill="#FFB347"/><ellipse cx="48" cy="16" rx="9" ry="5" fill="#E8E0D0"/><ellipse cx="48" cy="13" rx="9" ry="4" fill="#F4EDE4"/></svg></div>`;
    const kStove = (x, y) => `<div class="table" style="left:${x}%;top:${y}%;z-index:9"><svg width="92" height="70" viewBox="0 0 92 70" aria-hidden="true" style="overflow:visible">
      <rect x="0" y="50" width="92" height="20" fill="#2A2A36"/><rect x="0" y="48" width="92" height="4" fill="#4A4A5A"/>
      <g class="flame"><path d="M14 50 q4 -8 8 0 q4 -8 8 0" fill="#FF8A2E"/><path d="M58 50 q4 -8 8 0 q4 -8 8 0" fill="#FF8A2E"/><path d="M18 50 q3 -5 6 0" fill="#FFE14D"/><path d="M62 50 q3 -5 6 0" fill="#FFE14D"/></g>
      <rect x="6" y="26" width="34" height="22" rx="3" fill="#C9CFE0"/><rect x="4" y="24" width="38" height="5" rx="2" fill="#E8ECF6"/><rect x="40" y="30" width="10" height="3" rx="1.5" fill="#9AA0B8"/>
      <path d="M52 34 h36 l-4 14 h-28z" fill="#3A3A48"/><rect x="50" y="31" width="40" height="4" rx="2" fill="#5A5A6A"/><rect x="88" y="32" width="12" height="3" rx="1.5" fill="#5A3A26"/>
      ${steam(23, 22)}${steam(70, 30)}</svg></div>`;
    const kOven = (x, y) => `<div class="table" style="left:${x}%;top:${y}%;z-index:9"><svg width="108" height="128" viewBox="0 0 108 128" aria-hidden="true" style="overflow:visible">
      <defs><radialGradient id="koG" cx="50%" cy="70%" r="60%"><stop offset="0" stop-color="#FFE14D"/><stop offset=".45" stop-color="#FF8A2E"/><stop offset="1" stop-color="#7A1E10"/></radialGradient></defs>
      <rect x="44" y="0" width="16" height="40" fill="#4A3A3A"/><rect x="40" y="0" width="24" height="6" fill="#5A4848"/>
      <path d="M4 128 V70 Q4 30 54 30 Q104 30 104 70 V128 Z" fill="#9A4A36"/>
      ${[48, 62, 76, 90, 104, 118].map((y, i) => `<path d="M4 ${y} H104" stroke="#6A2E22" stroke-width="2"/>${[14, 34, 54, 74, 94].map(x => `<path d="M${x + (i % 2) * 10} ${y} v14" stroke="#6A2E22" stroke-width="2"/>`).join("")}`).join("")}
      <path d="M24 128 V92 Q24 70 54 70 Q84 70 84 92 V128 Z" fill="#1A0A08"/><path d="M28 128 V94 Q28 74 54 74 Q80 74 80 94 V128 Z" fill="url(#koG)" class="ovenglow"/>
      <g class="flame"><path d="M36 128 q6 -26 12 -6 q4 -20 10 -2 q6 -18 10 8z" fill="#FFE14D" opacity=".9"/></g>
      <rect x="32" y="118" width="40" height="6" rx="3" fill="#5A3A26"/><path d="M20 70 Q54 52 88 70" stroke="#C26A4A" stroke-width="3" fill="none"/></svg></div>`;
    const kFridge = (x, y) => `<div class="table" style="left:${x}%;top:${y}%;z-index:9"><svg width="52" height="118" viewBox="0 0 52 118" aria-hidden="true">
      <rect x="2" y="2" width="48" height="114" rx="12" fill="#8FD8C8"/><rect x="2" y="2" width="48" height="40" rx="12" fill="#A4E4D6"/><path d="M2 42 H50" stroke="#5FA898" stroke-width="2"/>
      <rect x="40" y="14" width="4" height="18" rx="2" fill="#E8ECF6"/><rect x="40" y="52" width="4" height="26" rx="2" fill="#E8ECF6"/>
      <circle cx="16" cy="60" r="5" fill="#FF5CA8"/><path d="M12 56 l-1 -4 l3 2 M20 56 l1 -4 l-3 2" stroke="#FF5CA8" stroke-width="2"/><rect x="12" y="72" width="14" height="10" fill="#F4EDE4"/><rect x="24" y="22" width="9" height="9" rx="4.5" fill="#FFC94D"/></svg></div>`;

    const LOC_DECOR = [
      { // 0 Кафе — «Лофт под дождём»: тёплый кирпич и лампы внутри, холодный неоновый город за окном
        seats: [{ x: 26, y: 78 }, { x: 74, y: 76 }],
        html() {
          const tt = tierOf("tables");
          return `<div style="position:absolute;inset:0;background:#2A1416;background-image:repeating-linear-gradient(0deg, transparent 0 13px, rgba(0,0,0,.35) 13px 15px), repeating-linear-gradient(90deg, transparent 0 28px, rgba(0,0,0,.25) 28px 30px)"></div>
            <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 20% 20%, rgba(255,170,80,.30), transparent 55%), radial-gradient(ellipse at 34% 16%, rgba(255,170,80,.16), transparent 45%)"></div>
            ${wallSkin(0)}${cityWindow(21)}
            <svg style="position:absolute;left:0;top:0;width:100%;height:30px;z-index:4" aria-hidden="true"><rect x="0" y="8" width="100%" height="6" fill="#B87333"/><rect x="0" y="9" width="100%" height="1.5" fill="#E8A066" opacity=".6"/>${[8, 30, 52, 74].map(x => `<rect x="${x}%" y="5" width="8" height="12" rx="2" fill="#8A5428"/>`).join("")}</svg>
            ${lampsFor(0, [[47, 34, 0], [62, 48, 1.3], [77, 30, 2.1]])}
            <div class="table" style="left:79%;top:58%;z-index:7;transform:translate(-50%,0)"><svg width="80" height="14" viewBox="0 0 80 14" aria-hidden="true"><rect x="0" y="0" width="80" height="6" rx="2" fill="#6B3F2A"/><path d="M8 6 l6 8 M72 6 l-6 8" stroke="#3B2218" stroke-width="3"/></svg></div>
            ${objBtn("bank", "Копилка", piggySvg(tierOf("bank")), "left:79%;top:58.4%;transform:translate(-50%,-100%);z-index:8")}
            <div style="position:absolute;left:0;right:0;top:61%;bottom:0;background-color:#1E120F;background-image:repeating-linear-gradient(0deg,#22140F 0 22px,#160C0A 22px 24px)"></div>${floorSkin(0).replace("top:60.5%", "top:61%")}
            <div style="position:absolute;left:0;right:0;top:60.5%;height:5px;background:#120A08"></div>
            <div style="position:absolute;left:6%;top:61%;width:46%;height:39%;background:radial-gradient(ellipse at 50% 0%, rgba(255,176,96,.20), transparent 70%)"></div>
            <div style="position:absolute;left:42%;top:61%;width:56%;height:39%;background:linear-gradient(rgba(33,150,255,.10),transparent 60%);filter:blur(4px)"></div>
`
            + tableRow(0, this.seats) + decorFor(0) + slotButtons(0);
        },
      },
      { // 1 Кухня: кирпичная печь с огнём, плита с кастрюлями, полки, кофемашина, лента заказов. Работают коты-повара
        seats: [],
        html() {
          const sv = S.service, orders = Math.max(1, Math.min(7, Math.round(sv.guests_min * 1.5))), hot = sv.neck === "kitchen";
          return `<div class="wall" style="height:58%;border:0;background:#2A2236;background-image:radial-gradient(ellipse at 50% 0%, rgba(255,170,90,.28), transparent 70%)"></div>
            <div style="position:absolute;left:0;right:0;top:30%;height:28%;background-color:#C9BBA4;background-image:linear-gradient(rgba(60,40,30,.35) 1.5px, transparent 1.5px),linear-gradient(90deg, rgba(60,40,30,.35) 1.5px, transparent 1.5px);background-size:26px 13px;filter:brightness(.62) sepia(.25)"></div>
            ${wallSkin(1)}
            <div style="position:absolute;left:0;right:0;top:30%;height:28%;background:linear-gradient(rgba(255,150,70,.12),rgba(0,0,0,.25))"></div>
            ${kWindow()}${kShelves()}${kRail()}${kTickets(orders, hot)}${artFor(1)}
            ${styleOf(1, "lamp") ? lampsFor(1, [[30, 18, 0], [62, 24, 1.2]]) : ""}
            <div class="floor" style="top:58%;background-color:#5E3426;background-image:linear-gradient(45deg,#6E3E2C 25%,transparent 25%,transparent 75%,#6E3E2C 75%),linear-gradient(45deg,#6E3E2C 25%,transparent 25%,transparent 75%,#6E3E2C 75%);background-size:40px 40px;background-position:0 0,20px 20px;filter:brightness(.75)"></div>${floorSkin(1)}
            <div style="position:absolute;left:0;right:0;top:58%;height:18%;background:radial-gradient(ellipse at 78% 0%, rgba(255,140,60,.35), transparent 60%)"></div>
            ${kCounter()}${kStove(34, 59)}
            ${eqOf("fridge").level > 0 ? kFridge(11, 74) : ""}
            ${kOven(80, 76)}
            ${eqBtn("coffee", coffeeSvg(eqOf("coffee").level >= 12 ? 2 : eqOf("coffee").level >= 5 ? 1 : 0), "left:58%;top:58.5%;transform:translate(-50%,-100%);z-index:70")}
            ${eqBtn("oven", "", "left:80%;top:76.5%;transform:translate(-50%,0);z-index:70")}
            ${eqOf("fridge").level > 0 ? eqBtn("fridge", "", "left:11%;top:74.5%;transform:translate(-50%,0);z-index:70") : `<button class="tslot ${S.coins >= eqOf("fridge").cost ? "can" : ""}" style="left:11%;top:74%;z-index:70" onclick="event.stopPropagation();openEquip('fridge')"><b>🧊 +</b><span><i class="coin s"></i>${fmt(eqOf("fridge").cost)}</span></button>`}
            ${slotButtons(1)}`;
        },
      },
      { // 2 Доп. зал: большие окна на город, лампы, много столиков
        seats: [{ x: 20, y: 74 }, { x: 52, y: 70 }, { x: 82, y: 74 }],
        html() {
          const tt = tierOf("tables");
          return `<div class="wall" style="background:#3A1A2C;background-image:repeating-linear-gradient(90deg, rgba(0,0,0,.25) 0 2px, transparent 2px 46px)"></div>${wallSkin(2)}
            ${scene(`${[100, 200, 300].map(x => `<rect x="${x}" y="20" width="84" height="110" rx="42" fill="#0A0B24" stroke="#6B4FA0" stroke-width="5"/>
              <path d="M${x + 6} 128 V${70} H${x + 18} V${92} H${x + 30} V${60} H${x + 44} V${84} H${x + 58} V${66} H${x + 78} V128 Z" fill="#141640"/>
              <rect x="${x + 22}" y="74" width="3" height="4" fill="#FFC94D"/><rect x="${x + 50}" y="72" width="3" height="4" fill="#21E6FF"/><rect x="${x + 64}" y="80" width="3" height="4" fill="#FF5CA8"/>
              <line x1="${x + 42}" y1="22" x2="${x + 42}" y2="128" stroke="#6B4FA0" stroke-width="3"/>`).join("")}
              <rect x="0" y="150" width="400" height="6" fill="#2A1222"/>`)}
            ${lampsFor(2, [[30, 30, .4], [70, 42, 1.6]])}
            <div class="floor" style="background-color:#4A2E26;background-image:repeating-linear-gradient(0deg,#4A2E26 0 22px,#3A221C 22px 24px)"></div>${floorSkin(2)}
            ${plant(5, 66)}${plant(95, 68)}` + tableRow(2, this.seats) + decorFor(2) + slotButtons(2);
        },
      },
      { // 3 Игровая: гости играют с котами — автоматы, кошачье дерево, пуфы, неоновые плакаты
        seats: [{ x: 34, y: 82 }, { x: 64, y: 90 }],
        html() {
          return `<div class="wall" style="background:#1E1450;background-image:radial-gradient(rgba(179,136,255,.18) 1px, transparent 1.5px);background-size:16px 16px"></div>${wallSkin(3)}${styleOf(3, "lamp") ? lampsFor(3, [[30, 20, 0], [70, 20, 1]]) : ""}
            ${scene(`<rect x="40" y="36" width="70" height="90" rx="6" fill="#2A0F3D" stroke="#FF5CA8" stroke-width="3"/><text x="75" y="88" text-anchor="middle" font-size="20" font-weight="800" fill="#FF5CA8" font-family="sans-serif">PLAY</text>
              <rect x="150" y="26" width="100" height="56" rx="6" fill="#0F2A3D" stroke="#21E6FF" stroke-width="3"/><text x="200" y="62" text-anchor="middle" font-size="18" font-weight="800" fill="#21E6FF" font-family="sans-serif">MEOW</text>
              <rect x="290" y="40" width="64" height="80" rx="6" fill="#2A2A0F" stroke="#FFC94D" stroke-width="3"/><text x="322" y="88" text-anchor="middle" font-size="20" font-weight="800" fill="#FFC94D" font-family="sans-serif">1UP</text>`)}
            <div class="floor" style="background-color:#3A2470;background-image:repeating-linear-gradient(45deg, rgba(255,255,255,.04) 0 12px, transparent 12px 24px)"></div>${floorSkin(3)}
            ${arcadeF(12, 70, "#FF5CA8")}${arcadeF(24, 66, "#21E6FF")}${catTowerF(88, 72)}${this.seats.map((t, i) => poufF(t.x, t.y, i ? "#21E6FF" : "#FF8FC4")).join("")}${plant(76, 64)}${decorFor(3)}${slotButtons(3)}
            <button class="obj" style="left:50%;top:44%;transform:translate(-50%,0);z-index:70" onclick="event.stopPropagation();openPlayroom()"><span class="lvl" style="font-size:10px">🎟 Вход · ур. ${S.service.playroom.level}</span></button>`;
        },
      },
    ];

    // ================= Уютное кафе: улучшаемые предметы =================
    // Каждый предмет — кнопка: тап открывает улучшения. Внешний вид меняется с уровнем (3 ступени).
    const UPG_TIER = { cash: [10, 24], coffee: [10, 24], bank: [3, 6], tables: [3, 7] };
    function upg(kind) { return (S && S.upgrades || []).find(u => u.kind === kind) || { level: 1, cost: 0, maxed: true }; }
    function tierOf(kind) { const l = upg(kind).level, t = UPG_TIER[kind]; return l >= t[1] ? 2 : l >= t[0] ? 1 : 0; }
    const steam = (x, y) => `<g class="steam"><path d="M${x} ${y} q-3 -5 0 -10 q3 -5 0 -10" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M${x + 6} ${y} q-3 -5 0 -10 q3 -5 0 -10" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M${x - 6} ${y} q-3 -5 0 -10 q3 -5 0 -10" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/></g>`;
    function coffeeSvg(t) {
      const body = ["#5EE7FF", "#C9D2E3", "#FFC94D"][t], trim = ["#2AA9C4", "#8A94AA", "#D49A1E"][t], w = [46, 54, 60][t];
      return `<svg width="${w}" height="${w + 14}" viewBox="0 0 60 74" aria-hidden="true" style="overflow:visible">
        ${steam(t ? 22 : 30, 30)}${t ? steam(40, 30) : ""}
        <rect x="4" y="18" width="52" height="54" rx="7" fill="${body}"/><rect x="4" y="18" width="52" height="10" rx="5" fill="${trim}"/>
        <rect x="11" y="32" width="38" height="12" rx="3" fill="#0E0B1E"/><circle cx="18" cy="38" r="2.6" fill="#FF5CA8"/><rect x="24" y="36" width="18" height="4" rx="2" fill="${t === 2 ? "#FF5CA8" : "#5EE7FF"}"/>
        ${t ? `<circle cx="47" cy="25" r="5" fill="#F2EEFF" stroke="${trim}" stroke-width="1.5"/><path d="M47 25 l2.5 -2.5" stroke="#140F2A" stroke-width="1.2"/>` : ""}
        <rect x="${t ? 14 : 22}" y="46" width="10" height="5" rx="2" fill="${trim}"/>${t ? `<rect x="36" y="46" width="10" height="5" rx="2" fill="${trim}"/>` : ""}
        <path d="M${t ? 13 : 21} 58 h12 l-1.5 10 h-9 Z" fill="#F2EEFF"/>${t ? `<path d="M35 58 h12 l-1.5 10 h-9 Z" fill="#F2EEFF"/>` : ""}
        ${t === 2 ? `<path d="M30 4 l4 8 l8 1 l-6 5 l2 8 l-8 -4 l-8 4 l2 -8 l-6 -5 l8 -1 Z" fill="#FF5CA8"/>` : ""}</svg>`;
    }
    function registerSvg(t) {
      const body = ["#8A80B5", "#FF8FC4", "#FFC94D"][t], dark = ["#5A5490", "#D9649E", "#D49A1E"][t];
      return `<svg width="${[42, 48, 52][t]}" height="${[40, 46, 50][t]}" viewBox="0 0 52 50" aria-hidden="true" style="overflow:visible">
        ${t === 2 ? `<circle cx="10" cy="44" r="5" fill="#FFC94D" stroke="#D49A1E"/><circle cx="16" cy="40" r="5" fill="#FFE08A" stroke="#D49A1E"/>` : ""}
        <rect x="6" y="4" width="28" height="12" rx="3" fill="${dark}"/><rect x="9" y="7" width="22" height="6" rx="2" fill="#7FE0B5"/>
        <path d="M2 20 h48 l-3 28 h-42 Z" fill="${body}"/><rect x="2" y="16" width="48" height="6" rx="2" fill="${dark}"/>
        ${[0, 1, 2].map(r => [0, 1, 2, 3].map(c => `<rect x="${9 + c * 9}" y="${25 + r * 7}" width="6" height="4" rx="1" fill="#F2EEFF" opacity=".85"/>`).join("")).join("")}
        ${t ? `<path d="M48 22 q8 -2 6 -12" stroke="${dark}" stroke-width="3" fill="none"/><circle cx="54" cy="9" r="3" fill="${dark}"/>` : ""}
        ${t === 2 ? `<path d="M26 0 l4 5 l-4 5 l-4 -5 Z" fill="#5EE7FF"/>` : ""}</svg>`;
    }
    function piggySvg(t) {
      const body = t === 2 ? "#FFC94D" : "#FF9ECB", dark = t === 2 ? "#D49A1E" : "#E2689E", sz = [34, 40, 44][t];
      return `<svg width="${sz}" height="${sz * 0.8}" viewBox="0 0 46 36" aria-hidden="true" style="overflow:visible">
        ${t ? `<circle cx="22" cy="-2" r="5" fill="#FFC94D" stroke="#D49A1E"/>` : ""}
        <ellipse cx="22" cy="20" rx="17" ry="13" fill="${body}"/><path d="M12 9 l2 -7 l6 6 Z" fill="${dark}"/><path d="M28 8 l4 -6 l3 8 Z" fill="${dark}"/>
        <ellipse cx="38" cy="21" rx="6" ry="5" fill="${dark}"/><circle cx="36.5" cy="21" r="1.2" fill="#140F2A"/><circle cx="39.5" cy="21" r="1.2" fill="#140F2A"/>
        <circle cx="30" cy="15" r="1.8" fill="#140F2A"/><rect x="16" y="8" width="10" height="2.5" rx="1.2" fill="${dark}"/>
        <rect x="10" y="30" width="5" height="6" rx="2" fill="${dark}"/><rect x="26" y="30" width="5" height="6" rx="2" fill="${dark}"/>
        <path d="M5 18 q-5 -2 -3 -7" stroke="${dark}" stroke-width="2" fill="none"/>
        ${t === 2 ? `<rect x="-14" y="26" width="10" height="4" rx="2" fill="#FFC94D" stroke="#D49A1E"/><rect x="-13" y="22" width="10" height="4" rx="2" fill="#FFE08A" stroke="#D49A1E"/><rect x="-14" y="18" width="10" height="4" rx="2" fill="#FFC94D" stroke="#D49A1E"/>` : ""}</svg>`;
    }
    // ================= Коты-работники: места в комнатах =================
    // место 0 в Главном зале — касса (там стоит бариста), остальные — у столиков, у плиты, на пуфах
    const SLOT_POS = { 0: [null, { x: 24, y: 92 }, { x: 70, y: 90 }], 1: [{ x: 36, y: 90 }, { x: 62, y: 93 }],
                       2: [{ x: 20, y: 90 }, { x: 50, y: 86 }, { x: 74, y: 92 }], 3: [{ x: 34, y: 80 }, { x: 64, y: 88 }] };
    const ROLE_ICO = { wait: "🍽", cook: "🍳", cash: "💰", play: "🎲" };
    const ROLE_NAME = { wait: "Официант", cook: "Повар", cash: "Кассир", play: "Игрок" };
    const svcSlots = () => (S.service && S.service.slots) || [];
    const slotOf = (room, slot) => svcSlots().find(s => s.room === room && s.slot === slot);
    function slotName(room, slot) {
      const s = slotOf(room, slot); if (!s) return "";
      const rn = (S.locations[room] || {}).name || "";
      if (s.role === "cash") return "Касса";
      if (s.role === "wait") return (room === 0 ? "Столик " : rn + ", столик ") + (s.table + 1);
      return rn + ", место " + (slot + 1);
    }
    function catPlace(c) { return c.location == null || c.slot == null ? "В запасе" : slotName(c.location, c.slot); }
    function statChips(st, role) {
      return `<div class="statchips">${["wait", "cook", "cash", "play"].map(k => `<span class="${k === role ? "on" : ""}" title="${ROLE_NAME[k]}">${ROLE_ICO[k]} ${d1(st[k])}</span>`).join("")}</div>`;
    }
    // пустые места: «+ официант», «+ повар»… (у некупленного столика вместо этого — кнопка покупки)
    function slotButtons(room) {
      if (!S.locations[room] || !S.locations[room].open) return "";
      return svcSlots().filter(s => s.room === room && s.cat_id == null && s.role !== "cash" && (s.table == null || s.table_level > 0)).map(s => {
        const p = SLOT_POS[room][s.slot];
        return `<button class="slotbtn" style="left:${p.x}%;top:${p.y}%;z-index:${Math.round(p.y) + 3}" onclick="event.stopPropagation();openSlotPicker(${room},${s.slot})">
          <span>${ROLE_ICO[s.role]}</span><b>+ ${ROLE_NAME[s.role].toLowerCase()}</b></button>`;
      }).join("");
    }
    function openSlotPicker(room, slot) {
      const s = slotOf(room, slot), m = document.getElementById("modal"), role = s.role;
      const list = S.cats.slice().sort((x, y) => y.stats[role] - x.stats[role]);
      m.innerHTML = `<div class="dialog pickdlg"><b style="font-size:18px">${slotName(room, slot)}</b>
        <div style="font-size:13px;color:var(--muted)">Нужен навык «${ROLE_NAME[role]}» ${ROLE_ICO[role]}. Чем он выше, тем лучше работает место.</div>
        ${list.length ? list.map(c => `<button class="pickrow ${c.location === room && c.slot === slot ? "here" : ""}" onclick="placeCat(${c.cat_id},${room},${slot})">
          <span class="av" style="border-color:${COLORS[c.rarity]}">${CatArt.svg(c.cat_id, "sit", 36)}</span>
          <span class="pt"><b>${c.name} <small>ур. ${c.level}</small></b><small>${catPlace(c)}</small></span>
          <span class="pv">${ROLE_ICO[role]} <b>${d1(c.stats[role])}</b></span></button>`).join("") : `<div class="note">Котов пока нет</div>`}
        ${s.cat_id != null ? `<button class="ghost" style="min-height:44px" onclick="placeCat(${s.cat_id},null,null)">Убрать кота в запас</button>` : ""}
        <button class="ghost" style="min-height:40px;border:none;background:none;color:var(--muted)" onclick="closeModal()">Закрыть</button></div>`;
      m.classList.add("on");
    }
    async function placeCat(id, room, slot) {
      if (busy) return; busy = true;
      try {
        const d = await api("POST", "/api/cats/place", { cat_id: id, room, slot });
        S = d; loadedAt = Date.now(); closeModal(); render();
        const c = catById(id); toast(room == null ? c.name + " отдыхает в запасе" : c.name + ": " + slotName(room, slot));
      } catch (e) { toast(e.message); }
      finally { busy = false; }
    }
    function openCatCard(id) {
      const c = catById(id); if (!c) return;
      const m = document.getElementById("modal"), col = COLORS[c.rarity], mem = c.memories || { n: 0, max: 5, texts: [] };
      const maxV = 24;
      const free = svcSlots().filter(s => S.locations[s.room].open && (s.table == null || s.table_level > 0));
      m.innerHTML = `<div class="dialog catcard">
        <div class="av" style="border-color:${col}">${CatArt.svg(id, "sit", 78)}</div>
        <b style="font-size:21px">${c.name}</b>
        <div style="font-size:12.5px"><span style="color:${col}">${c.rarity_name}</span> · ур. ${c.level} из ${c.max_level} · <span style="color:var(--muted)">${catPlace(c)}</span></div>
        <div class="statbars">${["wait", "cook", "cash", "play"].map(k => `<div class="${k === c.role ? "on" : ""}"><span>${ROLE_ICO[k]} ${ROLE_NAME[k]}</span>
          <i><em style="width:${Math.min(100, c.stats[k] / maxV * 100)}%"></em></i><b>${d1(c.stats[k])}</b></div>`).join("")}</div>
        ${c.feed_cost != null ? `<button class="main pink" id="feedBtn" ${S.treats >= c.feed_cost ? "" : "disabled"}>Покормить · ${c.feed_cost} 🍬 <small style="display:block;font-size:11px;font-weight:600">уровень ${c.level + 1}: навыки +15%${c.level < mem.max ? ", новое воспоминание" : ""}</small></button>
          ${S.treats < c.feed_cost ? `<div style="font-size:12px;color:var(--muted)">У тебя ${S.treats} 🍬. Вкусняшки дают коробка и Десертопад.</div>` : ""}` : `<div class="note">Максимальный уровень</div>`}
        <div class="memhead">История · ${mem.n} из ${mem.max}</div>
        ${mem.texts.map((t, i) => `<div class="memline"><b>${i + 1}</b><span>${t}</span></div>`).join("")}
        ${mem.n < mem.max ? `<div class="memline lock"><b>${mem.n + 1}</b><span>Откроется на ${mem.n + 1} уровне…</span></div>` : ""}
        <div class="memhead">Поставить на место</div>
        <div class="placegrid">${free.map(s => `<button class="${s.room === c.location && s.slot === c.slot ? "here" : ""}" onclick="placeCat(${id},${s.room},${s.slot})">
          <small>${slotName(s.room, s.slot)}</small><b>${ROLE_ICO[s.role]} ${d1(c.stats[s.role])}</b>${s.cat_id != null && s.cat_id !== id ? `<em>${catById(s.cat_id).name}</em>` : ""}</button>`).join("")}
          ${c.location != null ? `<button onclick="placeCat(${id},null,null)"><small>Отдых</small><b>В запас</b></button>` : ""}</div>
        <button class="ghost" style="min-height:40px;border:none;background:none;color:var(--muted)" onclick="closeModal()">Закрыть</button></div>`;
      m.classList.add("on");
      const fb = document.getElementById("feedBtn");
      if (fb) fb.onclick = async () => {
        if (busy) return; busy = true;
        try {
          const d = await api("POST", "/api/cats/feed", { cat_id: id });
          S = d; loadedAt = Date.now(); render(); window.Snd && Snd.play("upgrade"); haptic("medium");
          openCatCard(id); toast(c.name + ": уровень " + d.cat_level + "!");
        } catch (e) { toast(e.message); }
        finally { busy = false; }
      };
    }

    // ---- столики: уровень столика меняет его вид (свеча, цветы) и сколько гостей он приводит ----
    const svcTables = room => (S.service && S.service.tables[String(room)]) || [];
    const tableTier = l => l >= 8 ? 2 : l >= 4 ? 1 : 0;
    function tableRow(room, seats) {
      const ts = svcTables(room), cost = S.service ? S.service.buy_cost : 0;
      TTOP = TABLE_SKIN[styleOf(room, "table")] || ["#A86C46", "#7A4A30"];
      return seats.map((t, i) => {
        const lv = (ts[i] || {}).level || 0;
        if (lv > 0) return loftTable(t.x, t.y, tableTier(lv)) + `<button class="tbadge" style="left:${t.x}%;top:${t.y}%;z-index:${Math.round(t.y) + 2}" onclick="event.stopPropagation();openTable(${room},${i})" aria-label="Столик, уровень ${lv}">ур. ${lv}</button>`;
        return `<button class="tslot ${S.coins >= cost ? "can" : ""}" style="left:${t.x}%;top:${t.y}%;z-index:${Math.round(t.y)}" onclick="event.stopPropagation();buyTable(${room},${i})" aria-label="Купить столик за ${fmt(cost)}"><b>+</b><span><i class="coin s"></i>${fmt(cost)}</span></button>`;
      }).join("");
    }
    async function buyTable(room, seat) {
      if (busy) return; busy = true;
      try { const d = await api("POST", "/api/tables/buy", { room, seat }); S = d; loadedAt = Date.now(); window.Snd && Snd.play("upgrade"); render(); toast("Новый столик: гостей станет больше"); }
      catch (e) { toast(e.message); }
      finally { busy = false; }
    }
    function openTable(room, seat) {
      const t = svcTables(room)[seat], m = document.getElementById("modal");
      const next = t.cost != null ? (t.per_min * 1.4).toFixed(2).replace(".", ",") : null;
      m.innerHTML = `<div class="dialog"><b style="font-size:19px">Столик · ур. ${t.level}</b>
        <div style="font-size:14px;color:var(--muted);line-height:1.5">Приводит <b style="color:var(--ink)">${dec(t.per_min)}</b> гостя в минуту${next ? `, на ${t.level + 1} уровне — <b style="color:var(--mint)">${next}</b>` : ""} — и ещё +10% за каждую единицу навыка официанта.</div>
        ${(() => { const s = svcSlots().find(x => x.room === room && x.table === seat); const c = s && s.cat_id != null ? catById(s.cat_id) : null;
          return c ? `<button class="pickrow" onclick="openSlotPicker(${room},${s.slot})"><span class="av" style="border-color:${COLORS[c.rarity]}">${CatArt.svg(c.cat_id, "sit", 34)}</span><span class="pt"><b>${c.name}</b><small>официант · сейчас ${dec(s.per_min)} гостя/мин</small></span><span class="pv">сменить</span></button>`
                   : s ? `<button class="main" onclick="openSlotPicker(${room},${s.slot})">Поставить официанта</button><div style="font-size:12px;color:#FFB3C1">Без кота столик не работает</div>` : ""; })()}
        ${t.cost != null ? `<button class="main pink" id="tUp" ${S.coins >= t.cost ? "" : "disabled"}>Улучшить · ${fmt(t.cost)}</button>` : `<div class="note">Максимальный уровень</div>`}
        <button class="ghost" style="min-height:40px;border:none;background:none;color:var(--muted)" onclick="closeModal()">Закрыть</button></div>`;
      m.classList.add("on");
      const b = document.getElementById("tUp");
      if (b) b.onclick = async () => {
        if (busy) return; busy = true;
        try { const d = await api("POST", "/api/tables/upgrade", { room, seat }); S = d; loadedAt = Date.now(); window.Snd && Snd.play("upgrade"); render(); openTable(room, seat); }
        catch (e) { toast(e.message); }
        finally { busy = false; }
      };
    }

    // ---- меню и кухня ----
    function neckText() {
      const sv = S.service; if (!sv) return "";
      return {
        cashier: "Нет кассира — продажи стоят. Поставь кота на кассу.",
        cook: "На кухне нет повара — заказы не готовятся. Поставь кота на кухню.",
        waiter: "У столиков нет официантов — гости не приходят. Поставь кота к столику.",
        kitchen: "Кухня не успевает: часть гостей уходит. Прокачай печь и кофемашину в «Меню» или поставь второго повара.",
        guests: "Кухня простаивает: гостей мало. Поставь официанта к новому столику или прокачай столик.",
      }[sv.neck] || "Кухня и гости в балансе.";
    }
    const DISH_ICO = { coffee: "☕", bun: "🥐", donut: "🍩", cupcake: "🧁", macaron: "🍪", cake: "🎂" };
    const DISH_TXT = {
      coffee: "Чёрный, как ночь за окном. Бодрит даже Соню.",
      bun: "Тёплая, с корицей. Батон уверяет, что это его дальняя родственница.",
      donut: "Розовая глазурь и неоновая посыпка. Светится? Нет. Наверное.",
      cupcake: "Маленький, но гордый. С кремовой шапочкой набекрень.",
      macaron: "Хрустит снаружи, тает внутри. Все цвета вывесок квартала.",
      cake: "Три этажа и клубника. Режем только по праздникам — то есть каждый день.",
    };
    function openMenu() {
      const sv = S.service, m = document.getElementById("modal");
      const stars = l => "★".repeat(Math.min(5, Math.ceil(l / 4))) + "☆".repeat(5 - Math.min(5, Math.ceil(l / 4)));
      m.innerHTML = `<div class="paper"><button class="paperx" onclick="closeModal()" aria-label="Закрыть">×</button>
        <div class="phead"><small>старое кафе на Дождевой</small><b>MEOW CAFE</b><span>— меню —</span></div>
        ${sv.menu.map(d => `<div class="pdish"><div class="pline"><span class="pn">${DISH_ICO[d.key] || ""} ${d.name}</span><i></i><span class="pp">${fmt(d.price)}</span></div>
          <div class="pd">${DISH_TXT[d.key] || ""}</div>
          <div class="pl"><span title="Уровень рецепта ${d.level}">${stars(d.level)} рецепт ур. ${d.level}</span>
            ${d.cost != null ? `<button class="pup" data-d="${d.key}" ${S.coins >= d.cost ? "" : "disabled"}>улучшить рецепт · ${fmt(d.cost)} → цена ${fmt(d.next_price)}</button>` : `<span>лучший рецепт</span>`}</div></div>`).join("")}
        ${sv.menu_locked.map(n => `<div class="pdish locked"><div class="pline"><span class="pn">✎ ${n}</span><i></i><span class="pp">?</span></div><div class="pd">Рецепт ещё не найден. Ищи в коробках.</div></div>`).join("")}
        <div class="pfoot">Средний чек гостя — <b>${fmt(sv.check)}</b>. Чем больше блюд в меню, тем больше заказывает гость.<br>Кухню прокачивай на <b>кухне</b> — тапни по печи или кофемашине.</div></div>`;
      m.classList.add("on");
      m.querySelectorAll(".pup").forEach(b => b.onclick = async () => {
        if (busy) return; busy = true;
        try { const d = await api("POST", "/api/menu/upgrade", { dish: b.dataset.d }); S = d; loadedAt = Date.now(); window.Snd && Snd.play("upgrade"); render(); openMenu(); }
        catch (e) { toast(e.message); }
        finally { busy = false; }
      });
    }
    // ---- оборудование кухни: тап по печи, кофемашине, холодильнику ----
    const EQ_TXT = { oven: "Печёт булочки и всё сладкое.", coffee: "Варит кофе. Без неё заказы стоят в очереди.", fridge: "Хранит заготовки — повара работают быстрее." };
    function eqOf(k) { return S.service.kitchen.equip.find(e => e.key === k); }
    function eqBtn(k, inner, style) {
      const e = eqOf(k), can = e.cost != null && S.coins >= e.cost;
      return `<button class="obj eq ${can ? "can" : ""}" data-eq="${k}" style="${style}" onclick="event.stopPropagation();openEquip('${k}')" aria-label="${e.name}, уровень ${e.level}">
        <span class="up">▲</span>${inner}<span class="lvl">${e.name} · ${e.level}</span></button>`;
    }
    function openEquip(k) {
      const e = eqOf(k), sv = S.service, m = document.getElementById("modal");
      m.innerHTML = `<div class="dialog"><b style="font-size:19px">${e.name}${e.level ? " · ур. " + e.level : ""}</b>
        <div style="font-size:14px;color:var(--muted);line-height:1.5">${EQ_TXT[k]}<br>${e.level ? `Сейчас: <b style="color:var(--ink)">${dec(e.per_min)}</b> заказа в минуту, на ${e.level + 1} уровне — <b style="color:var(--mint)">${dec(e.next_per_min)}</b>.` : `Купи — и кухня успеет ещё <b style="color:var(--mint)">${dec(e.next_per_min)}</b> заказа в минуту.`}</div>
        <div class="svcgrid" style="align-self:stretch"><div><small>Вся кухня</small><b>${dec(sv.kitchen_min)}/мин</b></div><div><small>Повара</small><b>+${sv.kitchen.cats_bonus}%</b></div><div><small>Гостей</small><b>${dec(sv.guests_min)}/мин</b></div></div>
        ${e.cost != null ? `<button class="main pink" id="eqUp" ${S.coins >= e.cost ? "" : "disabled"}>${e.level ? "Улучшить" : "Купить"} · ${fmt(e.cost)}</button>` : `<div class="note">Максимальный уровень</div>`}
        <button class="ghost" style="min-height:40px;border:none;background:none;color:var(--muted)" onclick="closeModal()">Закрыть</button></div>`;
      m.classList.add("on");
      const b = document.getElementById("eqUp");
      if (b) b.onclick = async () => {
        if (busy) return; busy = true;
        try { const d = await api("POST", "/api/equip/upgrade", { item: k }); S = d; loadedAt = Date.now(); window.Snd && Snd.play("upgrade"); render(); openEquip(k); }
        catch (err) { toast(err.message); }
        finally { busy = false; }
      };
    }
    function openPlayroom() {
      const pr = S.service.playroom, m = document.getElementById("modal");
      m.innerHTML = `<div class="dialog"><b style="font-size:19px">Игровая · ур. ${pr.level}</b>
        <div style="font-size:14px;color:var(--muted);line-height:1.5">Гости платят за вход <b style="color:var(--ink)">${fmt(pr.ticket)}</b> и играют с котами. Чем сильнее навык «игрок» у котов здесь, тем больше гостей. Сейчас игровая даёт <b style="color:var(--gold)">+${dec(S.service.play)}/сек</b>.</div>
        ${pr.cost != null ? `<button class="main pink" id="prUp" ${S.coins >= pr.cost ? "" : "disabled"}>Улучшить · ${fmt(pr.cost)}</button>` : ""}
        <button class="ghost" style="min-height:40px;border:none;background:none;color:var(--muted)" onclick="closeModal()">Закрыть</button></div>`;
      m.classList.add("on");
      const b = document.getElementById("prUp");
      if (b) b.onclick = async () => { try { const d = await api("POST", "/api/equip/upgrade", { item: "play" }); S = d; loadedAt = Date.now(); render(); openPlayroom(); } catch (e) { toast(e.message); } };
    }

    function objBtn(kind, label, inner, style) {
      const u = upg(kind);
      return `<button class="obj" data-kind="${kind}" style="${style}" onclick="event.stopPropagation();openUpgrades('${kind}')" aria-label="${label}, уровень ${u.level}">
        <span class="up">▲</span>${inner}<span class="lvl">${label} · ${u.level}</span></button>`;
    }
    function showcaseSvg() {
      return `<svg width="58" height="46" viewBox="0 0 58 46" aria-hidden="true"><rect x="2" y="8" width="54" height="34" rx="6" fill="rgba(160,220,255,.18)" stroke="#9FE8FF" stroke-width="1.5"/>
        <rect x="2" y="40" width="54" height="6" rx="2" fill="#6B3F2A"/><ellipse cx="16" cy="34" rx="9" ry="3" fill="#EDEAFF"/><path d="M9 33 L16 22 L23 33 Z" fill="#F5D7A8"/><path d="M9 33 h14 v-3 h-14z" fill="#FF8FC4"/><circle cx="16" cy="22" r="2" fill="#FF3B5C"/>
        <circle cx="34" cy="31" r="6" fill="#E8A060"/><circle cx="34" cy="31" r="4.6" fill="#FF8FC4"/><circle cx="34" cy="31" r="1.6" fill="#3A2A40"/>
        <ellipse cx="47" cy="34" rx="6" ry="3" fill="#B388FF"/><ellipse cx="47" cy="31" rx="6" ry="3" fill="#FFC94D"/><ellipse cx="47" cy="28" rx="6" ry="3" fill="#7FE0B5"/>
        <path d="M6 12 h46" stroke="#fff" stroke-width="1.5" opacity=".4"/></svg>`;
    }
    function drawCounter() {
      const el = document.getElementById("counterItems");
      if (!el) return;
      el.innerHTML = `<button class="obj" style="left:2%;bottom:calc(100% - 12px);z-index:2" onclick="event.stopPropagation();openMenu()" aria-label="Витрина с десертами — открыть меню">${showcaseSvg()}<span class="lvl">Меню</span></button>`
        + objBtn("cash", "Касса", registerSvg(tierOf("cash")), "right:1%;bottom:calc(100% - 12px);z-index:2");
    }
    function updateUpgradeHints() {     // золотая стрелка над предметом, если на улучшение хватает мяуконов
      if (!roomEl || !S) return;
      roomEl.querySelectorAll(".obj[data-kind]").forEach(b => { const u = upg(b.dataset.kind); b.classList.toggle("can", !u.maxed && S.coins >= u.cost); });
      roomEl.querySelectorAll(".obj[data-eq]").forEach(b => { const e = eqOf(b.dataset.eq); b.classList.toggle("can", e.cost != null && S.coins >= e.cost); });
      if (S.service) roomEl.querySelectorAll(".tslot[onclick*=buyTable]").forEach(b => b.classList.toggle("can", S.coins >= S.service.buy_cost));
    }


    // ================= Лофт под дождём: окно в киберпанк-город =================
    function cwRnd(seed) { let a = seed; return () => { a = (a * 1664525 + 1013904223) % 4294967296; return a / 4294967296; }; }
    function cwSkyline(r, base, far, mid, near) {
      const W = 400, H = 220, out = [];
      const layer = (b, hmin, hmax, wmin, wmax, col, winCol, winP, signs) => {
        let x = -10;
        while (x < W) {
          const w = wmin + r() * (wmax - wmin), h = hmin + r() * (hmax - hmin), y = b - h;
          out.push(`<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${(H - y).toFixed(1)}" fill="${col}"/>`);
          if (r() < 0.3) out.push(`<rect x="${(x + w / 2 - 1).toFixed(1)}" y="${(y - 14).toFixed(1)}" width="2" height="14" fill="${col}"/><circle cx="${(x + w / 2).toFixed(1)}" cy="${(y - 15).toFixed(1)}" r="1.6" fill="#FF3B5C" class="blinkred"/>`);
          for (let wy = y + 6; wy < H - 4; wy += 7) for (let wx = x + 4; wx < x + w - 4; wx += 6)
            if (r() < winP) out.push(`<rect x="${wx.toFixed(1)}" y="${wy.toFixed(1)}" width="2.6" height="3.4" fill="${winCol[Math.floor(r() * winCol.length)]}" opacity="${(0.45 + r() * 0.55).toFixed(2)}"/>`);
          if (signs && r() < 0.45 && w > 22) {
            const c = ["#FF2E88", "#21E6FF", "#B44DFF", "#FFC23D"][Math.floor(r() * 4)], sy = y + 10 + r() * 30;
            out.push(`<rect x="${(x + 4).toFixed(1)}" y="${sy.toFixed(1)}" width="7" height="${(18 + r() * 22).toFixed(1)}" rx="1.5" fill="${c}" opacity=".85" class="flick" style="animation-delay:${(r() * 6).toFixed(1)}s"/>`);
          }
          x += w + r() * 3;
        }
      };
      layer(base - 40, 50, 130, 20, 46, far, ["#3A3466"], 0.12, false);
      layer(base - 10, 30, 110, 22, 44, mid, ["#FFD27A", "#7FE8FF", "#FF8AC4"], 0.22, true);
      layer(base + 20, 10, 70, 28, 54, near, ["#FFD27A", "#7FE8FF"], 0.12, true);
      return out.join("");
    }
    const cwHover = (color, light) => `<svg width="38" height="14" viewBox="0 0 38 14" aria-hidden="true"><ellipse cx="19" cy="12" rx="14" ry="2" fill="${light}" opacity=".45"/>
      <path d="M3 8 Q6 2 16 2 H24 Q32 2 35 8 Z" fill="${color}"/><path d="M12 3 h11 l3 4 h-16 Z" fill="#9FD8FF" opacity=".6"/>
      <rect x="1" y="8" width="36" height="3" rx="1.5" fill="${color}"/><circle cx="36" cy="9" r="1.6" fill="#FFF6C9"/><circle cx="2" cy="9" r="1.4" fill="#FF3B5C"/></svg>`;
    // наш красный летающий кабриолет, за рулём кот в очках
    const cwRoadster = () => `<svg width="104" height="40" viewBox="0 0 104 40" aria-hidden="true">
      <ellipse cx="52" cy="36" rx="40" ry="3.5" fill="#FF4D6D" opacity=".35"/><path d="M30 14 q4 -10 12 -8 q6 1 6 8" fill="#FFC23D"/>
      <g transform="translate(36 2)"><path d="M2 12 L0 0 L8 7 Z M16 12 L18 0 L10 7 Z" fill="#F2A65A"/><ellipse cx="9" cy="13" rx="9" ry="8" fill="#F2A65A"/><rect x="2" y="10" width="14" height="4" rx="2" fill="#140F2A"/><path d="M5 18 q4 2 8 0" stroke="#140F2A" stroke-width="1.2" fill="none"/></g>
      <path d="M4 26 Q8 16 24 16 L40 16 Q48 22 66 20 L90 20 Q100 22 102 28 L100 32 H6 Z" fill="#E21B3C"/><path d="M24 16 L34 8 L40 16 Z" fill="#9FD8FF" opacity=".55"/>
      <path d="M8 24 H96" stroke="#FF6B85" stroke-width="1.5"/><rect x="92" y="23" width="9" height="3" rx="1.5" fill="#FFF6C9"/><rect x="3" y="24" width="6" height="3" rx="1.5" fill="#FF3B5C"/>
      <ellipse cx="24" cy="32" rx="9" ry="3" fill="#21E6FF" opacity=".8"/><ellipse cx="82" cy="32" rx="9" ry="3" fill="#21E6FF" opacity=".8"/>
      <path d="M-30 28 H4" stroke="#FF4D6D" stroke-width="2" opacity=".5"/><path d="M-50 24 H0" stroke="#21E6FF" stroke-width="1" opacity=".35"/></svg>`;
    function cityWindow(seed) {
      const r = cwRnd(seed);
      let h = `<div class="cw" data-cw style="left:40%;top:7%;width:56%;height:40%;border:7px solid #3B2A22;border-radius:6px;box-shadow:inset 0 0 24px rgba(0,0,0,.7)">
        <div style="position:absolute;inset:0;background:linear-gradient(#060B1C,#0E2340 65%,#1A3E66)"></div>
        <svg style="position:absolute;left:0;bottom:0;width:100%;height:100%" viewBox="0 0 400 220" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
          <defs><radialGradient id="cwHaze" cx="50%" cy="100%" r="70%"><stop offset="0" stop-color="#21E6FF" stop-opacity=".45"/><stop offset="1" stop-color="#21E6FF" stop-opacity="0"/></radialGradient></defs>
          <rect x="0" y="40" width="400" height="180" fill="url(#cwHaze)"/>${cwSkyline(r, 205, "#13243F", "#0C1830", "#070F20")}
          <g class="holo"><rect x="40" y="70" width="64" height="34" rx="3" fill="#0B0A18" stroke="#21E6FF" stroke-width="1.5"/>
            <text x="72" y="85" text-anchor="middle" font-size="10" font-weight="800" fill="#21E6FF" font-family="sans-serif">NEKO</text>
            <text x="72" y="97" text-anchor="middle" font-size="7" font-weight="700" fill="#FF2E88" font-family="sans-serif">COFFEE 24/7</text></g></svg>`;
      [[22, 8, 2, 1, "#1E2A44"], [40, 12, 5, 0, "#26324E"], [58, 10, 8, 1, "#1A2238"]].forEach(([top, dur, delay, rev, col], i) =>
        h += `<div class="car ${rev ? "rev" : ""}" style="top:${top}%;animation-duration:${dur}s;animation-delay:-${delay}s;opacity:${0.55 + i * 0.2}">${cwHover(col, rev ? "#FF2E88" : "#21E6FF")}</div>`);
      h += `<div class="roadster" style="top:30%;animation-delay:-2s">${cwRoadster()}</div>`;
      for (let i = 0; i < 46; i++) h += `<div class="cdrop" style="left:${(r() * 100).toFixed(1)}%;height:${(12 + r() * 16).toFixed(0)}px;animation-duration:${(1.1 + r() * 0.6).toFixed(2)}s;animation-delay:-${(r() * 1.7).toFixed(2)}s"></div>`;
      for (let i = 0; i < 26; i++) { const sz = 2 + r() * 4; h += `<div class="gdrop" style="left:${(r() * 100).toFixed(1)}%;top:${(r() * 100).toFixed(1)}%;width:${sz.toFixed(1)}px;height:${(sz * 1.2).toFixed(1)}px"></div>`; }
      for (let i = 0; i < 5; i++) h += `<div class="trick" style="left:${(8 + r() * 84).toFixed(1)}%;top:${(r() * 40).toFixed(1)}%;height:${(14 + r() * 18).toFixed(0)}px;animation-delay:-${(r() * 6).toFixed(1)}s"></div>`;
      return h + `<div class="glare"></div><div style="position:absolute;left:33%;top:0;bottom:0;width:4px;background:#3B2A22"></div><div style="position:absolute;left:66%;top:0;bottom:0;width:4px;background:#3B2A22"></div><div style="position:absolute;left:0;right:0;top:55%;height:4px;background:#3B2A22"></div></div>`;
    }
    function fitCityWindow() { document.querySelectorAll("[data-cw]").forEach(w => w.style.setProperty("--w", (w.clientWidth + 20) + "px")); }
    const edison = (x, len, delay) => `<div class="table" style="left:${x}%;top:0;z-index:5;transform:translateX(-50%)"><svg width="40" height="${len + 30}" viewBox="0 0 40 ${len + 30}" aria-hidden="true" style="overflow:visible">
      <defs><radialGradient id="edG${x}"><stop offset="0" stop-color="#FFB060" stop-opacity=".45"/><stop offset=".5" stop-color="#FFB060" stop-opacity=".12"/><stop offset="1" stop-color="#FFB060" stop-opacity="0"/></radialGradient></defs>
      <g class="lampglow" style="animation-delay:${delay}s"><circle cx="20" cy="${len + 16}" r="60" fill="url(#edG${x})"/></g><rect x="19" y="0" width="2" height="${len}" fill="#1A0E0E"/><rect x="15" y="${len - 2}" width="10" height="6" rx="1" fill="#2A1A10"/>
      <ellipse cx="20" cy="${len + 14}" rx="9" ry="11" fill="#FFD27A" opacity=".92"/><path d="M17 ${len + 10} q3 6 6 0" stroke="#FF8A2E" stroke-width="1.4" fill="none"/></svg></div>`;
    let TTOP = ["#A86C46", "#7A4A30"];
    const TABLE_SKIN = { table_marble: ["#F2F0F6", "#BDB8CC"], table_pink: ["#FF9EC4", "#C2316E"] };
    function loftTable(x, y, t) {
      // t — уровень «Столиков» (0..2): с прокачкой появляются свеча, цветы и неоновая кромка
      const glow = t === 2 ? "#FFC94D" : t === 1 ? "#FF5CA8" : "#21E6FF";
      const stool = (cx, col) => `<ellipse cx="${cx}" cy="86" rx="13" ry="3" fill="#000" opacity=".3"/>
        <rect x="${cx - 2}" y="62" width="4" height="23" fill="#2A1A14"/><ellipse cx="${cx}" cy="85" rx="9" ry="2.4" fill="#2A1A14"/>
        <ellipse cx="${cx}" cy="60" rx="14" ry="5.5" fill="${col}" opacity=".75"/><ellipse cx="${cx}" cy="57" rx="14" ry="5.5" fill="${col}"/>
        <ellipse cx="${cx - 4}" cy="55.5" rx="6" ry="1.6" fill="#fff" opacity=".25"/>`;
      return piece(x, y, 136, 92, `
        <defs><radialGradient id="tg${x}${y}"><stop offset="0" stop-color="${glow}" stop-opacity=".55"/><stop offset="1" stop-color="${glow}" stop-opacity="0"/></radialGradient>
          <linearGradient id="tt${x}${y}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${TTOP[0]}"/><stop offset="1" stop-color="${TTOP[1]}"/></linearGradient></defs>
        <ellipse cx="68" cy="86" rx="46" ry="7" fill="url(#tg${x}${y})"/>
        ${stool(16, "#2C8C9C")}${stool(120, "#B0457A")}
        <ellipse cx="68" cy="87" rx="20" ry="3.5" fill="#000" opacity=".35"/>
        <path d="M64 40 h8 l3 44 h-14 Z" fill="#2E2A3E"/><ellipse cx="68" cy="85" rx="17" ry="4" fill="#3A3550"/><ellipse cx="68" cy="84" rx="17" ry="3.4" fill="#4A4562"/>
        <ellipse cx="68" cy="40" rx="44" ry="11" fill="#4A2A1C"/>
        <ellipse cx="68" cy="37" rx="44" ry="11" fill="url(#tt${x}${y})"/>
        <ellipse cx="68" cy="37" rx="44" ry="11" fill="none" stroke="${glow}" stroke-width="${t ? 1.6 : 0.8}" opacity="${t ? 0.9 : 0.4}"/>
        <ellipse cx="54" cy="33" rx="18" ry="3" fill="#fff" opacity=".12"/>
        <g transform="translate(40 20)"><path d="M0 4 h13 l-2 11 h-9 Z" fill="#F4EDE4"/><path d="M13 6 q5 1 0 6" stroke="#F4EDE4" stroke-width="1.8" fill="none"/><ellipse cx="6.5" cy="4" rx="6.5" ry="1.8" fill="#6B3F2A"/></g>${steam(46, 16)}
        <g transform="translate(72 26)"><ellipse cx="9" cy="9" rx="11" ry="3" fill="#EDEAFF"/><path d="M2 8 L9 1 L16 8 Z" fill="#F5D7A8"/><path d="M2 8 L16 8 L16 5 L2 5 Z" fill="#FF8FC4"/><circle cx="9" cy="1" r="1.8" fill="#FF3B5C"/></g>
        ${t ? `<rect x="96" y="20" width="5" height="12" rx="1.5" fill="#F4EDE4"/><path d="M98.5 14 q3 3 0 6 q-3 -3 0 -6" fill="#FFD27A"/><circle cx="98.5" cy="17" r="10" fill="#FFB060" opacity=".18"/>` : ""}
        ${t === 2 ? `<rect x="24" y="22" width="6" height="12" rx="2" fill="#21E6FF" opacity=".55"/><circle cx="24" cy="19" r="3.4" fill="#FF2E88"/><circle cx="30" cy="17" r="3.4" fill="#FFC94D"/><circle cx="27" cy="14" r="3" fill="#B388FF"/>` : ""}`, "", 1);
    }

    let decorLoc = -1;
    function drawDecor() {
      const key = curLoc + ":" + (S.upgrades || []).map(u => u.level).join(",") + ":" + JSON.stringify(S.service ? [S.service.tables, (S.service.decor || []).filter(d => d.have).map(d => d.key), (S.service.menu || []).length] : "") + JSON.stringify(svcSlots().map(s => s.cat_id)) + JSON.stringify(S.service ? [S.service.style, S.service.playroom.level] : "") + (S.service ? S.service.kitchen.equip.map(e => e.level).join(",") : "");
      if (decorLoc === key) return;
      decorLoc = key;
      roomEl.classList.toggle("loft", curLoc === 0);
      drawCounter();
      document.getElementById("roomDecor").innerHTML = LOC_DECOR[curLoc].html();
      requestAnimationFrame(fitCityWindow);
      // гости прошлой локации «остаются там»: запоминаем их и вернём, когда игрок вернётся
      for (const g of ambient.splice(0)) { (guestMem[g.loc] = guestMem[g.loc] || []).push(g); g.el.remove(); }
      const now = Date.now(), back = (guestMem[curLoc] || []).filter(g => g.leaveAt > now + 1500);
      guestMem[curLoc] = [];
      for (const g of back) placeGuest(g.table, g.look, g.leaveAt, true);
    }
    const guestMem = {};   // локация → гости, которые там сидели

    let switching = false;
    let roomEl = null, baristaEl = null, baristaSwap = null, roomShown = false;
    const walkers = new Map();   // cat_id → {el, x, y, dir, held, pausedUntil}
    const ambient = [];          // обычные гости: {el, table, look, leaveAt, loc}
    const catMem = new Map();    // cat_id → {x, y, dir, loc}: где кот стоял, когда игрок ушёл с локации

    function catSprite(color, pose, size) {
      if (typeof color === "number") return CatArt.svg(color, pose, size);   // новые спрайты: передан номер кота
      if (pose === "sit") return catSvg(color, size);
      const shade = color;
      return `<svg width="${size}" height="${size * 0.8}" viewBox="0 0 70 56" aria-hidden="true">
        <path d="M12 34 Q2 26 6 12" fill="none" stroke="${color}" stroke-width="5" stroke-linecap="round"/>
        <ellipse cx="30" cy="36" rx="20" ry="13" fill="${color}"/>
        <rect x="16" y="42" width="5" height="12" rx="2" fill="${color}"/><rect x="24" y="43" width="5" height="11" rx="2" fill="${shade}" opacity=".7"/>
        <rect x="36" y="43" width="5" height="11" rx="2" fill="${shade}" opacity=".7"/><rect x="43" y="42" width="5" height="12" rx="2" fill="${color}"/>
        <circle cx="52" cy="24" r="12" fill="${color}"/><path d="M43 16 L44 4 L52 12 Z" fill="${color}"/><path d="M54 12 L62 4 L62 17 Z" fill="${color}"/>
        <circle cx="57" cy="22" r="2.2" fill="#140F2A"/><circle cx="63" cy="27" r="1.4" fill="#FF8FC4"/></svg>`;
    }
    // Гости: горожане в дождевиках и худи с неоновыми деталями. look = [кожа, волосы, одежда, неон, причёска]
    function guestSvg(look) {
      const [skin, hair, coat, neon, style] = look;
      const hairSvg = {
        bob: `<path d="M8 16 Q8 2 20 2 Q32 2 32 16 L32 22 Q28 14 20 13 Q12 14 8 22 Z" fill="${hair}"/>`,
        spiky: `<path d="M8 15 L10 5 L14 10 L17 1 L21 9 L25 2 L27 10 L31 6 L32 16 Q20 9 8 16 Z" fill="${hair}"/>`,
        hood: `<path d="M5 22 Q4 2 20 1 Q36 2 35 22 L35 30 L30 30 Q32 12 20 11 Q8 12 10 30 L5 30 Z" fill="${coat}"/><path d="M8 26 Q8 8 20 7 Q32 8 32 26" stroke="${neon}" stroke-width="1.4" fill="none"/>`,
        cap: `<path d="M8 13 Q9 3 20 3 Q31 3 32 13 Z" fill="${hair}"/><rect x="18" y="10" width="17" height="4" rx="2" fill="${hair}"/><rect x="12" y="6" width="9" height="3" rx="1.5" fill="${neon}"/>`,
        bun: `<circle cx="20" cy="2" r="5" fill="${hair}"/><path d="M8 16 Q8 4 20 4 Q32 4 32 16 Q26 9 20 9 Q14 9 8 16 Z" fill="${hair}"/>`,
        long: `<path d="M7 34 Q4 4 20 3 Q36 4 33 34 L29 34 Q31 14 20 12 Q9 14 11 34 Z" fill="${hair}"/>`,
        mohawk: `<path d="M17 9 L18 -4 L20 2 L22 -5 L23 9 Z" fill="${neon}"/><path d="M9 14 Q10 7 14 6 M31 14 Q30 7 26 6" stroke="${hair}" stroke-width="2" fill="none"/>`,
        afro: `<circle cx="20" cy="10" r="13" fill="${hair}"/><circle cx="9" cy="14" r="5" fill="${hair}"/><circle cx="31" cy="14" r="5" fill="${hair}"/>`,
        pony: `<path d="M8 15 Q8 3 20 3 Q32 3 32 15 Q26 9 20 9 Q14 9 8 15 Z" fill="${hair}"/><path d="M31 9 Q42 12 36 28 Q34 18 30 14 Z" fill="${hair}"/><rect x="30" y="8" width="4" height="4" rx="1" fill="${neon}"/>`,
        beanie: `<path d="M8 15 Q8 1 20 1 Q32 1 32 15 Z" fill="${coat}"/><rect x="7" y="12" width="26" height="5" rx="2" fill="${neon}"/><circle cx="20" cy="0" r="3" fill="${neon}"/>`,
        buzz: `<path d="M9 14 Q9 5 20 5 Q31 5 31 14 Q26 10 20 10 Q14 10 9 14 Z" fill="${hair}" opacity=".85"/>`,
      }[style] || "";
      const extra = look[5] || "";
      const extraSvg = {
        glasses: `<circle cx="16.5" cy="18" r="3.4" fill="none" stroke="#140F2A" stroke-width="1.3"/><circle cx="23.5" cy="18" r="3.4" fill="none" stroke="#140F2A" stroke-width="1.3"/><path d="M19.9 18 h0.2" stroke="#140F2A" stroke-width="1.3"/>`,
        visor: `<rect x="10" y="15.5" width="20" height="5" rx="2.5" fill="#0B0A18"/><rect x="12" y="17" width="16" height="2" rx="1" fill="${neon}"/>`,
        phones: `<path d="M8 17 Q8 4 20 4 Q32 4 32 17" stroke="${neon}" stroke-width="2" fill="none"/><rect x="6" y="15" width="4" height="7" rx="2" fill="${neon}"/><rect x="30" y="15" width="4" height="7" rx="2" fill="${neon}"/>`,
        mask: `<path d="M12 21 Q20 27 28 21 L28 25 Q20 30 12 25 Z" fill="#0B0A18"/><path d="M15 24 h10" stroke="${neon}" stroke-width="1"/>`,
        earring: `<circle cx="9" cy="21" r="1.6" fill="${neon}"/><circle cx="31" cy="21" r="1.6" fill="${neon}"/>`,
        beard: `<path d="M11 20 Q12 29 20 29 Q28 29 29 20 Q26 25 20 25 Q14 25 11 20 Z" fill="${hair}"/>`,
      }[extra] || "";
      return `<svg width="44" height="70" viewBox="0 0 40 64" aria-hidden="true" style="overflow:visible">
        <ellipse cx="20" cy="62" rx="13" ry="2.5" fill="#000" opacity=".3"/>
        <path d="M6 62 V40 Q6 28 20 28 Q34 28 34 40 V62 Z" fill="${coat}"/>
        <path d="M20 30 V62" stroke="#000" stroke-opacity=".25" stroke-width="1.2"/><path d="M6 46 H34" stroke="${neon}" stroke-width="1.6" opacity=".9"/>
        <rect x="27" y="40" width="9" height="11" rx="2" fill="#F2EEFF"/><rect x="27" y="42" width="9" height="2" fill="${neon}"/>
        <circle cx="20" cy="17" r="11" fill="${skin}"/>
        ${hairSvg}
        <circle cx="16.5" cy="18" r="1.6" fill="#140F2A"/><circle cx="23.5" cy="18" r="1.6" fill="#140F2A"/>
        <ellipse cx="14" cy="21.5" rx="2" ry="1.2" fill="#FF8FC4" opacity=".5"/><ellipse cx="26" cy="21.5" rx="2" ry="1.2" fill="#FF8FC4" opacity=".5"/>
        <path d="M18 23 q2 1.5 4 0" stroke="#140F2A" stroke-width="1.2" fill="none" stroke-linecap="round"/>${extraSvg}</svg>`;
    }
    const scaleAt = (y) => (0.7 + (y - 55) / 40 * 0.3).toFixed(2);

    function buildRoom() {
      roomEl = document.createElement("div");
      roomEl.id = "room";
      roomEl.innerHTML = `<div id="roomDecor" style="position:absolute;inset:0"></div>
        <div class="sign" id="roomSign"><b>MEOW</b><span>CAFE</span></div>
        <div class="counter" id="roomCounter"><div id="counterItems"></div>
          <button class="baristaBtn" onclick="openSlotPicker(0,0)" aria-label="Кто на кассе"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h13l-3-3M20 17H7l3 3"/></svg><span id="baristaLabel" hidden></span></button></div>
        <div class="lock" id="roomLock"><div id="roomLockBody"></div></div>
        <button class="upBtn" onclick="openUpgrades()" aria-label="Улучшения кафе">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5M6 11l6-6 6 6"/></svg>Улучшить</button>`;
      // свайп по комнате — переход между локациями
      let swipeX = null;
      roomEl.addEventListener("pointerdown", (e) => { if (!e.target.closest(".cat")) swipeX = e.clientX; });
      roomEl.addEventListener("pointerup", (e) => {
        if (swipeX === null) return;
        const dx = e.clientX - swipeX; swipeX = null;
        if (Math.abs(dx) > 60) switchLoc(dx < 0 ? 1 : -1);
      });
      baristaEl = document.createElement("button");
      baristaEl.className = "ent idle";
      baristaEl.style.cssText = "left:30%;top:45%;z-index:25;transition:none";
      baristaEl.onclick = () => { if (baristaEl.dataset.id) openCatCard(Number(baristaEl.dataset.id)); };   // тап по кассиру — его карточка
      roomEl.appendChild(baristaEl);
      setInterval(wander, 3800);
      setInterval(spawnGuest, 1800);
      setInterval(catAction, 2200);
    }

    function catById(id) { return S.cats.find(c => String(c.cat_id) === String(id)); }

    function mountRoom() {
      if (!roomEl) buildRoom();
      const slot = document.getElementById("roomSlot");
      if (slot) slot.replaceWith(roomEl);
      syncRoom();
    }

    function syncRoom() {
      const L = S.locations[curLoc], look = LOC_LOOK[curLoc];
      drawDecor();
      document.getElementById("roomSign").innerHTML = `<b>${look.sign[0]}</b><span>${look.sign[1]}</span>`;
      document.getElementById("roomSign").style.display = curLoc === 1 ? "none" : "";   // на кухне вместо вывески — окно
      document.getElementById("roomCounter").style.display = curLoc === 0 ? "" : "none";
      updateUpgradeHints();
      const lock = document.getElementById("roomLock");
      lock.classList.toggle("on", !L.open);
      if (!L.open) {
        const prev = S.locations[curLoc - 1];
        const info = `<b style="font-size:17px">${L.name}</b><div style="font-size:13px;color:var(--muted)">${{ 2: "Ещё 3 столика для котов-официантов", 3: "Гости платят за вход и играют с котами" }[curLoc] || ""}</div>`;
        document.getElementById("roomLockBody").innerHTML = !L.level_ok
          ? info + `<div class="needlvl">Откроется на <b>${L.need_level} уровне</b> кафе</div>`
          : L.next
          ? info + `<button class="main" style="background:var(--gold);color:#3A2A00;min-height:48px" onclick="openLocation()">Открыть за ${fmt(L.price)}</button>`
          : info + `<div style="font-size:13px;color:var(--muted)">Сначала открой «${prev.name}»</div>`;
      }
      const cafe = S.cats.filter(c => c.location === curLoc);
      const barista = curLoc !== 0 ? null : cafe.find(c => c.cat_id === S.barista_cat_id);
      // бариста
      if (barista) {
        baristaEl.style.display = "flex";
        const prevId = baristaEl.dataset.id;
        if (prevId !== String(barista.cat_id)) {
          baristaEl.dataset.id = barista.cat_id;
          baristaEl.innerHTML = `<div class="pose">${catSprite(barista.cat_id, "sit", 68)}</div>`;
          if (prevId && baristaEl.animate) baristaEl.animate([{ opacity: 0, transform: "translate(-50%,-80%) scale(.8)" }, { opacity: 1, transform: "translate(-50%,-100%) scale(1)" }], { duration: 420, easing: "ease-out" });
          if (prevId) baristaSwap = Number(prevId);   // прежний бариста спрыгнет со стойки в зал
        }
        document.getElementById("baristaLabel").textContent = "Кассир: " + barista.name + " · 💰 " + d1(barista.stats.cash);
      } else { baristaEl.style.display = "none"; if (curLoc === 0) document.getElementById("baristaLabel").textContent = "+ кассир"; }
      // остальные коты гуляют
      const homeOf = c => (SLOT_POS[c.location] || [])[c.slot] || { x: 50, y: 80 };
      const want = new Set(cafe.filter(c => c.slot != null && (!barista || c.cat_id !== barista.cat_id)).map(c => c.cat_id));
      for (const [id, w] of walkers) if (!want.has(id)) {   // уходящий кот плавно растворяется
        walkers.delete(id);
        catMem.set(id, { x: w.x, y: w.y, dir: w.dir, loc: w.loc });
        if (w.el.animate) w.el.animate([{ opacity: 1 }, { opacity: 0, transform: "translate(-50%,-100%) scale(.7)" }], { duration: 320, easing: "ease-in" }).finished.then(() => w.el.remove()).catch(() => w.el.remove());
        else w.el.remove();
      }
      for (const c of cafe) {
        if (!want.has(c.cat_id)) continue;
        let w = walkers.get(c.cat_id);
        if (!w) {
          const h = homeOf(c);
          w = { x: h.x, y: h.y, dir: h.x > 50 ? -1 : 1, held: false, pausedUntil: 0 };
          w.loc = curLoc; w.restored = true; baristaSwap = null;
          w.el = document.createElement("button");
          w.el.className = "ent cat idle";
          w.el.style.transition = "none";
          attachDrag(w, c.cat_id);
          roomEl.appendChild(w.el);
          walkers.set(c.cat_id, w);
          requestAnimationFrame(() => { w.el.style.transition = ""; });
          if (roomShown && !switching && !w.restored && w.el.animate) w.el.animate([{ opacity: 0, transform: "translate(-50%,-70%) scale(.7)" }, { opacity: 1, transform: "translate(-50%,-100%) scale(1)" }], { duration: 450, easing: "ease-out" });
        }
        const h = homeOf(c);
        if (!w.cat || w.cat.slot !== c.slot) { w.x = h.x; w.y = h.y; }
        w.home = h;
        w.cat = c;
        w.el.setAttribute("aria-label", c.name + ": тап — погладить и карточка кота");
        drawWalker(w);
      }
      roomShown = true;
    }

    function drawWalker(w) {
      const c = w.cat, col = COLORS[c.rarity];
      const walking = w.el.classList.contains("walk");
      w.el.style.left = w.x.toFixed(1) + "%";
      w.el.style.top = w.y.toFixed(1) + "%";
      w.el.style.zIndex = w.held ? 130 : Math.round(w.y);
      w.el.innerHTML = `<div class="body" style="transform:scale(${scaleAt(w.y)});transform-origin:50% 100%"><div class="pose">
          <div style="transform:scaleX(${w.dir})">${catSprite(c.cat_id, walking ? "walk" : "sit", walking ? 86 : 70)}</div></div></div>
        <span class="label" style="color:${col}">${c.role ? ROLE_ICO[c.role] + " " : ""}${c.name}${c.level > 1 ? " · " + c.level : ""}</span>`;
    }

    // Маленькие действия на месте: прыжок, оглянуться, эмоция над головой
    const CAT_EMOTES = { 5: ["💤", "💤", "z"], 0: ["🍞", "…", "💤"], 9: ["♪", "♫", "🎧"], 16: ["</>", "01", "?"], 17: ["😎", "🏁", "!"], 13: ["🔥", "✨"], 8: ["🌙", "✨", "…"], 12: ["⚙", "!", "?"] };
    function catEmote(w, text) {
      if (!roomEl || !w.el.isConnected) return;
      const e = document.createElement("span");
      e.className = "catemo"; e.textContent = text;
      e.style.cssText = `left:${w.x}%;top:${w.y - 13}%`;
      roomEl.appendChild(e); setTimeout(() => e.remove(), 1700);
    }
    function catAction() {
      if (document.body.classList.contains("ingame")) return;
      if (!roomEl || view !== "cafe" || document.hidden) return;
      const idle = [...walkers.values()].filter(w => !w.held && !w.el.classList.contains("walk"));
      if (!idle.length || Math.random() < 0.3) return;
      const w = idle[Math.floor(Math.random() * idle.length)];
      const r = Math.random(), pose = w.el.querySelector(".pose");
      if (r < 0.35 && pose && pose.animate) {
        pose.animate([{ transform: "translateY(0)" }, { transform: "translateY(-10px) scale(1.04,.96)" }, { transform: "translateY(0)" }], { duration: 380, easing: "ease-out" });
      } else if (r < 0.6) {
        w.dir = -w.dir; drawWalker(w);
      } else {
        const em = CAT_EMOTES[w.cat.cat_id] || ["♪", "!", "?", "…", "♥", "мяу"];
        catEmote(w, em[Math.floor(Math.random() * em.length)]);
      }
    }

    function wander() {   // коты на работе: переминаются у своего места
      if (document.body.classList.contains("ingame")) return;
      const now = Date.now();
      for (const w of walkers.values()) {
        if (w.held || w.pausedUntil > now || w.el.classList.contains("walk") || Math.random() < 0.6 || !w.home) continue;
        const x = Math.max(8, Math.min(92, w.home.x + (Math.random() - .5) * 10)), y = Math.max(55, Math.min(96, w.home.y + (Math.random() - .5) * 4));
        w.dir = x < w.x ? -1 : 1; w.x = x; w.y = y;
        setPose(w, true);
        setTimeout(() => setPose(w, false), 1600);
      }
    }
    function setPose(w, walking) { w.el.classList.toggle("walk", walking); w.el.classList.toggle("idle", !walking); drawWalker(w); }

    function attachDrag(w, id) {   // тап — погладить (перетаскивания больше нет: место выбирается в карточке)
      let d = null;
      w.el.addEventListener("pointerdown", (e) => { e.preventDefault(); e.stopPropagation(); d = { sx: e.clientX, sy: e.clientY }; });
      const end = (e) => { if (!d) return; if (Math.abs(e.clientX - d.sx) + Math.abs(e.clientY - d.sy) < 12) petCat(w); d = null; };
      w.el.addEventListener("pointerup", end);
      w.el.addEventListener("pointercancel", () => { d = null; });
    }

    // Погладить кота: сердечки, прыжок и его фраза. Второй тап по облачку — подробности о коте.
    const CAT_LINES = {
      0: ["Я не толстый, я выпечка", "Мурр… свежий, тёплый", "Не трогай корочку!", "Меня продали за 49 ₽. Я стою дороже"],
      1: ["Мой хвост где-то там…", "Подожди, остальная часть меня ещё идёт", "Обнимашки на весь столик!"],
      2: ["В моё время коробки были больше", "Эх, молодёжь…", "Где мои очки? А, на мне"],
      4: ["Эта коробка — 7 из 10", "Я тут живу, вообще-то", "Картон тонковат…"],
      5: ["Ещё пять минуточек…", "Zzz…", "Я не сплю, я экономлю энергию"],
      8: ["Дождь кончится… но не сегодня", "Я помню, как выглядят звёзды", "Ты тоже это видишь?"],
      9: ["Эфир через 3… 2…", "Поймай ритм", "Это не шум. Это бит"],
      12: ["Сканирую… ты свой", "Ошибка 404: ласка не найдена. А, нет, найдена", "Neko Corp? Не слышал. Наверное"],
      13: ["Я упала с неба. Красиво, да?", "Осторожно, горячо!", "Дождь начался в ночь, когда я упала…"],
      14: ["Время — это рыба", "Я уже инвестировал в эту ласку", "Записывай: гений, миллиардер, кот"],
      15: ["Путь кота — путь тишины", "…", "Моя катана — это коготь"],
      16: ["root@meowcafe:~# мур", "Я знаю, сколько раз ты меня погладил", "Они не должны узнать…"],
      17: ["Пристегнись", "Я видел, что там, за дождём", "От нуля до сотни за два мурра"],
    };
    function petCat(w) {
      const c = w.cat;
      haptic("light");
      window.Snd && Snd.play(Math.random() < 0.55 ? "meow" : "purr");
      const lines = CAT_LINES[c.cat_id] || ["Мур!", "Мрр…", "Мяу?"];
      const line = lines[Math.floor(Math.random() * lines.length)];
      w.pausedUntil = Date.now() + 5000;
      const pose = w.el.querySelector(".pose");
      if (pose && pose.animate) pose.animate([{ transform: "translateY(0) scale(1)" }, { transform: "translateY(-14px) scale(1.08,.94)" }, { transform: "translateY(0) scale(1)" }],
                                             { duration: 420, easing: "cubic-bezier(.3,1.6,.5,1)" });
      for (let i = 0; i < 4; i++) {
        const ht = document.createElement("span");
        ht.className = "pethe"; ht.textContent = i % 2 ? "💜" : "💗";
        ht.style.cssText = `left:${w.x + (Math.random() - .5) * 8}%;top:${w.y - 10}%;--dx:${((Math.random() - .5) * 40).toFixed(0)}px;animation-delay:${i * 0.12}s`;
        roomEl.appendChild(ht); setTimeout(() => ht.remove(), 1600);
      }
      roomEl.querySelectorAll(".petbub").forEach(b => b.remove());
      const b = document.createElement("button");
      b.className = "petbub";
      b.innerHTML = `${esc(line)}<small>${esc(c.name)} · ур. ${c.level} · тап — карточка</small>`;
      b.style.cssText = `left:${Math.max(18, Math.min(82, w.x))}%;top:${w.y - 17}%`;
      b.onclick = (e) => { e.stopPropagation(); b.remove(); openCatCard(c.cat_id); };
      roomEl.appendChild(b);
      setTimeout(() => b.remove(), 3200);
    }

    // Гость встаёт и уходит, растворяясь у края
    function guestLeaves(el, happyText) {
      el.onclick = null; el.style.pointerEvents = "none";
      const bubble = happyText ? `<div class="bubble" style="background:#FFD6EA">♥ ${happyText}</div>` : "";
      el.innerHTML = bubble + `<div class="pose">${el.querySelector(".pose") ? el.querySelector(".pose").innerHTML : ""}</div>`;
      setTimeout(() => { el.classList.replace("idle", "walk"); el.classList.add("leave"); el.style.left = "106%"; setTimeout(() => el.remove(), 3100); }, happyText ? 1300 : 300);
    }

    // ---- обычные гости: просто атмосфера ----
    function spawnGuest() {
      if (document.body.classList.contains("ingame")) return;
      if (!roomEl || view !== "cafe") return;
      const seats = LOC_DECOR[curLoc].seats;
      const busy = ambient.map(g => g.table);
      const first = 0;
      const own = svcTables(curLoc);
      const working = svcSlots().filter(s => s.room === curLoc && s.role === "wait" && s.cat_id != null && s.table_level > 0).map(s => s.table);
      const free = seats.map((_, i) => i).filter(i => i >= first && !busy.includes(i) && working.includes(i));
      if (!free.length || Math.random() < 0.15 || ambient.length >= (curLoc === 0 ? 2 : 3)) return;
      const table = free[Math.floor(Math.random() * free.length)];
      placeGuest(table, randomGuestLook(), Date.now() + 9000 + Math.random() * 7000, false);
    }
    // seated=true — гость уже сидит (вернулись на локацию), иначе входит справа
    function placeGuest(table, look, leaveAt, seated) {
      const t = LOC_DECOR[curLoc].seats[table];
      if (!t) return;
      const g = { table, look, leaveAt, loc: curLoc, el: document.createElement("div") };
      g.el.className = seated ? "ent idle" : "ent walk";
      g.el.style.cssText = `left:${seated ? t.x - 13 : 106}%;top:${t.y - 3}%;z-index:${t.y + 1};pointer-events:none;transition:left 3s linear, top 3s linear`;
      g.el.innerHTML = `<div class="pose">${guestSvg(typeof look === "number" ? GUEST_LOOKS[look] : look)}</div>`;
      roomEl.appendChild(g.el);
      ambient.push(g);
      if (!seated) {
        requestAnimationFrame(() => requestAnimationFrame(() => { g.el.style.left = (t.x - 13) + "%"; }));
        setTimeout(() => { g.el.classList.replace("walk", "idle"); }, 3000);
      }
      setTimeout(() => {
        if (!g.el.isConnected || !ambient.includes(g)) return;
        ambient.splice(ambient.indexOf(g), 1);
        guestLeaves(g.el, ["Вкусно!", "Мур!", "Приду ещё", "Котики ♥"][Math.floor(Math.random() * 4)]);
      }, Math.max(500, leaveAt - Date.now()));
    }

    function switchLoc(d) {
      const pos = ROOM_ORDER.indexOf(curLoc) + d;
      if (pos < 0 || pos >= ROOM_ORDER.length || switching) return;
      const n = ROOM_ORDER[pos];
      if (!roomEl || !roomEl.animate) { curLoc = n; render(); return; }
      switching = true;
      // старая сцена уезжает в сторону свайпа, новая въезжает с другой стороны
      roomEl.animate([{ transform: "translateX(0)", opacity: 1 }, { transform: `translateX(${-d * 35}%)`, opacity: 0 }],
                     { duration: 180, easing: "ease-in", fill: "forwards" }).finished.then(() => {
        curLoc = n; render();
        const a = roomEl.animate([{ transform: `translateX(${d * 35}%)`, opacity: 0 }, { transform: "translateX(0)", opacity: 1 }],
                                 { duration: 260, easing: "cubic-bezier(.2,.8,.3,1)" });
        roomEl.getAnimations().forEach(x => { if (x !== a) x.cancel(); });
        a.finished.finally(() => { switching = false; });
      }).catch(() => { switching = false; });
    }

    // ================= Развитие: локации и улучшения =================
    async function openLocation() {
      try { const d = await api("POST", "/api/locations/open"); S = d; loadedAt = Date.now(); render(); toast(d.opened + " открыта!"); }
      catch (e) { toast(e.message); }
    }
    const UPG_ICON = {
      cash: "M4 9h16v11H4zM7 9V5h10v4M8 13h2M12 13h2M8 16h8",
      bank: "M5 11a7 6 0 0 1 13-2h2v4l-2 1v3h-3v-2H9v2H6v-3a6 6 0 0 1-1-3zM10 6.5h3",
      coffee: "M5 8h11v6a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5zM16 9h1.5a2.5 2.5 0 0 1 0 5H16M8 3v2M11 3v2",
      tables: "M3 9h18M6 9l-1 10M18 9l1 10M9 9v6h6V9",
    };
    const UPG_COLOR = { cash: "#5EE7FF", bank: "#FFC94D", coffee: "#FF5CA8", tables: "#B388FF" };
    function openUpgrades(focus) {
      if (typeof focus !== "string") focus = null;
      const body = document.getElementById("sheetBody");
      body.innerHTML = `<div class="row" style="align-items:center"><h3>Улучшения кафе</h3>
          <button onclick="closeSheet()" aria-label="Закрыть" style="width:44px;height:44px;border-radius:12px;border:none;background:#241D45;color:var(--text);font-size:18px">×</button></div>
        ${S.upgrades.map(u => {
          const can = !u.maxed && S.coins >= u.cost;
          return `<div class="upg ${focus === u.kind ? "focus" : ""}"><div class="ico" style="color:${UPG_COLOR[u.kind]}"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${UPG_ICON[u.kind]}"/></svg></div>
            <div class="txt"><b style="font-size:14px">${u.name} <span style="color:var(--muted);font-weight:400;font-size:12px">ур. ${u.level}${u.maxed ? " (макс.)" : ""}</span></b>
              <span style="font-size:11px;color:var(--muted)">${u.what}</span>
              <span style="font-size:12px;color:${UPG_COLOR[u.kind]}">${u.effect}${u.maxed ? "" : " → " + u.next_effect}</span></div>
            <button onclick="buyUpgrade('${u.kind}')" ${u.maxed ? "disabled" : ""} style="background:${can ? "var(--gold)" : "#2E2458"};color:${can ? "#3A2A00" : "#8A80B5"}">${u.maxed ? "Макс." : fmt(u.cost)}</button></div>`;
        }).join("")}
        `;
      document.getElementById("sheet").classList.add("on");
    }
    async function buyUpgrade(kind) {
      try {
        const d = await api("POST", "/api/upgrades/buy", { kind });
        S = d; loadedAt = Date.now(); render(); openUpgrades(kind); window.Snd && Snd.play("upgrade");
        toast(d.upgraded + ": уровень " + d.upgrade_level + "!");
      } catch (e) { toast(e.message); }
    }
    function closeSheet() { document.getElementById("sheet").classList.remove("on"); }

    // ================= Вкладка «Коты» =================
    function renderCats() {
      const owned = new Map(S.cats.map(c => [c.cat_id, c]));
      const working = S.cats.filter(c => c.location !== null);
      let body;
      if (catsTab === "mine") {
        body = `<div class="panel"><div class="row"><span style="color:var(--muted)">В работе: <b style="color:var(--text)">${working.length}</b> · в запасе: <b style="color:var(--text)">${S.cats.length - working.length}</b></span>
                  <b style="color:#FF8FC4">🍬 ${S.treats}</b></div></div>${S.cats.length ? "" : `<div class="note">Котов пока нет — начни историю в кафе</div>`}
          ${S.cats.map(c => {
            const col = COLORS[c.rarity], working = c.slot != null;
            return `<button class="catrow catrow2" style="opacity:${working ? 1 : .8}" onclick="openCatCard(${c.cat_id})"><div class="av" style="border-color:${col}">${CatArt.svg(c.cat_id, "sit", 44)}</div>
              <div class="txt"><b style="font-size:15px">${c.name} <span style="font-size:11px;color:var(--muted);font-weight:400">ур. ${c.level}</span>${c.feed_cost != null && S.treats >= c.feed_cost ? ` <span class="canfeed">🍬 можно покормить</span>` : ""}</b>
                <span style="font-size:11.5px;color:${working ? "var(--cyan)" : "var(--muted)"}">${c.role ? ROLE_ICO[c.role] + " " : ""}${catPlace(c)}</span>
                ${statChips(c.stats, c.role)}</div><span class="chev">›</span></button>`;
          }).join("")}`;
      } else {
        body = [0, 1, 2, 3, 4].map(r => {
          const list = CATALOG.filter(c => c.rarity === r);
          const got = list.filter(c => owned.has(c.cat_id)).length;
          return `<div style="display:flex;flex-direction:column;gap:6px"><div class="row"><b style="color:${COLORS[r]}">${RARITY[r]}</b><span style="color:#8A80B5">${got} / ${list.length}</span></div>
            <div class="coll">${list.map(c => {
              const have = owned.has(c.cat_id);
              return `<div style="border-color:${have ? COLORS[r] : "#241D45"};background:${have ? "var(--card)" : "#120E24"}">${have ? CatArt.svg(c.cat_id, "sit", 50) : CatArt.silhouette(c.cat_id, 50)}
                <span style="color:${have ? "var(--text)" : "#5A4E92"}">${have ? c.name : "???"}</span></div>`;
            }).join("")}</div></div>`;
        }).join("");
      }
      return `<div class="top"><div class="title">Коты${helpBtn("cats")}</div><div style="font-size:12px;color:var(--muted)">Собрано <b style="color:var(--text)">${S.cats.length} / ${CATALOG.length || 10}</b></div></div>
        <div class="seg"><button class="${catsTab === "mine" ? "on" : ""}" onclick="catsTab='mine';render()">Мои коты</button>
          <button class="${catsTab === "all" ? "on" : ""}" onclick="catsTab='all';render()">Коллекция</button></div>${body}`;
    }

    async function refreshState() {
      try { const d = await api("GET", "/api/tasks"); S = d; loadedAt = Date.now(); render(); } catch (e) {}
    }


    // ================= Мини-игры: Десертопад =================
    let GV = null, GVat = 0, G = null;
    const ITEM_SVG = {
      cup: `<svg width="56" height="56" viewBox="0 0 40 40" aria-hidden="true"><path d="M9 20 L12 36 H28 L31 20 Z" fill="#FF8FC4"/><path d="M12 22v12M20 22v14M28 22v12" stroke="#E0679F" stroke-width="2"/><circle cx="14" cy="17" r="7" fill="#FFF0F6"/><circle cx="26" cy="17" r="7" fill="#FFF0F6"/><circle cx="20" cy="12" r="8" fill="#FFF0F6"/><circle cx="20" cy="4" r="3" fill="#FF3B5C"/></svg>`,
      donut: `<svg width="56" height="56" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="16" fill="#E8A060"/><circle cx="20" cy="20" r="13" fill="#FF8FC4"/><circle cx="20" cy="20" r="5" fill="#1A1433"/><path d="M12 13l2 1M26 12l-1 2M28 24l-2-1M13 27l2-1M20 9v2" stroke="#FFF0F6" stroke-width="2" stroke-linecap="round"/></svg>`,
      cake: `<svg width="56" height="56" viewBox="0 0 40 40" aria-hidden="true"><path d="M5 30 L35 30 L35 20 L5 14 Z" fill="#F5D7A8"/><path d="M5 14 L35 20 L35 23 L5 18 Z" fill="#8A4B2F"/><path d="M5 22 L35 26 L35 28 L5 25 Z" fill="#8A4B2F"/><path d="M5 14 L18 6 L35 20 Z" fill="#FFF0F6"/><circle cx="18" cy="7" r="3" fill="#FF3B5C"/></svg>`,
      gold: `<svg width="56" height="56" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="18" fill="#FFC94D" opacity=".25"/><ellipse cx="20" cy="14" rx="14" ry="6.5" fill="#FFC94D"/><rect x="8" y="17" width="24" height="5" rx="2" fill="#FFF0C2"/><ellipse cx="20" cy="25" rx="14" ry="6.5" fill="#FFC94D"/></svg>`,
      rock: `<svg width="56" height="56" viewBox="0 0 40 40" aria-hidden="true"><path d="M8 14 L20 6 L33 12 L35 24 L24 34 L10 30 Z" fill="#6B6880"/><circle cx="18" cy="17" r="3" fill="#55526A"/><circle cx="26" cy="25" r="2" fill="#55526A"/></svg>`,
    };

    const ITEM_IMG = {};
    function itemImg(kind) {
      if (!ITEM_IMG[kind]) ITEM_IMG[kind] = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(ITEM_SVG[kind].replace("<svg ", '<svg xmlns="http://www.w3.org/2000/svg" '));
      return ITEM_IMG[kind];
    }

    function renderGames() {
      if (!GV) return header("Мини-игры") + `<div class="err" style="color:var(--muted)">Загрузка…</div>`;
      const left = Math.max(0, GV.next_attempt_in - (Date.now() - GVat) / 1000);
      const cells = [...Array(GV.attempts_max)].map((_, i) => `<i class="${i < GV.attempts ? "on" : ""}"></i>`).join("");
      const fall = [["cup", 8, 0], ["donut", 30, 1.1], ["gold", 52, .5], ["cake", 72, 1.7], ["rock", 88, .9], ["cup", 62, 2.3], ["donut", 18, 2.8]]
        .map(([k, x, d]) => `<div class="fall" style="left:${x}%;animation-delay:-${d}s;animation-duration:${3 + (x % 3) * .4}s">${ITEM_SVG[k]}</div>`).join("");
      const canAd = adsOn() && GV.attempts < GV.attempts_max && ADL && ADL.attempts > 0;
      return header("Мини-игры") + `
        <div class="arcade">
          <div class="ascreen">${fall}
            <div class="atitle"><b>ДЕСЕРТОПАД</b><span>30 секунд · лови десерты</span></div>
            <div class="acat">${CatArt.svg(S.barista_cat_id != null ? S.barista_cat_id : 3, "sit", 64)}</div>
            <div class="ascan"></div></div>
          <div class="abody">
            <div class="energy2"><div class="cells">${cells}</div><span id="gNext">${GV.attempts ? `Попытки ${GV.attempts} из ${GV.attempts_max}` : "Попытки закончились"}${left > 0 ? ` · +1 через ${hms(left)}` : ""}</span></div>
            <button class="playbtn" onclick="startGame()" ${GV.attempts > 0 ? "" : "disabled"}>
              <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4v16l13-8z" fill="currentColor"/></svg>${GV.attempts > 0 ? "ИГРАТЬ" : "НЕТ ПОПЫТОК"}</button>
            ${canAd ? `<button class="adbtn" onclick="attemptAd()">+1 попытка за рекламу <span>осталось ${ADL.attempts}${isDesktop() ? " · лучше с телефона" : ""}</span></button>` : ""}
            <div class="gstats">
              <div><span>Рекорд</span><b>${GV.best}</b></div>
              <div><span>1 очко</span><b style="color:var(--gold)"><span class="coin s"></span>${fmt(GV.per_point)}</b></div>
              <div><span>За сезон</span><b>${fmt(GV.points_season)}</b></div></div>
            <div class="grules"><span>${ITEM_SVG.cup}<b>+1</b></span><span>${ITEM_SVG.cake}<b>+2</b></span><span>${ITEM_SVG.gold}<b>+5</b></span><span>${ITEM_SVG.rock}<b style="color:#FF6B6B">−25%</b></span></div>
          </div></div>
        <div class="sec">Скоро</div>
        <div class="soon">
          <div><div class="sicon">🎵</div><b>Кото-ритм</b><span>тапай в такт</span></div>
          <div><div class="sicon">☕</div><b>Бариста</b><span>собери заказ</span></div></div>
        <div class="note">Награда растёт вместе с кафе: 1 очко = 15 секунд дохода × кофемашина</div>`;
    }


    // Фон десертопада: небо, город (растровая картинка — не грузит кадры), пара машин и редкий дождь.
    let FIELD_BG = null;
    function fieldBg() {
      if (!FIELD_BG) {
        const r = cwRnd(77);
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 220" preserveAspectRatio="xMidYMax slice">${cwSkyline(r, 205, "#1A2448", "#111A36", "#0A1024")}</svg>`;
        FIELD_BG = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
      }
      const rr = cwRnd(5);
      let drops = "";
      for (let i = 0; i < 22; i++) drops += `<i style="left:${(rr() * 100).toFixed(1)}%;height:${(16 + rr() * 18).toFixed(0)}px;animation-duration:${(1.4 + rr() * 0.8).toFixed(2)}s;animation-delay:-${(rr() * 2).toFixed(2)}s"></i>`;
      return `<div class="gsky"></div><div class="gmoon"></div>
        <div class="gcar" style="top:16%;animation-duration:14s">${cwHover("#26324E", "#21E6FF")}</div>
        <div class="gcar rev" style="top:30%;animation-duration:19s;animation-delay:-8s">${cwHover("#1E2A44", "#FF2E88")}</div>
        <div class="gcity" style="background-image:url('${FIELD_BG}')"></div><div class="grain">${drops}</div><div class="gshade"></div>`;
    }
    function measureField() { const f = document.getElementById("field"); if (G && f) { G.fw = f.clientWidth; G.fh = f.clientHeight; } }
    window.addEventListener("resize", measureField);

    async function startGame() {
      try {
        const d = await api("POST", "/api/game/start");
        GV = d.game; GVat = Date.now();
        const field = document.getElementById("field");
        field.innerHTML = fieldBg() + '<div class="gbig" id="gBig"></div>';
        G = { sid: d.session_id, items: Dessert.schedule(d.seed), caught: new Set(), taps: [], score: 0, els: new Map(), dur: d.duration_ms, done: false, lastBig: null };
        document.getElementById("gScore").innerHTML = '0 <span style="font-size:13px;color:var(--muted);font-weight:500">очков</span>';
        document.getElementById("game").classList.add("on");
        document.body.classList.add("ingame");
        if (window.Snd) Snd.scene("game");
        measureField();
        G.t0 = performance.now() + 3000;   // 3 секунды отсчёта «3, 2, 1» — партия начинается после него
        requestAnimationFrame(gameLoop);
      } catch (e) { toast(e.message); }
    }

    function gameLoop() {
      if (!G || G.done) return;
      const t = performance.now() - G.t0;
      const big = document.getElementById("gBig");
      if (t < 0) {                               // отсчёт перед стартом
        const n = Math.ceil(-t / 1000);
        if (G.lastBig !== "c" + n) { G.lastBig = "c" + n; big.textContent = n; big.className = "gbig"; void big.offsetWidth; big.className = "gbig count"; }
        document.getElementById("gTime").textContent = Math.ceil(G.dur / 1000) + " с";
        document.getElementById("gBar").style.transform = "scaleX(1)";
        requestAnimationFrame(gameLoop); return;
      }
      const left = Math.max(0, G.dur - t);
      const sec = Math.ceil(left / 1000);
      if (G.lastBig !== sec) {                   // большой таймер в центре поля: видно периферийным зрением
        G.lastBig = sec; big.textContent = sec;
        big.className = "gbig"; if (sec <= 5) { void big.offsetWidth; big.className = "gbig warn"; }
      }
      if (G.lastSec !== sec) {
        G.lastSec = sec;
        const gt = document.getElementById("gTime");
        gt.textContent = sec + " с"; gt.style.color = left < 5000 ? "var(--pink)" : "var(--cyan)";
      }
      document.getElementById("gBar").style.transform = `scaleX(${(left / G.dur).toFixed(4)})`;
      if (t >= G.dur) { endGame(); return; }
      const field = document.getElementById("field");
      G.items.forEach((it, i) => {
        const y = Dessert.yAt(it, t);
        const show = it.t0 <= t && y >= -8 && y <= 108 && !G.caught.has(i);
        let el = G.els.get(i);
        if (show) {
          if (!el) { el = document.createElement("div"); el.className = "it"; el.innerHTML = `<img src="${itemImg(it.kind)}" width="56" height="56" alt="" draggable="false">`; field.appendChild(el); G.els.set(i, el); }
          const px = it.x / 100 * G.fw, py = y / 100 * G.fh;
          el.style.transform = `translate3d(${px.toFixed(1)}px,${py.toFixed(1)}px,0) rotate(${(((i * 47) % 40 - 20) + (t - it.t0) / 1000 * ((i % 7) * 15 - 45)).toFixed(1)}deg)`;
        } else if (el) { el.remove(); G.els.delete(i); }
      });
      requestAnimationFrame(gameLoop);
    }

    function gameTap(e) {
      if (!G || G.done) return;
      e.preventDefault();
      const field = document.getElementById("field"), r = field.getBoundingClientRect();
      const t = performance.now() - G.t0;
      if (t < 0) return;                        // во время отсчёта тапы не считаются
      const x = (e.clientX - r.left) / r.width * 100, y = (e.clientY - r.top) / r.height * 100;
      G.taps.push([Math.round(t), Math.round(x * 100) / 100, Math.round(y * 100) / 100]);
      const i = Dessert.hitTest(G.items, G.caught, t, x, y);
      if (i < 0) return;
      G.caught.add(i);
      const it = G.items[i];
      let text, color;
      if (it.kind === "rock") {
        const lost = Math.ceil(G.score * Dessert.ROCK_PENALTY);
        G.score -= lost; text = "−" + lost; color = "#FF6B6B"; window.Snd && Snd.play("rock");
        field.classList.remove("hit"); void field.offsetWidth; field.classList.add("hit");
        if (tg && tg.HapticFeedback) tg.HapticFeedback.notificationOccurred("error");
      } else {
        G.score += it.pts; text = "+" + it.pts; color = it.kind === "gold" ? "var(--gold)" : "var(--text)"; window.Snd && Snd.play("catch", it.pts);
        if (tg && tg.HapticFeedback) tg.HapticFeedback.impactOccurred("light");
      }
      document.getElementById("gScore").innerHTML = G.score + ' <span style="font-size:13px;color:var(--muted);font-weight:500">очков</span>';
      const pop = document.createElement("div");
      pop.className = "pop"; pop.textContent = text; pop.style.color = color;
      pop.style.left = it.x + "%"; pop.style.top = Dessert.yAt(it, t) + "%";
      field.appendChild(pop); setTimeout(() => pop.remove(), 700);
      // искры вокруг пойманного десерта
      const sc = it.kind === "rock" ? "#FF6B6B" : it.kind === "gold" ? "#FFC94D" : ["#FF8FC4", "#5EE7FF", "#FFF"][Math.floor(Math.random() * 3)];
      for (let k = 0; k < 7; k++) {
        const sp = document.createElement("div"), ang = k / 7 * Math.PI * 2, dist = 26 + Math.random() * 14;
        sp.className = "spark"; sp.style.background = sc; sp.style.boxShadow = "0 0 6px " + sc;
        sp.style.left = it.x + "%"; sp.style.top = Dessert.yAt(it, t) + "%";
        sp.style.setProperty("--dx", Math.cos(ang) * dist + "px"); sp.style.setProperty("--dy", Math.sin(ang) * dist + "px");
        field.appendChild(sp); setTimeout(() => sp.remove(), 520);
      }
    }

    async function endGame() {
      G.done = true;
      const m = document.getElementById("modal");
      m.innerHTML = `<div style="color:var(--muted);font-size:15px">Время вышло! Считаем очки…</div>`;
      m.classList.add("on");
      try {
        const d = await api("POST", "/api/game/finish", { session_id: G.sid, taps: G.taps });
        S = d; loadedAt = Date.now(); GV = d.game; GVat = Date.now();
        m.innerHTML = `<button class="xbtn" id="gClose" onclick="closeGame()" aria-label="Закрыть">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
          <div class="dialog">
          <div style="font-size:14px;color:var(--muted)">Время вышло!</div>
          <div style="font-size:48px;font-weight:800">${d.score}</div>
          <div style="font-size:14px;color:#D6CCFF">очков · поймано ${d.hits} · камней ${d.rocks}</div>
          ${d.new_record ? `<div class="tag" style="background:var(--pink);color:#1A0614">Новый рекорд!</div>` : ""}
          <div class="panel" style="width:100%;align-items:center"><span style="font-size:12px;color:var(--muted)">${d.score} × ${fmt(GV.per_point)} мяуконов за очко</span>
            <div class="coins" style="justify-content:center"><span class="coin"></span><span id="gReward">+${fmt(d.reward)}</span></div></div>
          ${d.treats ? `<div class="tag" style="background:#3A1A40;color:#FFB3D9">+${d.treats} 🍬 вкусняшек для котов</div>` : ""}
          <div style="font-size:12px;color:var(--muted)">Мяуконы уже на счету</div>
          ${adsOn() && d.reward > 0 ? `<button class="main" id="x2Btn" style="margin-top:28px;opacity:.35;pointer-events:none;transition:opacity .4s" onclick="x2Ad(${d.session_id})">×2 за рекламу</button>` : ""}</div>`;
        // кнопка рекламы оживает через 1,5 с — чтобы не нажать её по инерции после игры
        setTimeout(() => { const b = document.getElementById("x2Btn"); if (b) { b.style.opacity = 1; b.style.pointerEvents = "auto"; } }, 1500);
        setTimeout(() => { const x = document.getElementById("gClose"); if (x) x.classList.add("on"); }, 1000);
      } catch (e) {
        m.innerHTML = `<div class="dialog"><div class="err">${e.message}</div><button class="main" onclick="closeGame()">Закрыть</button></div>`;
      }
    }
    function closeGame() {
      closeModal();
      document.getElementById("game").classList.remove("on");
      document.body.classList.remove("ingame");
      if (window.Snd) Snd.scene("cafe");
      G = null; render();
    }


    // ================= Задания =================
    const CHECK = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>`;
    const sponsorOpened = new Set();   // по каким каналам нажали «Подписаться» — тогда показываем «Проверить»

    function setBadge() {
      const b = document.getElementById("tasksBadge");
      if (!b || !T) return;
      b.textContent = T.ready > 9 ? "9+" : T.ready;
      b.classList.toggle("on", T.ready > 0);
    }


    // иконки квестов по типу
    const QICON = {
      box: ["#FFC94D", "M3 8l9-5 9 5v8l-9 5-9-5zM3 8l9 5 9-5M12 13v8"],
      cat: ["#B388FF", "M5 10 4 3l5 3h6l5-3-1 7a7 7 0 0 1-14 0zM9.5 12h.01M14.5 12h.01"],
      cup: ["#FF8FC4", "M5 8h11v6a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5zM16 9h1.5a2.5 2.5 0 0 1 0 5H16M8 3v2M11 3v2"],
      guest: ["#5EE7FF", "M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0"],
      game: ["#3DFFB0", "M6 8h12a4 4 0 0 1 4 4v1a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4v-1a4 4 0 0 1 4-4zM7 11v3M5.5 12.5h3M16 12h.01M18 14h.01"],
      up: ["#FFC94D", "M12 19V5M6 11l6-6 6 6"],
      map: ["#FF5CA8", "M12 21s-7-6-7-11a7 7 0 0 1 14 0c0 5-7 11-7 11zM12 12a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"],
      friend: ["#5EE7FF", "M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6 6 0 0 1 3.5 6"],
      tg: ["#5EE7FF", "M21 4 3 11l6 2 2 6 3-4 5 4z"],
    };
    function qIcon(id) {
      const k = /^q_box/.test(id) ? "box" : /^q_(col|epic|leg)/.test(id) ? "cat" : /^q_barista/.test(id) ? "cup" : /^q_guest/.test(id) ? "guest"
        : /^q_(game|score)/.test(id) ? "game" : /^q_(cash|bank)/.test(id) ? "up" : /^q_(terrace|space)/.test(id) ? "map" : /^q_friend/.test(id) ? "friend" : "tg";
      const [c, d] = QICON[k];
      return `<div class="qi" style="color:${c};background:${c}1F;box-shadow:0 0 14px ${c}22 inset"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg></div>`;
    }
    const CHEST = `<svg width="26" height="22" viewBox="0 0 26 22" aria-hidden="true"><rect x="2" y="9" width="22" height="12" rx="2" fill="#B87418"/><path d="M2 10 Q13 0 24 10 Z" fill="#FFC94D"/><rect x="2" y="9" width="22" height="3" fill="#8A5410"/><rect x="11" y="10" width="4" height="6" rx="1" fill="#FF2E88"/></svg>`;

    const QCATS = [["friends", "👥", "Друзья"], ["boxes", "📦", "Коробки"], ["collection", "🐱", "Коллекция"], ["games", "🎮", "Мини-игры"], ["cafe", "☕", "Кафе"]];
    const openQ = {};
    // Коробка в наградах — своим цветом (как во вкладке «Коробки»), без названия цвета
    function boxIco(name, size) {
      if (name === "Редкая коробка") return CHEST.replace('width="26" height="22"', `width="${size}" height="${Math.round(size * 0.85)}"`);
      return boxSvg(0, size);
    }
    function rewardLine(coins, boxName) {
      return `<span class="rw">${coins ? `<span class="coin s"></span>+${fmt(coins)}` : ""}${boxName ? `<span class="rwbox ${boxName === "Легендарная" ? "leg" : ""}">${coins ? "+ " : ""}${boxIco(boxName, 17)} ${boxName === "Легендарная" ? "Легендарная коробка" : "Коробка"}</span>` : ""}</span>`;
    }
    function renderTasks() {
      if (!T) return header("Задания") + `<div class="err" style="color:var(--muted)">Загрузка…</div>`;
      const d = T.daily;
      const doneUpTo = d.claimed_today ? d.day : d.day - 1;
      const boxes = d.boxes || [];
      const days = d.rewards.map((r, i) => {
        const n = i + 1, done = n <= doneUpTo, today = n === d.day && !d.claimed_today, bx = boxes[i];
        return `<div class="dy ${done ? "done" : ""} ${today ? "today" : ""} ${n === 7 ? "wk" : ""} ${bx ? "hasbox" : ""}">
          <span class="n">${n === 7 ? "7 день" : n}</span>
          ${done ? `<span class="ok">${CHECK}</span>` : bx ? `<span class="dbox">${boxIco(bx, 24)}</span>` : `<span class="coin s"></span>`}
          <b>${bx ? (bx === "Легендарная" ? "Легенд." : r ? fmt(r) : "Коробка") : fmt(r)}</b></div>`;
      }).join("");
      const todayBox = boxes[d.day - 1], todayCoins = d.rewards[d.day - 1];
      const dailyBtn = d.claimed_today
        ? `<div class="dnext">Следующая награда через <b>${hm(d.next_in)}</b></div>`
        : `<button class="main pink glowbtn" onclick="claimDaily()">Забрать за ${d.day}-й день · ${[todayCoins ? "+" + fmt(todayCoins) : "", todayBox ? (todayBox === "Легендарная" ? "легендарная коробка" : "коробка") : ""].filter(Boolean).join(" + ")}</button>`;

      const sponsors = T.sponsors.filter(x => !x.done).map(x => `
        <div class="qcard">${qIcon("sp")}<div class="qt"><b>Подпишись на ${x.title}</b><span class="rw"><span class="coin s"></span>+${fmt(x.reward)}</span></div>
          ${sponsorOpened.has(x.channel)
            ? `<button class="qbtn pink" onclick="checkSponsor('${x.channel}')">Проверить</button>`
            : `<button class="qbtn cyan" onclick="openSponsor('${x.channel}','${x.url}')">Открыть</button>`}</div>`).join("");

      const card = (q) => `<div class="qcard ${q.status}">${qIcon(q.id)}
          <div class="qt"><b>${q.title}</b>
            ${q.need > 1 && q.status !== "claimed" ? `<div class="qbar"><div style="width:${Math.min(100, q.have / q.need * 100)}%"></div></div>` : ""}
            ${rewardLine(q.reward, q.box_name)}${q.need > 1 && q.status === "progress" ? `<i class="qcnt">${fmt(q.have)} / ${fmt(q.need)}</i>` : ""}</div>
          ${q.status === "ready" ? `<button class="qbtn pink glowbtn" onclick="claimQuest('${q.id}')">Забрать</button>` : q.status === "claimed" ? `<div class="chk">${CHECK}</div>` : ""}</div>`;
      const sections = QCATS.map(([key, ico, name]) => {
        const list = T.quests.filter(q => (q.cat || "cafe") === key);
        if (!list.length) return "";
        const ready = list.filter(q => q.status === "ready"), prog = list.filter(q => q.status === "progress"), done = list.filter(q => q.status === "claimed");
        const open = openQ[key];
        const shown = open ? [...ready, ...prog, ...done] : [...ready, ...prog.slice(0, ready.length ? 1 : 2)];
        const more = list.length - shown.length;
        return `<div class="qsec">
          <div class="qhead"><span class="qico">${ico}</span><b>${name}</b>${ready.length ? `<span class="qready">${ready.length}</span>` : ""}
            <span class="qof">${done.length} / ${list.length}</span></div>
          ${key === "friends" ? `<div class="qnote">Активный друг — заходил 3 разных дня и сыграл 1 мини-игру. <a onclick="go('friends')">Пригласить →</a></div>` : ""}
          ${shown.map(card).join("") || `<div class="qnote">Всё выполнено 🎉</div>`}
          ${more > 0 || open ? `<button class="qmore" onclick="openQ['${key}']=!openQ['${key}'];render()">${open ? "Свернуть" : "Ещё " + more}</button>` : ""}
        </div>`;
      }).join("");

      return header("Задания") + `
        <div class="dcard">
          <div class="row" style="align-items:center"><b style="font-size:16px">Серия входов</b><span class="streak">🔥 ${doneUpTo} / 7</span></div>
          <div class="dstrip">${days}</div>
          ${dailyBtn}
          <div class="dhint">7 дней подряд — <b style="color:var(--gold)">легендарная коробка</b>. Пропустишь день — серия начнётся заново</div>
        </div>
        <div class="promo"><input id="promoIn" placeholder="Есть промокод?" maxlength="32" autocomplete="off" autocapitalize="characters"
            value="${promoDraft}" oninput="promoDraft=this.value" onkeydown="if(event.key==='Enter')usePromo()">
          <button class="pink" onclick="usePromo()">OK</button></div>
        ${sponsors ? `<div class="qsec"><div class="qhead"><span class="qico">📢</span><b>Спонсоры</b></div>${sponsors}</div>` : ""}
        ${sections}
        <div class="note">Награды монетами растут вместе с доходом кафе</div>`;
    }


    let promoDraft = "";
    async function usePromo() {
      const code = promoDraft.trim();
      if (!code) { toast("Введи промокод"); return; }
      if (busy) return; busy = true;
      try {
        const d = await api("POST", "/api/promo", { code });
        S = d; loadedAt = Date.now(); B = d; boxesAt = Date.now(); promoDraft = ""; render();
        if (d.results && d.results.length) {
          lastOpen = { count: 1, free: true };
          showShake(); await new Promise(r => setTimeout(r, 900)); await chargeReveal(d.results);
          showResults(d.results); document.getElementById("modal").classList.add("on");
          if (d.coins_added) toast("+" + fmt(d.coins_added) + " мяуконов и коробка!");
        } else rewardPopup("Промокод активирован!", d.coins_added);
        if (tg && tg.HapticFeedback) tg.HapticFeedback.notificationOccurred("success");
      } catch (e) { toast(e.message); } finally { busy = false; }
    }
    function rewardPopup(title, amount) {
      window.Snd && Snd.play("reward");
      const m = document.getElementById("modal");
      m.innerHTML = `<div class="dialog"><div style="font-size:15px;color:var(--muted)">${title}</div>
        <div class="coins" style="font-size:40px;justify-content:center"><span class="coin"></span>+${fmt(amount)}</div>
        <button class="main pink" onclick="closeModal()">Отлично</button></div>`;
      m.classList.add("on");
    }
    async function claimDaily() {
      if (busy) return; busy = true;
      try { const d = await api("POST", "/api/tasks/daily"); S = d; loadedAt = Date.now(); render();
        if (d.results && d.results.length) await giftReveal(d.results, d.box_name, d.reward);
        else { rewardPopup("Награда за день " + d.day, d.reward); if (tg && tg.HapticFeedback) tg.HapticFeedback.notificationOccurred("success"); } }
      catch (e) { toast(e.message); } finally { busy = false; }
    }
    async function claimQuest(id) {
      if (busy) return; busy = true;
      try { const d = await api("POST", "/api/tasks/claim", { id }); S = d; loadedAt = Date.now(); render();
        if (d.results && d.results.length) await giftReveal(d.results, d.box_name, d.reward); else rewardPopup("Задание выполнено!", d.reward); }
      catch (e) { toast(e.message); } finally { busy = false; }
    }
    function openSponsor(channel, url) {
      if (tg && tg.openTelegramLink && url.startsWith("https://t.me/")) tg.openTelegramLink(url); else window.open(url, "_blank");
      sponsorOpened.add(channel); render();
    }
    async function checkSponsor(channel) {
      if (busy) return; busy = true;
      try { const d = await api("POST", "/api/tasks/sponsor", { channel }); S = d; loadedAt = Date.now(); render(); rewardPopup("Спасибо за подписку!", d.reward); }
      catch (e) { toast(e.message); } finally { busy = false; }
    }


    // ================= Друзья =================
    function renderFriends() {
      if (!F) return header("Друзья") + `<div class="err" style="color:var(--muted)">Загрузка…</div>`;
      const left = Math.max(0, F.collect_in - (Date.now() - Fat) / 1000);
      const btn = left > 0
        ? `<button class="main" disabled id="fBtn">Следующий сбор через ${hms(left)}</button>`
        : `<button class="main pink glowbtn" id="fBtn" onclick="collectFriends()" ${F.bank > 0 ? "" : "disabled"}>${F.bank > 0 ? "Собрать" : "Банк пуст"}</button>`;
      const fa = (f, size) => f.avatar != null ? avatarHtml(f.avatar, f.decor, size) : `<span style="font-weight:800">${esc((f.name.replace(/^@/, "")[0] || "?").toUpperCase())}</span>`;
      const stack = F.friends.slice(0, 5).map((f, i) => `<span class="sav" style="z-index:${9 - i}">${fa(f, 34)}</span>`).join("");
      const list = F.friends.map(f => {
        const pDays = f.days / F.need_days * 100, pGames = f.games / F.need_games * 100;
        return `<div class="friend"><div class="av">${fa(f, 40)}</div>
          <div class="txt"><b>${esc(f.name)}</b>${f.active
            ? `<span><span class="pill" style="background:#12261F;color:#7FE0B5">✓ Активный</span></span>`
            : `<div class="fprog"><span>дни</span><div class="qbar"><div style="width:${pDays}%"></div></div><span>${f.days}/${F.need_days}</span></div>
               <div class="fprog"><span>игры</span><div class="qbar"><div style="width:${pGames}%"></div></div><span>${f.games}/${F.need_games}</span></div>`}</div>
          <div class="fgiven"><span class="coin s"></span>${fmt(f.given)}</div></div>`;
      }).join("");
      return header("Друзья") + `
        <div class="fbank2">
          <div class="fcoins">${[10, 30, 55, 75, 90].map((x, i) => `<span class="coin" style="left:${x}%;animation-delay:${i * .7}s"></span>`).join("")}</div>
          <span class="fl">Банк друзей</span>
          <div class="coins" style="font-size:38px;justify-content:center"><span class="coin"></span><span>${fmt(F.bank)}</span></div>
          <span class="fr">${F.per_hour > 0 ? "≈ +" + fmt(F.per_hour) + " в час · " + F.share_pct + "% дохода друзей" : F.share_pct + "% от дохода каждого друга — навсегда"}</span>
          ${btn}</div>
        <div class="steps">
          <div><i>1</i><b>Отправь ссылку</b><span>другу в Telegram</span></div>
          <div><i>2</i><b>Друг играет</b><span>${F.need_days} дня и ${F.need_games} игры</span></div>
          <div><i>3</i><b>Ты получаешь</b><span>${F.share_pct}% его дохода</span></div></div>
        ${F.link ? `<div class="invite"><button class="pink glowbtn" onclick="shareLink()"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M16 6l-4-4-4 4M12 2v13"/></svg>Пригласить друга</button>
          <button class="copy" onclick="copyLink()" aria-label="Скопировать ссылку"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg></button></div>`
          : `<div class="note">Ссылка появится, когда сервер узнает имя бота</div>`}
        <div class="sec row" style="align-items:center;margin-right:4px"><span>Мои друзья · ${F.total}</span><span class="stack">${stack}</span></div>
        ${list || `<div class="fempty">${CatArt.svg(4, "sit", 70)}<b>Пока никого</b><span>Позови первого друга — его доход будет приносить мяуконы и тебе</span></div>`}
        ${F.total > F.friends.length ? `<div class="note">Показаны первые ${F.friends.length}</div>` : ""}
        <div class="note">Активный друг — ${F.need_days} разных дня в игре и ${F.need_games} мини-игры. В рейтинге рефоводов считаются только активные.</div>`;
    }

    function shareLink() {
      const text = "Заходи в MeowCafe — неоновое кошачье кафе! Собираем котов и соревнуемся за призы 🐱";
      const url = "https://t.me/share/url?url=" + encodeURIComponent(F.link) + "&text=" + encodeURIComponent(text);
      if (tg && tg.openTelegramLink) tg.openTelegramLink(url); else window.open(url, "_blank");
    }
    async function copyLink() {
      try { await navigator.clipboard.writeText(F.link); toast("Ссылка скопирована"); }
      catch (e) {
        const t = document.createElement("textarea"); t.value = F.link; document.body.appendChild(t); t.select();
        try { document.execCommand("copy"); toast("Ссылка скопирована"); } catch (e2) { toast("Не получилось, скопируй вручную"); }
        t.remove();
      }
    }
    async function collectFriends() {
      if (busy) return; busy = true;
      try { const d = await api("POST", "/api/friends/collect"); S = d; loadedAt = Date.now(); F = d.friends; Fat = Date.now(); render(); rewardPopup("Банк друзей", d.collected); }
      catch (e) { toast(e.message); } finally { busy = false; }
    }


    // ================= Рейтинг сезона =================
    const CUP = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3M12 14v4M8 21h8M9 18h6"/></svg>`;
    const BOARD_INFO = {
      players: { name: "Игроки", what: "Сколько мяуконов заработано за сезон", unit: (v) => fmt(v) },
      games: { name: "Мини-игры", what: "Сумма очков во всех мини-играх за сезон", unit: (v) => fmt(v) + " оч." },
      refs: { name: "Рефоводы", what: "Сколько активных друзей ты пригласил", unit: (v) => fmt(v) + " " + plural(v, "друг", "друга", "друзей") },
    };
    let R = null, Rat = 0, board = "players";
    function plural(n, one, few, many) {
      n = Math.abs(Math.floor(n)) % 100; const d = n % 10;
      if (n > 10 && n < 20) return many; if (d === 1) return one; if (d >= 2 && d <= 4) return few; return many;
    }
    const dhm = (s) => s >= 86400 ? Math.floor(s / 86400) + "д " + Math.floor(s % 86400 / 3600) + "ч" : hm(s);
    const usd = (x) => "$" + (Math.round(x * 100) / 100).toString().replace(".", ",");

    function renderRating() {
      const tabs = Object.entries(BOARD_INFO).map(([k, b]) => `<button class="${k === board ? "on" : ""}" onclick="pickBoard('${k}')">${b.name}</button>`).join("");
      if (!R || R.board !== board) return header("Рейтинг") + `<div class="seg seg3">${tabs}</div><div class="err" style="color:var(--muted)">Загрузка…</div>`;
      const info = BOARD_INFO[board], se = R.season, me = R.me;
      const left = Math.max(0, se.ends_in - (Date.now() - Rat) / 1000);
      const ava = (r, size) => r.avatar != null ? avatarHtml(r.avatar, r.decor, size) : `<span style="font-weight:800">${esc((r.name.replace(/^@/, "")[0] || "?").toUpperCase())}</span>`;
      const top3 = R.top.slice(0, 3), rest = R.top.slice(3);
      const podium = [1, 0, 2].map(i => {
        const r = top3[i]; if (!r) return `<div class="pd empty"></div>`;
        const medal = ["#FFC94D", "#C2CCDC", "#E2A06A"][i];
        return `<div class="pd p${i + 1} ${r.me ? "me" : ""}">
          <div class="pav" style="border-color:${medal};box-shadow:0 0 ${i ? 12 : 22}px ${medal}88">${ava(r, i ? 54 : 70)}</div>
          <b class="pn">${esc(r.name)}${r.me ? " (ты)" : ""}</b><span class="pv">${info.unit(r.value)}</span>${r.prize ? `<span class="prize">${usd(r.prize)}</span>` : ""}
          <div class="ped" style="background:linear-gradient(${medal}55, ${medal}11);border-color:${medal}88"><span style="color:${medal}">${i + 1}</span></div></div>`;
      }).join("");
      const rows = rest.map(r => `<div class="rrow ${r.me ? "me" : ""}" id="${r.me ? "meRow" : ""}">
          <div class="pl">${r.place}</div><div class="rav">${ava(r, 36)}</div>
          <div class="nm"><b>${esc(r.name)}${r.me ? " (ты)" : ""}</b>${r.prize ? `<span class="prize">приз ${usd(r.prize)}</span>` : ""}</div>
          <div class="val">${info.unit(r.value)}</div></div>`).join("");
      const myAva = S.avatar && S.avatar.cat_id != null ? avatarHtml(S.avatar.cat_id, S.avatar.decor, 36) : "";
      return header("Рейтинг") + `
        <div class="season"><span><b>${se.name}</b> · <span id="seasonLeft">${se.ended ? "сезон завершён" : "до конца " + dhm(left)}</span></span>
          <span>${se.pool > 0 ? "фонд " + usd(se.pool) : "призы скоро"}</span></div>
        <div class="seg seg3">${tabs}</div>
        <div class="note" style="text-align:center;margin-top:-4px">${info.what}</div>
        ${R.top.length ? `<div class="podium">${podium}</div>${rows}` : `<div class="note" style="padding:30px 0">Пока никого нет — стань первым!</div>`}
        ${R.top.length >= 100 ? `<div class="note">Показаны первые 100</div>` : ""}
        <div class="mybar" onclick="const e=document.getElementById('meRow');if(e)e.scrollIntoView({block:'center',behavior:'smooth'})">
          <div class="pl">${me.place || "—"}</div><div class="rav">${myAva}</div>
          <div class="nm"><b>Ты</b><span>${me.banned ? "на проверке" : me.place ? "из " + fmt(me.total) : board === "refs" ? "пригласи активного друга" : board === "games" ? "сыграй в мини-игру" : "собери доход"}</span></div>
          <div class="val">${info.unit(me.value)}</div></div>`;
    }

    async function loadRating() {
      try { const d = await api("GET", "/api/rating?board=" + board); R = d; Rat = Date.now(); if (view === "rating") render(); }
      catch (e) { toast(e.message); }
    }
    function pickBoard(b) { board = b; render(); loadRating(); }


    // ================= Реклама (Adsgram) =================
    // Награду выдаёт сервер, когда Adsgram сам сообщит ему о досмотре (Reward URL). Фронт только показывает рекламу.
    let AdC = null, adsLoading = null, ADL = null;
    const adsOn = () => !!(S && S.ads && S.ads.block_id);
    const isDesktop = () => !!(tg && ["tdesktop", "macos", "web", "weba", "webk", "unigram"].includes(tg.platform));
    function loadAds() {
      if (!adsOn()) return Promise.reject(new Error("Реклама выключена"));
      if (AdC) return Promise.resolve(AdC);
      if (!adsLoading) adsLoading = new Promise((ok, fail) => {
        const sc = document.createElement("script");
        sc.src = "https://sad.adsgram.ai/js/sad.min.js";
        sc.onload = () => { try { AdC = window.Adsgram.init({ blockId: String(S.ads.block_id), debug: !!S.ads.test }); ok(AdC); } catch (e) { fail(e); } };
        sc.onerror = () => { adsLoading = null; fail(new Error("Реклама не загрузилась, попробуй позже")); };
        document.head.appendChild(sc);
      });
      return adsLoading;
    }
    async function watchAd(kind, ref) {
      const ctl = await loadAds();
      const { ad_id } = await api("POST", "/api/ads/start", { kind, ref });
      try { await ctl.show(); }
      catch (r) { throw new Error(r && r.error ? (isDesktop() ? "На компьютере реклама может не показываться — попробуй с телефона" : "Реклама сейчас недоступна, попробуй позже") : "Досмотри рекламу до конца, чтобы получить награду"); }
      for (let i = 0; i < 10; i++) {      // ждём, пока Adsgram подтвердит просмотр серверу
        try { const d = await api("POST", "/api/ads/claim", { ad_id }); S = d; loadedAt = Date.now(); if (d.ads_left) ADL = d.ads_left; return d; }
        catch (e) { if (!/Ждём подтверждения/.test(e.message)) throw e; await new Promise(r => setTimeout(r, 1500)); }
      }
      throw new Error("Adsgram пока не подтвердил просмотр. Награда придёт, если открыть экран ещё раз");
    }
    async function freeBoxAd() {
      if (busy) return; busy = true; render();
      try {
        const d = await watchAd("free_box");
        B = d; boxesAt = Date.now(); lastOpen = { count: 1, free: true };
        showShake(); await new Promise(r => setTimeout(r, 1100)); await chargeReveal(d.results); showResults(d.results);
      } catch (e) { toast(e.message); }
      finally { busy = false; render(); }
    }
    async function attemptAd() {
      if (busy) return; busy = true;
      try { const d = await watchAd("attempt"); GV = d.game; GVat = Date.now(); render(); toast("+1 попытка!"); }
      catch (e) { toast(e.message); } finally { busy = false; }
    }
    async function x2Ad(sid) {
      const b = document.getElementById("x2Btn"); if (!b || busy) return;
      busy = true; b.disabled = true; b.textContent = "Смотрим рекламу…";
      try {
        const d = await watchAd("game_x2", sid);
        document.getElementById("gReward").textContent = "+" + fmt(d.reward * 2);
        b.remove(); toast("Награда удвоена!");
      } catch (e) { toast(e.message); b.disabled = false; b.textContent = "×2 за рекламу"; }
      finally { busy = false; }
    }


    // ================= Профиль =================
    // Украшения рисуются поверх сидящего кота (та же система координат, что в cats.js).
    const DECOR_SVG = {
      beta: `<path d="M20 30 Q50 20 80 30 L80 37 Q50 27 20 37 Z" fill="#21E6FF"/><path d="M80 32 l12 -5 l-3 9 Z M80 35 l10 6 l-10 0 Z" fill="#21E6FF"/><text x="50" y="34" text-anchor="middle" font-size="9" font-weight="900" fill="#0B0A18" font-family="sans-serif">BETA</text>`,
      headphones: `<path d="M18 42 Q18 4 50 4 Q82 4 82 42" stroke="#FF2E88" stroke-width="5" fill="none"/><rect x="11" y="36" width="12" height="18" rx="5" fill="#21E6FF"/><rect x="77" y="36" width="12" height="18" rx="5" fill="#21E6FF"/><circle cx="17" cy="45" r="2" fill="#fff"/><circle cx="83" cy="45" r="2" fill="#fff"/>`,
      visor: `<rect x="22" y="37" width="56" height="13" rx="6.5" fill="#0B0A18" stroke="#FF2E88" stroke-width="2"/><rect x="28" y="41" width="44" height="5" rx="2.5" fill="#FF2E88" opacity=".9"/>`,
      cap: `<path d="M24 26 Q26 6 50 6 Q74 6 76 26 Z" fill="#6B3F2A"/><path d="M50 22 Q72 20 92 26 Q72 30 50 26 Z" fill="#4A2C1E"/><circle cx="50" cy="15" r="5" fill="#FFC94D"/><path d="M47 14 h6 v3 a3 3 0 0 1 -6 0 Z" fill="#6B3F2A"/>`,
      halo: `<ellipse cx="50" cy="2" rx="22" ry="5.5" fill="none" stroke="#FFF27A" stroke-width="3.5"/><ellipse cx="50" cy="2" rx="22" ry="5.5" fill="none" stroke="#FFF27A" stroke-width="8" opacity=".25"/>`,
      crown: `<path d="M28 22 L32 4 L42 14 L50 0 L58 14 L68 4 L72 22 Z" fill="#FFC94D" stroke="#C9821A" stroke-width="1.5"/><circle cx="50" cy="12" r="3" fill="#FF2E88"/><circle cx="37" cy="16" r="2" fill="#21E6FF"/><circle cx="63" cy="16" r="2" fill="#21E6FF"/>`,
    };
    function avatarHtml(catId, decor, size) {
      return `<span class="ava" style="width:${size}px;height:${size}px">${CatArt.svg(catId, "sit", size, { still: true })}${decor && DECOR_SVG[decor] ? `<svg class="decor" viewBox="-6 -8 112 112" aria-hidden="true">${DECOR_SVG[decor]}</svg>` : ""}</span>`;
    }
    let P = null;
    function renderProfile() {
      if (!P) return header("Профиль") + `<div class="err" style="color:var(--muted)">Загрузка…</div>`;
      const names = { players: "Игроки", games: "Мини-игры", refs: "Рефоводы" };
      const unit = (b, v) => b === "players" ? fmt(v) + " мяуконов" : b === "games" ? fmt(v) + " очков" : fmt(v) + " " + plural(v, "друг", "друга", "друзей");
      const owned = S.cats.slice().sort((a, b) => b.rarity - a.rarity || a.cat_id - b.cat_id);
      return header("Профиль") + `
        <div class="panel" style="align-items:center;text-align:center;padding:18px 14px;background:linear-gradient(160deg,#2A1A44,#17122E 70%)">
          <div style="width:118px;height:118px;border-radius:50%;border:3px solid var(--pink);box-shadow:0 0 24px rgba(255,92,168,.45);background:radial-gradient(circle at 50% 40%,#3A2860,#120E24);display:flex;align-items:center;justify-content:center">
            ${P.avatar_cat_id != null ? avatarHtml(P.avatar_cat_id, P.decor, 104) : ""}</div>
          <b style="font-size:20px;margin-top:6px">${esc(S.name)}</b>
          ${P.beta ? `<span class="pill" style="background:rgba(33,230,255,.14);color:#21E6FF">Бета-тестер</span>` : ""}
        </div>
        <div class="sec">Места в рейтингах сезона</div>
        <div class="btns" style="grid-template-columns:repeat(3,minmax(0,1fr))">${Object.keys(names).map(b => { const r = P.ratings[b];
          return `<button class="panel" style="align-items:center;gap:2px;padding:10px 6px;color:var(--text)" onclick="board='${b}';go('rating')">
            <span style="font-size:11px;color:var(--muted)">${names[b]}</span><b style="font-size:24px;color:${r.place && r.place <= 3 ? "var(--gold)" : "var(--text)"}">${r.place ? "#" + r.place : "—"}</b>
            <span style="font-size:10px;color:var(--muted)">${unit(b, r.value)}</span></button>`; }).join("")}</div>
        <div class="sec">Аватар — выбери кота</div>
        <div class="coll">${owned.map(c => `<button onclick="setProfile({avatar_cat_id:${c.cat_id}})" style="border-color:${c.cat_id === P.avatar_cat_id ? "var(--pink)" : COLORS[c.rarity] + "66"};background:${c.cat_id === P.avatar_cat_id ? "#2A1636" : "var(--card)"};color:var(--text)">
            ${CatArt.svg(c.cat_id, "sit", 44, { still: true })}<span>${c.name}</span></button>`).join("")}</div>
        <div class="sec">Украшения</div>
        <div class="coll" style="grid-template-columns:repeat(3,minmax(0,1fr))">${P.decors.map(d => `<button ${d.open ? `onclick="setProfile({decor:'${d.id}'})"` : "disabled"} style="border-color:${d.id === P.decor ? "var(--pink)" : d.open ? "#4B3D85" : "#241D45"};background:${d.id === P.decor ? "#2A1636" : d.open ? "var(--card)" : "#120E24"};color:${d.open ? "var(--text)" : "#5A4E92"};min-height:96px;opacity:1">
            <span style="width:52px;height:52px;display:block;filter:${d.open ? "none" : "grayscale(1) brightness(.5)"}">${P.avatar_cat_id != null ? avatarHtml(P.avatar_cat_id, d.id, 52) : ""}</span>
            <span style="font-size:10px">${d.name}</span>${d.open ? "" : `<span style="font-size:9px;color:#8A80B5;font-weight:500">🔒 ${d.need}</span>`}</button>`).join("")}</div>
        <button class="opt" onclick="Snd.music(!Snd.musicOn);render()">🎵 Музыка и дождь<span>${window.Snd && Snd.musicOn ? "вкл" : "выкл"}</span></button>
        <button class="opt" onclick="Snd.sfx(!Snd.sfxOn);render()">🔊 Звуки<span>${window.Snd && Snd.sfxOn ? "вкл" : "выкл"}</span></button>
        <button class="opt" onclick="watchProlog()" style="margin-top:2px">🎬 Посмотреть пролог<span>40 сек</span></button>
        <div class="sec">Статистика</div>
        <div class="panel">${[["Котов в коллекции", P.stats.cats + " / " + (CATALOG.length || 10)], ["Сыграно мини-игр", P.stats.games], ["Рекорд Десертопада", P.stats.best + " очков"], ["Дней в игре", P.stats.days], ["Обслужено гостей", P.stats.guests]]
          .map(([k, v]) => `<div class="row" style="font-size:14px"><span style="color:var(--muted)">${k}</span><b>${v}</b></div>`).join("")}</div>`;
    }
    async function setProfile(body) {
      try { const d = await api("POST", "/api/profile", body); S = d; loadedAt = Date.now(); P = d.profile; render(); if (tg && tg.HapticFeedback) tg.HapticFeedback.selectionChanged(); }
      catch (e) { toast(e.message); }
    }

    // ---------- общее ----------
    // ================= Уровень кафе =================
    // Опыт за действия: открыть комнату, улучшить, открыть коробку, задание, мини-игра. Уровень открывает комнаты и даёт награды.
    let lvSeen = null;
    function levelBadge() {
      const L = S.level; if (!L) return "";
      const span = Math.max(1, L.to - L.from), pct = Math.min(1, (L.xp - L.from) / span), ready = L.claimable.length > 0;
      const r = 20, c = 2 * Math.PI * r;
      return `<button class="lvlbtn ${ready ? "ready" : ""}" onclick="openLevel()" aria-label="Уровень кафе ${L.level}">
        <svg width="50" height="50" viewBox="0 0 50 50" aria-hidden="true"><circle cx="25" cy="25" r="${r}" fill="#1A1233" stroke="#2C2352" stroke-width="5"/>
        <circle cx="25" cy="25" r="${r}" fill="none" stroke="${ready ? "#FFC94D" : "#21E6FF"}" stroke-width="5" stroke-linecap="round" stroke-dasharray="${(c * pct).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 25 25)"/></svg>
        <b>${L.level}</b><small>ур.</small>${ready ? "<i>!</i>" : ""}</button>`;
    }
    function checkLevelUp() {
      const L = S.level; if (!L) return;
      if (lvSeen != null && L.level > lvSeen) { window.Snd && Snd.play("reward"); toast(`Новый уровень кафе: ${L.level}! Забери награду`); }
      lvSeen = L.level;
    }
    function rewardChips(p) {
      const out = [];
      if (p.coins) out.push(`<span class="lvchip"><span class="coin s"></span>+${fmt(p.coins)}</span>`);
      if (p.box_name) out.push(`<span class="lvchip">${boxIco(p.box_name, 18)} ${p.box_name === "Легендарная" ? "Легендарная коробка" : "Коробка"}</span>`);
      (p.unlocks || []).forEach(u => out.push(`<span class="lvchip un">🔓 ${u}</span>`));
      return out.join("");
    }
    function openLevel() {
      const L = S.level, m = document.getElementById("modal");
      const span = Math.max(1, L.to - L.from), have = L.xp - L.from;
      const ready = L.claimable;
      m.innerHTML = `<div class="dialog lvdlg"><div class="lvbig"><b>${L.level}</b><span>уровень кафе</span></div>
        <div class="lvbar"><div style="width:${Math.min(100, have / span * 100).toFixed(1)}%"></div></div>
        <div class="lvxp">${fmt(have)} / ${fmt(span)} опыта до ${L.level + 1} уровня</div>
        ${ready.length ? `<div class="lvsec">Награды ждут</div>${ready.map(p => `<div class="lvrow"><b>Ур. ${p.level}</b><div>${rewardChips(p) || "—"}</div></div>`).join("")}
            <button class="main pink" onclick="claimLevel()">Забрать награды</button>`
          : `<div class="lvsec">На ${L.next.level} уровне</div><div class="lvrow"><div>${rewardChips(L.next) || "—"}</div></div>`}
        <div class="lvsec">Как получить опыт</div>
        <div class="lvhow"><span>Открыть комнату <b>+100</b></span><span>Улучшение <b>+10</b></span><span>Задание <b>+15</b></span><span>Награда дня <b>+10</b></span><span>Гость с заказом <b>+5</b></span><span>Коробка <b>+5</b></span><span>Десертопад <b>до +25</b></span></div>
        <button class="ghost" style="min-height:40px;border:none;background:none;color:var(--muted)" onclick="closeModal()">Закрыть</button></div>`;
      m.classList.add("on");
    }
    async function claimLevel() {
      if (busy) return; busy = true;
      try {
        const d = await api("POST", "/api/level/claim"); S = d; loadedAt = Date.now(); lvSeen = d.level.level; render();
        window.Snd && Snd.play("upgrade");
        const m = document.getElementById("modal");
        m.innerHTML = `<div class="dialog lvdlg"><div class="lvbig up"><b>${d.to_level}</b><span>${d.to_level > d.from_level ? `уровни ${d.from_level}–${d.to_level}` : "новый уровень"}</span></div>
          <div class="lvchips">${d.reward ? `<span class="lvchip"><span class="coin s"></span>+${fmt(d.reward)}</span>` : ""}${d.boxes.map(b => `<span class="lvchip">${boxIco(b, 18)} ${b === "Легендарная" ? "Легендарная коробка" : "Коробка"}</span>`).join("")}${d.unlocks.map(u => `<span class="lvchip un">🔓 ${u}</span>`).join("")}</div>
          <button class="main pink" id="lvOk">${d.results.length ? "Открыть коробку" : "Отлично"}</button></div>`;
        m.classList.add("on");
        document.getElementById("lvOk").onclick = () => { if (d.results.length) giftReveal(d.results, d.boxes[0], 0); else closeModal(); };
      } catch (e) { toast(e.message); }
      finally { busy = false; }
    }

    // ================= Начало истории =================
    // Первый вход (или старый аккаунт, застрявший в начале): экран «Начать игру» → пролог → команда в сборе
    function showIntro() {
      if (window.Prolog) { window.Snd && Snd.hold(true); Prolog.play({ first: true, onEnd: () => { window.Snd && Snd.hold(false); introTeam(); } }); }
      else introTeam();
    }
    function watchProlog() { closeModal(); if (window.Prolog) { window.Snd && Snd.hold(true); Prolog.play({ onEnd: () => window.Snd && Snd.hold(false) }); } }
    async function introTeam() {
      if (busy) return; busy = true;
      try {
        const d = await api("POST", "/api/intro/team");
        S = d; loadedAt = Date.now(); render();
        const cats = d.new_cats.map(x => catById(x.cat_id)), m = document.getElementById("modal");
        window.Snd && Snd.play("meow"); haptic("medium");
        m.innerHTML = `<div class="dialog introdlg"><b style="font-size:21px">Кафе снова открыто!</b>
          <div class="introtext">Утром на объявления откликнулись двое. А Коробкин, похоже, решил, что касса теперь его.</div>
          ${cats.map(c => `<div class="introcat"><div class="av" style="border-color:${COLORS[c.rarity]}">${CatArt.svg(c.cat_id, "sit", 58)}</div>
            <div><b>${c.name} · ${c.role ? ROLE_NAME[c.role].toLowerCase() : ""}</b><span>${c.memories.texts[0]}</span>${statChips(c.stats, c.role)}</div></div>`).join("")}
          <div class="introtext" style="font-size:13px;color:var(--muted)">На стене — подарок от прежнего хозяина: портрет кота. Интерьер можно менять кнопкой «Интерьер».</div>
          <button class="main pink" onclick="closeModal();setTimeout(()=>openIncome(true),300)">Открыть кафе!</button></div>`;
        m.classList.add("on");
      } catch (e) { toast(e.message); }
      finally { busy = false; }
    }
    // ================= Карта города (пока витрина: районы откроются позже) =================
    function openCity() {
      const m = document.getElementById("modal");
      const D = [["Нижний город", "Здесь твоё кафе", true, 200, 250], ["Рыночная улица", "Скоро", false, 92, 176], ["Небоскрёбы", "Скоро", false, 300, 150], ["Неоновый залив", "Скоро", false, 112, 72], ["Орбита", "Скоро", false, 292, 42]];
      let blocks = ""; for (let n = 0; n < 24; n++) { const x = 18 + (n * 61) % 360, y = 26 + (n * 97) % 250, h = 10 + (n * 13) % 24; blocks += `<rect x="${x}" y="${y}" width="15" height="${h}" fill="#1A1236"/><rect x="${x + 4}" y="${y + 4}" width="3" height="3" fill="${["#FFC94D", "#21E6FF", "#FF5CA8"][n % 3]}" opacity=".7"/>`; }
      const roads = `M200 250 L92 176 M200 250 L300 150 M92 176 L112 72 M300 150 L292 42 M112 72 L292 42`;
      m.innerHTML = `<div class="dialog citydlg"><b style="font-size:19px">Карта города</b>
        <svg viewBox="0 0 400 300" class="citymap" role="img" aria-label="Карта города"><rect width="400" height="300" fill="#0B0720"/>${blocks}
          <path d="${roads}" stroke="#3A2D66" stroke-width="9" stroke-linecap="round" fill="none"/><path d="${roads}" stroke="#21E6FF" stroke-width="1.2" stroke-dasharray="4 6" fill="none" opacity=".6"/>
          ${D.map(([n, s, own, x, y]) => `<circle cx="${x}" cy="${y}" r="20" fill="${own ? "rgba(255,92,168,.25)" : "rgba(33,230,255,.08)"}" stroke="${own ? "#FF5CA8" : "#4A3A80"}" stroke-width="2"/><circle cx="${x}" cy="${y}" r="6" fill="${own ? "#FF5CA8" : "#2B2058"}" stroke="${own ? "#FFE0EF" : "#8F80D8"}" stroke-width="2"/>
            <text x="${x}" y="${y + 36}" text-anchor="middle" font-size="12.5" font-weight="800" fill="${own ? "#FFE0EF" : "#CFC6F0"}" font-family="sans-serif">${n}</text><text x="${x}" y="${y + 50}" text-anchor="middle" font-size="10.5" fill="${own ? "#FF8FC4" : "#8F80D8"}" font-family="sans-serif">${s}</text>`).join("")}</svg>
        <div style="font-size:13px;color:var(--muted);line-height:1.45">Новые районы откроются с уровнем кафе. В каждом будет свой эпизод истории города.</div>
        <button class="main" onclick="closeModal()">Вернуться в кафе</button></div>`;
      m.classList.add("on");
    }

    function render() {
      checkLevelUp();
      document.getElementById("app").innerHTML = view === "cafe" ? renderCafe() : view === "boxes" ? renderBoxes() : view === "cats" ? renderCats() : view === "games" ? renderGames() : view === "tasks" ? renderTasks() : view === "rating" ? renderRating() : view === "profile" ? renderProfile() : renderFriends();
      document.getElementById("nav").style.display = "grid";
      document.getElementById("navCafe").classList.toggle("on", view === "cafe");
      document.getElementById("navBoxes").classList.toggle("on", view === "boxes");
      document.getElementById("navCats").classList.toggle("on", view === "cats");
      document.getElementById("navGames").classList.toggle("on", view === "games");
      document.getElementById("navTasks").classList.toggle("on", view === "tasks");
      document.getElementById("navFriends").classList.toggle("on", view === "friends");
      if (view === "cafe") { mountRoom(); fitRoom(); }
      tick();
    }

    async function go(v) {
      view = v; render();
      if (v === "boxes") {
        try { const d = await api("GET", "/api/boxes"); S = d; loadedAt = Date.now(); B = d; boxesAt = Date.now(); render(); }
        catch (e) { toast(e.message); }
      }
      if (v === "rating") loadRating();
      if (v === "profile") {
        try { const d = await api("GET", "/api/profile"); S = d; loadedAt = Date.now(); P = d.profile; render(); }
        catch (e) { toast(e.message); }
      }
      if (v === "friends") {
        try { const d = await api("GET", "/api/friends"); S = d; loadedAt = Date.now(); F = d.friends; Fat = Date.now(); render(); }
        catch (e) { toast(e.message); }
      }
      if (v === "tasks") {
        try { const d = await api("GET", "/api/tasks"); S = d; loadedAt = Date.now(); render(); }
        catch (e) { toast(e.message); }
      }
      if (v === "games") {
        try { const d = await api("GET", "/api/game"); S = d; loadedAt = Date.now(); GV = d.game; GVat = Date.now(); ADL = d.ads_left; render(); }
        catch (e) { toast(e.message); }
      }
    }

    // Плавно показываем рост копилки. Настоящую сумму считает сервер.
    function tick() {
      if (view === "cafe") updateUpgradeHints();
      if (!S) return;
      if (view === "cafe" && Date.now() - loadedAt > 120000) refreshState();   // раз в пару минут сверяемся с сервером
      if (view === "cafe" && document.getElementById("bankBar")) {
        const dt = (Date.now() - loadedAt) / 1000;
        const elapsed = Math.min(S.elapsed_sec + dt, S.cap_sec);
        const full = elapsed >= S.cap_sec;
        document.getElementById("bankBar").style.width = (elapsed / S.cap_sec * 100).toFixed(1) + "%";
        document.getElementById("bankTime").textContent = full ? "полная — собери!" : hm(elapsed) + " из " + hm(S.cap_sec);
        document.getElementById("bankTitle").textContent = full ? "Копилка полна!" : "Копилка";
        document.getElementById("bankSum").textContent = "+" + fmt(S.income * elapsed);
        document.getElementById("bank").classList.toggle("full", full);
      }
      const sl = document.getElementById("seasonLeft");
      if (view === "rating" && sl && R && !R.season.ended) sl.textContent = "до конца " + dhm(Math.max(0, R.season.ends_in - (Date.now() - Rat) / 1000));
      const fb2 = document.getElementById("fBtn");
      if (view === "friends" && fb2 && F && F.collect_in > 0) {
        const left = Math.max(0, F.collect_in - (Date.now() - Fat) / 1000);
        if (left > 0) fb2.textContent = "Следующий сбор через " + hms(left); else { F.collect_in = 0; render(); }
      }
      const gn = document.getElementById("gNext");
      if (view === "games" && gn && GV) {
        const left = Math.max(0, GV.next_attempt_in - (Date.now() - GVat) / 1000);
        gn.innerHTML = `Попытки ${GV.attempts} / ${GV.attempts_max}` + (left > 0 ? "<br>+1 через " + hms(left) : "");
        if (GV.next_attempt_in > 0 && left <= 0) { GV.next_attempt_in = 0; go("games"); }
      }
      const fb = document.getElementById("freeBtn");
      if (view === "boxes" && fb && B) {
        const left = Math.max(0, B.free_box_in - (Date.now() - boxesAt) / 1000);
        fb.textContent = left > 0 ? "Коробка за рекламу через " + hms(left) : freeLabel();
        fb.disabled = left > 0 || busy;
      }
    }
    setInterval(tick, 1000);
    addEventListener("resize", () => { if (typeof fitCityWindow === "function") fitCityWindow(); });
    document.getElementById("field").addEventListener("pointerdown", gameTap);

    // Имена игроков приходят из Telegram и могут содержать HTML — всегда экранируем перед вставкой.
    function esc(s) { return String(s == null ? "" : s).replace(/[&<>"'`]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;", "`": "&#96;" })[ch]); }
    function toast(text) {
      const t = document.getElementById("toast");
      t.textContent = text; t.style.display = "block";
      clearTimeout(toast.timer); toast.timer = setTimeout(() => t.style.display = "none", 1800);
    }

    function softUpdate() {   // обновить цифры без перерисовки комнаты — гости и коты остаются на местах
      const c = document.getElementById("coins"); if (c) c.textContent = fmt(S.coins);
      const fl = document.getElementById("flow"); if (fl) fl.outerHTML = flowHtml();
      updateUpgradeHints(); tick();
    }
    async function doCollect() {
      const btn = document.getElementById("collectBtn");
      btn.disabled = true;
      try {
        const data = await api("POST", "/api/collect");
        S = data; loadedAt = Date.now(); softUpdate(); btn.disabled = false;
        toast("+" + fmt(data.collected) + " мяуконов");
        window.Snd && Snd.play("coin");
        if (tg && tg.HapticFeedback) tg.HapticFeedback.impactOccurred("light");
      } catch (e) { toast(e.message); }
    }

    const hideSplash = window.hideSplash || ((f) => f && f());   // заставка живёт в index.html

    api("POST", "/api/auth")
      .then((data) => { S = data; CATALOG = data.catalog || []; loadedAt = Date.now(); render();
        hideSplash(() => { if ((data.intro_step || 0) < 2) showIntro(); });
        // «Друзья» подгружаем заранее в фоне — вкладка открывается сразу, без «Загрузка…»
        setTimeout(() => api("GET", "/api/friends").then((d) => { F = d.friends; Fat = Date.now(); if (view === "friends") render(); }).catch(() => {}), 1500); })
      .catch((e) => {
        hideSplash();
        const noData = initData === "dev";
        const ver = tg ? (tg.platform + " · " + tg.version) : "нет Telegram";
        document.getElementById("app").innerHTML = '<div class="err">' + (noData
          ? 'Telegram не передал данные входа.<br><br>Закрой это окно и открой игру кнопкой «Играть» в меню бота. Если не помогло — обнови Telegram Desktop.'
          : 'Не удалось войти: ' + e.message) + '</div><div class="note" style="margin-top:12px">' + ver + '</div>'
          + '<button class="main" style="margin-top:16px" onclick="location.reload()">Попробовать ещё раз</button>';
      });
