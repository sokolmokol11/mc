# MeowCafe — шаг 1: скелет

Что работает: бот с кнопкой «Играть» → мини-приложение → сервер проверяет подпись Telegram → игрок создаётся в базе и видит своё имя и 20 000 мяуконов.

## 1. Подготовка в Telegram (BotFather)

1. `/mybots` → твой бот → **Bot Settings → Menu Button** → укажи адрес `https://твой-домен.ru` (кнопка слева от поля ввода).
2. `/newapp` → выбери бота → название MeowCafe, адрес `https://твой-домен.ru`, короткое имя, например `play`.
   Тогда реферальные ссылки будут вида `https://t.me/<бот>/play?startapp=ref_<id>`.

## 2. Сервер (VPS, Ubuntu)

```bash
cd meowcafe/backend
python3 -m venv ../.venv && source ../.venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # и вписать BOT_TOKEN и WEBAPP_URL
python -m pytest -q         # должно быть 5 passed
uvicorn main:app --host 127.0.0.1 --port 8000
```

Проверка: `curl http://127.0.0.1:8000/api/health` → `{"ok":true}`.

## 3. HTTPS через nginx

Telegram открывает мини-приложения только по https.

```nginx
server {
    server_name твой-домен.ru;
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

```bash
sudo apt install nginx certbot python3-certbot-nginx
sudo nano /etc/nginx/sites-available/meowcafe   # вставить конфиг выше
sudo ln -s /etc/nginx/sites-available/meowcafe /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d твой-домен.ru
```

## 4. Бот

```bash
cd meowcafe/bot
source ../.venv/bin/activate
python bot.py
```

Напиши боту `/start` → «Играть» → должно появиться «Добро пожаловать, <имя>!» и 20 000 мяуконов.

## 5. Чтобы всё работало после перезагрузки (systemd)

`/etc/systemd/system/meowcafe-api.service`:

```ini
[Unit]
Description=MeowCafe API
After=network.target

[Service]
WorkingDirectory=/root/meowcafe/backend
ExecStart=/root/meowcafe/.venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

Такой же файл `meowcafe-bot.service` с `WorkingDirectory=/root/meowcafe/bot` и `ExecStart=/root/meowcafe/.venv/bin/python bot.py`. Затем:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now meowcafe-api meowcafe-bot
```

## Отладка в обычном браузере

Только на своём компьютере: `DEV_MODE=1` в `.env`, запустить uvicorn и открыть `http://127.0.0.1:8000`. На сервере `DEV_MODE` всегда `0`, иначе любой сможет войти без Telegram.

## Структура

```
backend/   config.py (все цифры игры) · auth.py (подпись Telegram) · models.py (таблицы) · routers/ (API) · tests/
frontend/  index.html
bot/       bot.py
```

## Промокоды

На сервере, из папки backend:

```
../.venv/bin/python admin.py promo add MEOW2026 --coins 50000 --box 2 --uses 100 --days 7
../.venv/bin/python admin.py promo list
../.venv/bin/python admin.py promo off MEOW2026
```

- `--coins` — мяуконы; `--box` — коробка в подарок (0 картонная … 4 космическая)
- `--uses` — сколько всего активаций (не указывать — без ограничения), `--days` — срок действия
- один игрок может ввести код один раз; мяуконы из промокода не идут в рейтинг «Игроки»
- перезапускать сервер не нужно


## 7. PostgreSQL, бэкапы и сторож (один раз)

```bash
bash /root/meowcafe/deploy/setup_server.sh ТВОЙ_TELEGRAM_ID
```
Скрипт ставит PostgreSQL, переносит туда все данные из SQLite (старый файл остаётся копией), запускает
сервер в 2–4 процесса, включает ночной бэкап (04:00, хранится 14 дней в `/root/backups` + файл тебе в Telegram)
и сторожа: каждые 2 минуты проверяет `/api/health`, если игра не отвечает — перезапускает и пишет тебе.

Восстановить базу из бэкапа:
```bash
systemctl stop mc-api
runuser -u postgres -- pg_restore --clean --if-exists -d meowcafe /root/backups/meowcafe-ГГГГ-ММ-ДД.dump
systemctl start mc-api
```

Если лёг весь сервер (а не только игра), сторож тоже молчит — для этого внешний монитор UptimeRobot
(uptimerobot.com, бесплатно): HTTP(s)-монитор на `https://meowcafe-game.ru/api/health`, интервал 5 минут.

## 8. Коты в игре

Какие коты выпадают из коробок, задаёт `ACTIVE_CATS` в `.env` (id = редкость × 4 + номер):

| редкость | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| Обычные | 0 Батон | 1 Коробкин | 2 Соня | 3 Рыжик |
| Редкие | 4 Сосиска | 5 Дед | 6 Уголёк | 7 Бизнес-кот |
| Эпические | 8 Луна | 9 Неон | 10 Дымка | 11 Кекс |
| Легендарные | 12 Самурай | 13 Кибер | 14 Комета | 15 Граф |
| Мифические | 16 Космо | 17 Нова | 18 Орион | 19 Пульсар |

Добавить кота: дописать его номер в `ACTIVE_CATS`, затем `systemctl restart mc-api`. Убирать котов, которые
уже у кого-то есть, можно — у игроков они остаются, просто перестают выпадать.

## 9. Проверка игроков и ферм

```bash
cd /root/meowcafe/backend
../.venv/bin/python admin.py stats              # игроки, новые, активные сегодня
../.venv/bin/python admin.py top refs           # топ-10 с пометками ⚠ (players | games | refs)
../.venv/bin/python admin.py suspects           # похожие на фермы рефералов
../.venv/bin/python admin.py user 123456789     # подробно об игроке
../.venv/bin/python admin.py ban 123456789 --refs   # убрать из рейтингов вместе с приглашёнными
../.venv/bin/python admin.py unban 123456789
```
Перед выплатой призов всегда смотри `top` по всем трём рейтингам и `user` по призёрам.
