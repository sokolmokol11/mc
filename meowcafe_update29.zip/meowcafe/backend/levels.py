"""
Уровень кафе. Опыт копится за действия (открыть комнату, улучшить, открыть коробку, задание, мини-игра),
уровень открывает комнаты и даёт награды. Награды забираются кнопкой — POST /api/level/claim.
"""
from config import GAME_XP_DAY_CAP, GAME_XP_MAX, LEVEL_REWARD_AFTER, LEVEL_REWARDS, LOCATIONS, XP
import quests as qs


def xp_for(level: int) -> int:
    """Сколько опыта всего нужно, чтобы дойти до уровня level."""
    return 0 if level <= 1 else int(round(60 * (level - 1) ** 1.7))


def level_of(xp: int) -> int:
    lvl = 1
    while xp >= xp_for(lvl + 1):
        lvl += 1
    return lvl


def reward_of(level: int):
    if level in LEVEL_REWARDS:
        return LEVEL_REWARDS[level]
    if level < 2:
        return (None, None)
    return LEVEL_REWARD_AFTER[(level - max(LEVEL_REWARDS) - 1) % len(LEVEL_REWARD_AFTER)]


def unlocks_of(level: int) -> list[str]:
    out = [f"Можно открыть комнату «{name}»" for name, _p, _s, _m, need in LOCATIONS if need == level and need > 1]
    return out


def add_xp(user, amount: int) -> None:
    user.xp = (user.xp or 0) + max(0, int(amount))


def add(user, kind: str, count: int = 1) -> None:
    add_xp(user, XP[kind] * count)


def add_game_xp(user, score: int, now) -> int:
    """Опыт за Десертопад: 5 + очки/10, не больше 25 за игру и 100 в сутки."""
    day = qs.day_index(now)
    if (user.xp_game_day or 0) != day:
        user.xp_game_day, user.xp_game_today = day, 0
    want = min(GAME_XP_MAX, 5 + max(0, score) // 10)
    got = max(0, min(want, GAME_XP_DAY_CAP - (user.xp_game_today or 0)))
    user.xp_game_today = (user.xp_game_today or 0) + got
    add_xp(user, got)
    return got


def view(user, income: float) -> dict:
    xp = user.xp or 0
    lvl = level_of(xp)
    claimed = user.level_claimed or 1
    pending = []
    for l in range(claimed + 1, lvl + 1):
        rule, box = reward_of(l)
        pending.append({"level": l, "coins": qs.scaled_reward(income, rule) / 100, "box": box, "box_name": qs.box_name(box),
                        "unlocks": unlocks_of(l)})
    nxt = lvl + 1
    rule, box = reward_of(nxt)
    return {"level": lvl, "xp": xp, "from": xp_for(lvl), "to": xp_for(nxt), "claimable": pending,
            "next": {"level": nxt, "coins": qs.scaled_reward(income, rule) / 100, "box_name": qs.box_name(box), "unlocks": unlocks_of(nxt)}}
