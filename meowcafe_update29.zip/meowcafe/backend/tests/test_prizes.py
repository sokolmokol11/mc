"""Призы: деление фонда и отсечение призов меньше $2."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import MIN_PRIZE_USD, PRIZE_BOARDS, PRIZE_SPLIT  # noqa: E402
from prizes import board_prizes  # noqa: E402


def test_split_sums_to_100():
    assert sum(PRIZE_SPLIT) == 100
    assert abs(sum(PRIZE_BOARDS.values()) - 1) < 1e-9


def test_big_pool_pays_all_places():
    p = board_prizes("players", pool=1000)       # на «Игроков» 500$
    assert len(p) == 10 and p[0] == 150 and p == sorted(p, reverse=True)


def test_small_pool_cuts_tiny_prizes():
    p = board_prizes("games", pool=40)           # на «Мини-игры» 10$: 3, 1.8, 1.2... — остаётся только 1-е место
    assert p == [3.0]
    assert all(x >= MIN_PRIZE_USD for x in board_prizes("refs", pool=100))
    assert board_prizes("players", pool=0) == []
