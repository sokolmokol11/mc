"""Тесты Десертопада. Запуск из папки backend:  python -m pytest -q"""
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import game_logic as gl  # noqa: E402

GAME_JS = Path(__file__).resolve().parent.parent.parent / "frontend" / "game.js"


def honest_taps(seed, every=1, delay_ms=600, jitter=1.5):
    """Тапы «человека»: ловит каждый every-й десерт с задержкой реакции, чуть мимо центра."""
    taps = []
    for i, it in enumerate(gl.schedule(seed)):
        if it["kind"] == "rock" or i % every:
            continue
        t = it["t0"] + 8000 / it["v"] + delay_ms + (i % 5) * 37
        if t > gl.DURATION_MS:
            continue
        taps.append([t, it["x"] + jitter * ((i % 3) - 1), gl.y_at(it, t) + jitter])
    taps.sort()
    taps += [[taps[-1][0] + 5, 50, 1]] if taps else []  # пара промахов, как у людей
    return taps


def test_generator_deterministic():
    assert gl.schedule(123) == gl.schedule(123)
    assert gl.schedule(123) != gl.schedule(124)
    n = len(gl.schedule(5))
    assert 80 < n < 140  # примерно 3–4 предмета в секунду за 30 секунд


def test_python_matches_javascript():
    """Генератор в браузере и на сервере даёт ровно те же предметы."""
    node = shutil.which("node")
    if node is None:
        return  # на сервере без node тест пропускаем, у разработчика он запускается
    seeds = [1, 42, 2026, 123456789, 2147483647]
    js = f"const D=require({json.dumps(str(GAME_JS))});console.log(JSON.stringify({seeds}.map(s=>D.schedule(s))))"
    out = json.loads(subprocess.check_output([node, "-e", js]))
    for seed, js_items in zip(seeds, out):
        py_items = gl.schedule(seed)
        assert len(py_items) == len(js_items)
        for a, b in zip(py_items, js_items):
            assert a["kind"] == b["kind"] and a["x"] == b["x"] and a["v"] == b["v"] and a["t0"] == b["t0"]


def test_honest_play_counts():
    taps = honest_taps(77, every=2)
    res = gl.verify(77, taps)
    assert res["score"] > 0 and not res["flagged"], res


def test_random_taps_score_little():
    taps = [[t, (t * 7) % 100, (t * 3) % 100] for t in range(100, 20000, 400)]
    res = gl.verify(5, taps)
    assert res["score"] < 10


def test_bot_instant_reaction_flagged():
    """Скрипт, который тапает каждый десерт сразу как он показался, ловится."""
    taps = []
    for it in gl.schedule(9):
        if it["kind"] == "rock":
            continue
        t = it["t0"] + 8000 / it["v"] + 20
        if t < gl.DURATION_MS:
            taps.append([t, it["x"], gl.y_at(it, t)])
    taps.sort()
    res = gl.verify(9, taps)
    assert res["flagged"] and "inhuman_reaction" in res["reasons"]


def test_tap_spam_and_garbage_flagged():
    spam = [[i * 10, 50, 50] for i in range(500)]
    assert "too_many_taps" in gl.verify(1, spam)["reasons"]
    assert "bad_tap" in gl.verify(1, [[5000, 50, 50], [100, 50, 50]])["reasons"]   # время назад
    assert "bad_tap" in gl.verify(1, [["x", 1, 2]])["reasons"]


def test_rock_takes_quarter():
    items = gl.schedule(31)
    good = [it for it in items if it["kind"] != "rock"][:8]
    rock = next(it for it in items if it["kind"] == "rock" and it["t0"] > max(g["t0"] for g in good))
    taps = []
    for it in good + [rock]:
        t = it["t0"] + 8000 / it["v"] + 700
        taps.append([t, it["x"], gl.y_at(it, t)])
    taps.sort()
    res = gl.verify(31, taps)
    assert res["rocks"] == 1
    before = sum(g["pts"] for g in good)
    assert res["score"] == before - -(-before * 25 // 100)  # минус 25% с округлением вверх
