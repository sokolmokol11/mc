"""Тесты гостей с заказами. Запуск из папки backend:  python -m pytest -q"""
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import economy as eco  # noqa: E402
from config import GUEST_ORDER_CHANCE, GUEST_WINDOW_MIN  # noqa: E402

T0 = datetime(2026, 10, 17, 12, 0, tzinfo=timezone.utc)


def test_window_changes_every_15_min():
    w = eco.guest_window(T0)
    assert eco.guest_window(T0 + timedelta(minutes=GUEST_WINDOW_MIN - 1)) == w
    assert eco.guest_window(T0 + timedelta(minutes=GUEST_WINDOW_MIN)) == w + 1


def test_order_is_stable_and_secret_dependent():
    a = [eco.guest_order(42, w, "secret-A") for w in range(1000)]
    assert a == [eco.guest_order(42, w, "secret-A") for w in range(1000)]   # одинаково при повторе
    assert a != [eco.guest_order(42, w, "secret-B") for w in range(1000)]   # без секрета не угадать


def test_order_rate_and_rarities():
    orders = [eco.guest_order(7, w, "s") for w in range(20_000)]
    share = sum(o is not None for o in orders) / len(orders)
    assert abs(share - GUEST_ORDER_CHANCE) < 0.02
    assert {o for o in orders if o is not None} == {0, 1, 2}  # гости не просят легендарных и мификов
