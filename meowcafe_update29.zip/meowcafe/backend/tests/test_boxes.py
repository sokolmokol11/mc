"""Ядро v2: коты на местах, формула кафе, коробка. Запуск из папки backend:  python -m pytest -q"""
import sys
from pathlib import Path
from types import SimpleNamespace as NS

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import service as sv  # noqa: E402


def user(cats=(), **kw):
    base = dict(cats=[NS(cat_id=c, level=l, location=r, slot=s) for c, l, r, s in cats], locations_open=2,
                tables="1,0;0,0,0", kitchen_level=1, coffee_level=1, fridge_level=0, cash_level=1, play_level=1)
    base.update(kw)
    return NS(**base)


DISHES = {"coffee": 1, "bun": 1}


def test_empty_cafe_earns_nothing():
    m = sv.breakdown(user(), DISHES)
    assert m["total"] == 0 and m["neck"] == "cashier"


def test_cashier_alone_earns_nothing_until_team():
    m = sv.breakdown(user([(4, 1, 0, 0)]), DISHES)          # Коробкин на кассе
    assert m["total"] == 0 and m["neck"] == "cook"
    m = sv.breakdown(user([(4, 1, 0, 0), (0, 1, 1, 0)]), DISHES)   # + повар, но нет официанта
    assert m["total"] == 0 and m["neck"] == "waiter"


def test_start_team_income():
    m = sv.breakdown(user([(4, 1, 0, 0), (0, 1, 1, 0), (1, 1, 0, 1)]), DISHES)
    assert abs(m["guests"] - 0.02 * 1.6) < 1e-9             # Сосиска официант 6
    assert abs(m["kitchen"] - 0.024 * 1.6) < 1e-9           # печь + кофемашина, Батон повар 6
    assert m["neck"] == "guests" and 0.4 < m["total"] < 0.8


def test_table_without_table_or_cat_gives_no_guests():
    # официант на месте, где столик не куплен
    m = sv.breakdown(user([(4, 1, 0, 0), (0, 1, 1, 0), (1, 1, 0, 2)]), DISHES)
    assert m["guests"] == 0


def test_cat_level_raises_stats():
    assert sv.cat_stats(1, 1)["wait"] == 6
    assert abs(sv.cat_stats(1, 5)["wait"] - 6 * 1.6) < 1e-9


def test_closed_rooms_do_not_work():
    cats = [(4, 1, 0, 0), (0, 1, 1, 0), (1, 1, 2, 0)]
    assert sv.breakdown(user(cats, tables="1,0;1,0,0"), DISHES)["guests"] == 0
    assert sv.breakdown(user(cats, tables="1,0;1,0,0", locations_open=3), DISHES)["guests"] > 0


def test_menu_variety_raises_check():
    assert sv.avg_check({"coffee": 1, "bun": 1, "donut": 1}) > sv.avg_check({"coffee": 1, "bun": 1})


def test_costs_grow():
    assert sv.table_buy_cost({0: [1, 0], 2: [0, 0, 0]}) < sv.table_buy_cost({0: [1, 1], 2: [0, 0, 0]})
    assert sv.equip_cost("oven", 1) < sv.equip_cost("oven", 2)
    assert sv.equip_cost("fridge", 0) == 4000
