"""Тесты экономики. Запуск из папки backend:  python -m pytest -q"""
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import economy as eco  # noqa: E402
from config import CENTS, GIFT_CHANCES  # noqa: E402

T0 = datetime(2026, 10, 17, 12, 0, tzinfo=timezone.utc)


def test_cat_ids_and_names():
    assert eco.cat_info(0)["name"] == "Батон"
    assert eco.cat_info(8)["name"] == "Луна" and eco.cat_info(8)["rarity"] == 2
    assert eco.cat_info(17)["name"] == "Турбо" and eco.cat_info(17)["rarity"] == 4


def test_piggy_bank_cap_4h():
    inc = 1.0
    assert eco.pending_cents(inc, T0, T0 + timedelta(hours=1), 1) == 3600 * CENTS
    assert eco.pending_cents(inc, T0, T0 + timedelta(hours=10), 1) == 4 * 3600 * CENTS   # упёрлись в 4 ч
    assert eco.pending_cents(inc, T0, T0 + timedelta(hours=10), 2) == 5 * 3600 * CENTS   # копилка ур. 2 = 5 ч
    assert eco.pending_cents(inc, T0, T0 - timedelta(hours=1), 1) == 0                   # время назад — ноль


def test_naive_datetime_from_sqlite():
    naive = T0.replace(tzinfo=None)  # так даты возвращает SQLite
    assert eco.pending_cents(1.0, naive, T0 + timedelta(seconds=10), 1) == 10 * CENTS


def test_gift_is_always_rare():
    """Подарок новичку — всегда редкий кот, чтобы у всех был равный старт. Сам кот — любой из доступных редких."""
    rng = random.Random(1)
    cats = [eco.roll_cat(GIFT_CHANCES, rng) for _ in range(2000)]
    assert {eco.cat_rarity(c) for c in cats} == {1}
    assert set(cats) == set(eco.pool(1))


def test_roll_matches_chances():
    rng = random.Random(7)
    chances = [70, 22, 7, 1, 0]
    n = 50_000
    counts = [0] * 5
    for _ in range(n):
        counts[eco.roll_rarity(chances, rng)] += 1
    for r, c in enumerate(chances):
        assert abs(counts[r] / n * 100 - c) < 1.0  # в пределах 1 процентного пункта
    assert counts[4] == 0


def test_only_active_cats_drop():
    """Из коробок выпадают только коты из ACTIVE_CATS."""
    from config import ACTIVE_CATS
    rng = random.Random(3)
    got = {eco.roll_cat([20, 20, 20, 20, 20], rng) for _ in range(3000)}
    assert got <= set(ACTIVE_CATS) and len(got) == len(ACTIVE_CATS)
