"""Тесты проверки подписи Telegram. Запуск из папки backend:  python -m pytest -q"""
import hashlib
import hmac
import json
import sys
import time
from pathlib import Path
from urllib.parse import urlencode

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from auth import AuthError, verify_init_data  # noqa: E402

TOKEN = "123456:TEST-TOKEN"


def make_init_data(user: dict, token: str = TOKEN, auth_date: int | None = None, **extra) -> str:
    """Собирает initData так же, как это делает Telegram."""
    fields = {"auth_date": str(auth_date or int(time.time())), "user": json.dumps(user, ensure_ascii=False), **extra}
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(fields.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    fields["hash"] = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    return urlencode(fields)


def test_valid():
    data = verify_init_data(make_init_data({"id": 42, "first_name": "Максим"}, start_param="ref_7"), TOKEN)
    assert data["user"]["id"] == 42
    assert data["user"]["first_name"] == "Максим"
    assert data["start_param"] == "ref_7"


def test_wrong_token():
    with pytest.raises(AuthError):
        verify_init_data(make_init_data({"id": 42}), "999:OTHER")


def test_tampered_user():
    raw = make_init_data({"id": 42, "first_name": "Максим"})
    tampered = raw.replace("42", "43", 1)  # пытаемся выдать себя за другого
    with pytest.raises(AuthError):
        verify_init_data(tampered, TOKEN)


def test_expired():
    old = int(time.time()) - 2 * 86400
    with pytest.raises(AuthError):
        verify_init_data(make_init_data({"id": 42}, auth_date=old), TOKEN)


def test_no_hash():
    with pytest.raises(AuthError):
        verify_init_data("auth_date=1&user=%7B%7D", TOKEN)
