"""
Команды для админа (запускать на сервере из папки backend):

  ../.venv/bin/python admin.py promo add MEOW2026 --coins 50000 --box 2 --uses 100 --days 7
  ../.venv/bin/python admin.py promo list
  ../.venv/bin/python admin.py promo off MEOW2026

  --coins  сколько мяуконов дать (можно не указывать)
  --box    какую коробку открыть в подарок: 0 картонная, 1 деревянная, 2 серебряная, 3 золотая, 4 космическая
  --uses   сколько всего активаций (0 или не указывать — без ограничения)
  --days   сколько дней действует (не указывать — бессрочно)
Сервер перезапускать не нужно: промокод работает сразу.

Проверка игроков и защита от ферм:
  ../.venv/bin/python admin.py stats                 — сколько игроков, новых, активных сегодня
  ../.venv/bin/python admin.py top players           — топ-10 рейтинга с пометками подозрительных (players | games | refs)
  ../.venv/bin/python admin.py suspects              — кто похож на ферму рефералов (самые подозрительные сверху)
  ../.venv/bin/python admin.py user 123456789        — всё об игроке: доход, друзья, подозрительные игры
  ../.venv/bin/python admin.py ban 123456789         — убрать из рейтингов (игра у него продолжает работать)
  ../.venv/bin/python admin.py ban 123456789 --refs  — и всех его приглашённых тоже
  ../.venv/bin/python admin.py unban 123456789

Сезоны (даты — по Москве, сезон начинается в 00:00 указанного дня):
  ../.venv/bin/python admin.py season show
  ../.venv/bin/python admin.py season set --name "Бета-тест" --start 2026-10-25 --end 2026-11-01
       — поменять название и даты ТЕКУЩЕГО сезона (очки игроков не трогает)
  ../.venv/bin/python admin.py season new --name "Сезон 1" --start 2026-11-01 --days 30
       — начать НОВЫЙ сезон: обнуляет очки рейтингов (заработано за сезон, очки мини-игр, друзья).
         Коты, мяуконы, улучшения остаются.
  ../.venv/bin/python admin.py wipe
       — удалить ВСЕХ игроков и весь прогресс (чистый старт беты). Промокоды остаются. Спросит подтверждение.
"""
import argparse
import statistics
from datetime import timedelta

from sqlalchemy import func, select

import economy as eco
import quests as qs
from config import BOXES, CENTS
from db import SessionLocal, auto_migrate
from models import AdView, BoxOpening, GameSession, PromoCode, PromoUse, Season, User, UserCat, UserPity, UserTask, utcnow
from routers.player import display_name, income_of
from routers.promo import normalize
from routers.rating import BOARDS, board_rows


def fmt(cents: int) -> str:
    v = (cents or 0) / CENTS
    return f"{v / 1e6:.1f}M" if v >= 1e6 else f"{v / 1e3:.1f}K" if v >= 1e3 else f"{v:.0f}"


def game_flags(db, uid: int) -> tuple[int, int]:
    total = db.scalar(select(func.count()).select_from(GameSession).where(GameSession.user_id == uid,
                                                                         GameSession.finished_at.is_not(None))) or 0
    flagged = db.scalar(select(func.count()).select_from(GameSession).where(GameSession.user_id == uid,
                                                                           GameSession.flagged.is_(True))) or 0
    return total, flagged


def farm_signals(db, referrer: User) -> dict:
    """
    Признаки фермы среди приглашённых. Ни один признак сам по себе не доказательство — смотри на сумму.
      burst  — доля друзей, пришедших пачкой (3+ человека в течение 10 минут)
      nearid — доля друзей с «соседними» Telegram id (аккаунты, зарегистрированные подряд, — типичная ферма)
      nouser — доля друзей без @username
      flag   — доля подозрительных партий в мини-игре у друзей
      same   — друзья делают одно и то же: почти одинаковые очки в играх
    """
    refs = db.scalars(select(User).where(User.referrer_id == referrer.tg_id)).all()
    n = len(refs)
    if n == 0:
        return {"n": 0, "active": 0, "score": 0}
    times = sorted(eco.as_utc(r.created_at).timestamp() for r in refs)
    burst = sum(1 for i, t in enumerate(times)
                if sum(1 for u in times if abs(u - t) <= 600) >= 3) / n
    ids = sorted(r.tg_id for r in refs)
    near = sum(1 for i, x in enumerate(ids) if (i > 0 and x - ids[i - 1] < 20000) or (i + 1 < n and ids[i + 1] - x < 20000)) / n
    nouser = sum(1 for r in refs if not r.username) / n
    games = flagged = 0
    for r in refs:
        g, f = game_flags(db, r.tg_id)
        games += g
        flagged += f
    flag = flagged / games if games else 0
    scores = [s for (s,) in db.execute(select(GameSession.score).where(
        GameSession.user_id.in_(ids), GameSession.finished_at.is_not(None)).limit(2000))]
    same = 0.0
    if len(scores) >= 10:
        spread = statistics.pstdev(scores)
        same = 1.0 if spread < 2 else 0.5 if spread < 4 else 0.0
    active = sum(1 for r in refs if r.is_active_ref)
    score = round(100 * (0.30 * burst + 0.30 * near + 0.10 * nouser + 0.20 * flag + 0.10 * same) * min(1, n / 5))
    return {"n": n, "active": active, "burst": burst, "near": near, "nouser": nouser, "flag": flag, "same": same,
            "score": score}


def cmd_stats(db):
    now = utcnow()
    today = qs.day_index(now)
    day_start = now - timedelta(seconds=86400 - qs.seconds_to_next_day(now))
    total = db.scalar(select(func.count()).select_from(User)) or 0
    new = db.scalar(select(func.count()).select_from(User).where(User.created_at >= day_start)) or 0
    dau = db.scalar(select(func.count()).select_from(User).where(User.last_active_day == today)) or 0
    games = db.scalar(select(func.count()).select_from(GameSession).where(GameSession.started_at >= day_start)) or 0
    boxes = db.scalar(select(func.count()).select_from(BoxOpening).where(BoxOpening.created_at >= day_start)) or 0
    ads = db.scalar(select(func.count()).select_from(AdView).where(AdView.day == today, AdView.status == "used")) or 0
    refs = db.scalar(select(func.count()).select_from(User).where(User.referrer_id.is_not(None))) or 0
    banned = db.scalar(select(func.count()).select_from(User).where(User.banned.is_(True))) or 0
    print(f"Игроков всего: {total}   новых сегодня: {new}   заходили сегодня: {dau}")
    print(f"Сегодня: игр {games}, коробок {boxes}, рекламы досмотрено {ads}")
    print(f"Пришли по приглашению: {refs}   в бане: {banned}")


def cmd_top(db, board: str):
    for i, (u, v) in enumerate(board_rows(db, board, limit=10)):
        sig = farm_signals(db, u)
        g, f = game_flags(db, u.tg_id)
        warn = []
        if sig["score"] >= 40:
            warn.append(f"ферма? {sig['score']}")
        if g and f / g > 0.2:
            warn.append(f"читы в игре {f}/{g}")
        print(f"{i + 1:>2}. {u.tg_id:<12} {display_name(u)[:18]:<18} {v:>12,.0f}  друзей {sig['n']}/{sig['active']} акт."
              f"  {'⚠ ' + ', '.join(warn) if warn else ''}")


def cmd_suspects(db):
    rows = db.execute(select(User.referrer_id, func.count()).where(User.referrer_id.is_not(None))
                      .group_by(User.referrer_id).having(func.count() >= 3)).all()
    out = []
    for rid, _ in rows:
        u = db.get(User, rid)
        if u:
            out.append((farm_signals(db, u), u))
    out.sort(key=lambda x: -x[0]["score"])
    print("score  id           имя                друзей(акт.)  пачкой  соседние id  без @  читы  одинаково")
    for sig, u in out[:30]:
        print(f"{sig['score']:>5}  {u.tg_id:<12} {display_name(u)[:18]:<18} {sig['n']:>5}({sig['active']:>3})"
              f"    {sig['burst']:>4.0%}     {sig['near']:>4.0%}      {sig['nouser']:>4.0%}  {sig['flag']:>4.0%}  {sig['same']:>4.0%}"
              f"{'  ' + 'BANNED' if u.banned else ''}")
    if not out:
        print("Пока никого: нужно хотя бы 3 приглашённых у одного игрока.")


def cmd_user(db, uid: int):
    u = db.get(User, uid)
    if u is None:
        return print("Нет такого игрока")
    g, f = game_flags(db, uid)
    sig = farm_signals(db, u)
    print(f"{display_name(u)}  id={u.tg_id}  @{u.username or '-'}  premium={'да' if u.is_premium else 'нет'}"
          f"  {'BANNED' if u.banned else ''}")
    print(f"Создан {eco.as_utc(u.created_at):%d.%m %H:%M} UTC, дней в игре {u.days_active}, пригласил его: {u.referrer_id or '-'}")
    print(f"Баланс {fmt(u.coins)}, за сезон {fmt(u.coins_earned_season)}, доход {income_of(u):.1f}/с, котов {len(u.cats)}")
    print(f"Игр {g}, подозрительных {f}, рекорд {u.game_best}, очков за сезон {u.game_points_season}")
    print(f"Друзей {sig['n']} (активных {sig['active']}), подозрение на ферму: {sig['score']}/100, принёс пригласившему {fmt(u.ref_given)}")
    bad = db.execute(select(GameSession.id, GameSession.score, GameSession.reasons).where(
        GameSession.user_id == uid, GameSession.flagged.is_(True)).order_by(GameSession.id.desc()).limit(5)).all()
    for sid, sc, why in bad:
        print(f"   партия #{sid}: {sc} очков, причины: {why}")


MSK = timedelta(hours=3)


def msk_day(s: str):
    """'2026-10-25' → 00:00 по Москве этого дня, в UTC."""
    from datetime import datetime, timezone
    d = datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return d - MSK


def fmt_msk(dt) -> str:
    return (eco.as_utc(dt) + MSK).strftime("%d.%m.%Y %H:%M МСК")


def cmd_season(db, a):
    from routers.rating import current_season
    cur = current_season(db)
    if a.cmd == "show":
        n = db.scalar(select(func.count()).select_from(Season)) or 0
        return print(f"Текущий сезон: «{cur.name}» {fmt_msk(cur.starts_at)} → {fmt_msk(cur.ends_at)} (всего сезонов: {n})")
    if a.cmd == "set":
        if a.name:
            cur.name = a.name
        if a.start:
            cur.starts_at = msk_day(a.start)
        if a.end:
            cur.ends_at = msk_day(a.end)
        elif a.days:
            cur.ends_at = eco.as_utc(cur.starts_at) + timedelta(days=a.days)
        if eco.as_utc(cur.ends_at) <= eco.as_utc(cur.starts_at):
            db.rollback()
            return print("Конец сезона должен быть позже начала")
        db.commit()
        return print(f"Готово: «{cur.name}» {fmt_msk(cur.starts_at)} → {fmt_msk(cur.ends_at)}. Перезапусти mc-api, чтобы таймер обновился сразу.")
    # new
    start = msk_day(a.start) if a.start else utcnow()
    end = msk_day(a.end) if a.end else start + timedelta(days=a.days or 30)
    if input(f"Начать новый сезон «{a.name}» и ОБНУЛИТЬ рейтинги? Напиши ДА: ").strip().upper() != "ДА":
        return print("Отменено")
    db.add(Season(name=a.name or "Новый сезон", starts_at=start, ends_at=end))
    from sqlalchemy import update
    db.execute(update(User).values(coins_earned_season=0, game_points_season=0))
    db.commit()
    print(f"Новый сезон «{a.name}»: {fmt_msk(start)} → {fmt_msk(end)}. Рейтинги обнулены. Перезапусти mc-api: systemctl restart mc-api")


def cmd_wipe(db):
    n = db.scalar(select(func.count()).select_from(User)) or 0
    print(f"Будут удалены ВСЕ игроки ({n}), их коты, игры, задания, реклама и история коробок. Промокоды останутся.")
    print("Сначала сделай бэкап: bash /root/meowcafe/deploy/backup.sh")
    if input("Точно? Напиши УДАЛИТЬ: ").strip().upper() != "УДАЛИТЬ":
        return print("Отменено")
    from sqlalchemy import delete, update
    for model in (UserCat, UserPity, UserTask, PromoUse, AdView, GameSession, BoxOpening, User, Season):
        db.execute(delete(model))
    db.execute(update(PromoCode).values(uses=0))
    db.commit()
    print("Готово: база пустая. Перезапусти сервер: systemctl restart mc-api — сезон создастся заново, потом задай даты через season set.")


def cmd_ban(db, uid: int, value: bool, refs: bool):
    u = db.get(User, uid)
    if u is None:
        return print("Нет такого игрока")
    u.banned = value
    n = 0
    if refs:
        for r in db.scalars(select(User).where(User.referrer_id == uid)):
            r.banned = value
            n += 1
    db.commit()
    print(f"{display_name(u)}: {'убран из рейтингов' if value else 'снова в рейтингах'}" + (f", и его друзья ({n})" if refs else ""))
    print("Рейтинг обновится в течение минуты.")


def main():
    p = argparse.ArgumentParser(description="MeowCafe admin")
    sub = p.add_subparsers(dest="what", required=True)
    promo = sub.add_parser("promo").add_subparsers(dest="cmd", required=True)
    add = promo.add_parser("add")
    add.add_argument("code")
    add.add_argument("--coins", type=int, default=0)
    add.add_argument("--box", type=int, default=None, choices=range(len(BOXES)))
    add.add_argument("--uses", type=int, default=0)
    add.add_argument("--days", type=float, default=None)
    promo.add_parser("list")
    off = promo.add_parser("off")
    off.add_argument("code")
    season = sub.add_parser("season").add_subparsers(dest="cmd", required=True)
    season.add_parser("show")
    for name in ("set", "new"):
        x = season.add_parser(name)
        x.add_argument("--name", default=None)
        x.add_argument("--start", default=None, help="ГГГГ-ММ-ДД по Москве")
        x.add_argument("--end", default=None, help="ГГГГ-ММ-ДД по Москве")
        x.add_argument("--days", type=int, default=None)
    sub.add_parser("wipe")
    sub.add_parser("stats")
    sub.add_parser("suspects")
    top = sub.add_parser("top")
    top.add_argument("board", nargs="?", default="players", choices=BOARDS)
    for name in ("user", "ban", "unban"):
        x = sub.add_parser(name)
        x.add_argument("id", type=int)
        if name != "user":
            x.add_argument("--refs", action="store_true", help="то же для всех его приглашённых")
    a = p.parse_args()

    auto_migrate()
    db = SessionLocal()
    try:
        if a.what == "season":
            return cmd_season(db, a)
        if a.what == "wipe":
            return cmd_wipe(db)
        if a.what != "promo":
            return {"stats": lambda: cmd_stats(db), "suspects": lambda: cmd_suspects(db),
                    "top": lambda: cmd_top(db, getattr(a, "board", "players")),
                    "user": lambda: cmd_user(db, a.id),
                    "ban": lambda: cmd_ban(db, a.id, True, a.refs),
                    "unban": lambda: cmd_ban(db, a.id, False, a.refs)}[a.what]()
        if a.cmd == "add":
            code = normalize(a.code)
            if not code:
                return print("Пустой код")
            if not a.coins and a.box is None:
                return print("Укажи --coins и/или --box, иначе промокод ничего не даёт")
            if db.get(PromoCode, code):
                return print(f"Промокод {code} уже есть. Выключи его (promo off) или придумай другой")
            exp = utcnow() + timedelta(days=a.days) if a.days else None
            db.add(PromoCode(code=code, coins=a.coins, box_id=a.box, max_uses=a.uses, expires_at=exp))
            db.commit()
            gift = ", ".join(x for x in [f"{a.coins} мяуконов" if a.coins else "",
                                         f"коробка «{BOXES[a.box][0]}»" if a.box is not None else ""] if x)
            print(f"Готово: {code} → {gift}; активаций: {a.uses or 'без ограничения'}; "
                  f"до: {exp:%d.%m.%Y %H:%M} UTC" if exp else f"Готово: {code} → {gift}; активаций: {a.uses or 'без ограничения'}; бессрочно")
        elif a.cmd == "list":
            rows = db.query(PromoCode).order_by(PromoCode.created_at.desc()).all()
            if not rows:
                print("Промокодов пока нет")
            for r in rows:
                box = BOXES[r.box_id][0] if r.box_id is not None else "-"
                exp = r.expires_at.strftime("%d.%m.%Y") if r.expires_at else "бессрочно"
                print(f"{r.code:<16} {'вкл ' if r.active else 'выкл'}  мяуконы={r.coins:<8} коробка={box:<12} "
                      f"использован {r.uses}/{r.max_uses or '∞'}  до {exp}")
        elif a.cmd == "off":
            r = db.get(PromoCode, normalize(a.code))
            if r is None:
                return print("Нет такого промокода")
            r.active = False
            db.commit()
            print(f"{r.code} выключен")
    finally:
        db.close()


if __name__ == "__main__":
    main()
