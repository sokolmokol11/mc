"""Призы сезона: сколько долларов получает место в рейтинге. Чистые расчёты — для тестов."""
from config import MIN_PRIZE_USD, PRIZE_BOARDS, PRIZE_POOL_USD, PRIZE_SPLIT


def board_prizes(board: str, pool: float = PRIZE_POOL_USD) -> list[float]:
    """Список призов за места 1..N. Призы меньше минимума отрезаются (их деньги остаются в фонде)."""
    total = pool * PRIZE_BOARDS.get(board, 0)
    prizes = [round(total * pct / 100, 2) for pct in PRIZE_SPLIT]
    return [p for p in prizes if p >= MIN_PRIZE_USD]
