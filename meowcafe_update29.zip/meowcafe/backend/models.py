"""
Таблицы базы. Шаг 2: игрок + его коты. Остальные таблицы из техплана добавим на своих шагах.
"""
from datetime import datetime, timezone

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db import Base


def utcnow():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    tg_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    username: Mapped[str | None] = mapped_column(String(64))
    first_name: Mapped[str] = mapped_column(String(128), default="")
    is_premium: Mapped[bool] = mapped_column(Boolean, default=False)
    referrer_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)

    coins: Mapped[int] = mapped_column(BigInteger, default=0)                # в сотых долях
    coins_earned_season: Mapped[int] = mapped_column(BigInteger, default=0, index=True)  # метрика рейтинга

    last_collect_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    bank_level: Mapped[int] = mapped_column(Integer, default=1)   # копилка
    cash_level: Mapped[int] = mapped_column(Integer, default=1)   # касса
    free_box_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)  # когда брал бесплатную коробку
    coffee_level: Mapped[int] = mapped_column(Integer, default=1)  # кофемашина (награда мини-игр)
    tables_level: Mapped[int] = mapped_column(Integer, default=1)  # столики (шанс редких котов)
    locations_open: Mapped[int] = mapped_column(Integer, default=2)       # открыто комнат: 2 = Главный зал и Кухня
    xp: Mapped[int] = mapped_column(Integer, default=0)                 # опыт кафе
    level_claimed: Mapped[int] = mapped_column(Integer, default=1)      # до какого уровня награды уже забраны
    xp_game_day: Mapped[int] = mapped_column(Integer, default=0)        # день, за который считаем опыт мини-игр
    xp_game_today: Mapped[int] = mapped_column(Integer, default=0)
    tables: Mapped[str] = mapped_column(String(64), default="1,0;0,0,0")   # уровни столиков: Главный зал;Доп. зал (0 — не куплен)
    fridge_level: Mapped[int] = mapped_column(Integer, default=0)           # холодильник (0 — не куплен); печь = kitchen_level, кофемашина = coffee_level
    play_level: Mapped[int] = mapped_column(Integer, default=1)             # игровая: цена входа
    treats: Mapped[int] = mapped_column(Integer, default=0)                 # вкусняшки — качать котов
    intro_step: Mapped[int] = mapped_column(Integer, default=0)             # начало истории: 0 нет котов, 1 кот на кассе, 2 пришли коты по объявлениям
    core_v: Mapped[int] = mapped_column(Integer, default=0)                 # версия экономики; старая → прогресс обнуляется
    box_pity: Mapped[int] = mapped_column(Integer, default=0)               # коробок подряд без кота
    kitchen_level: Mapped[int] = mapped_column(Integer, default=1)
    dish_coffee: Mapped[int] = mapped_column(Integer, default=1)                # уровни блюд меню (0 — рецепт не открыт)
    dish_bun: Mapped[int] = mapped_column(Integer, default=1)
    collection: Mapped[str] = mapped_column(Text, default="{}")              # рецепты, декор, воспоминания (JSON)
    box_buy_day: Mapped[int] = mapped_column(Integer, default=0)                 # лимит покупки коробок в сутки
    box_buy_count: Mapped[int] = mapped_column(Integer, default=0)  # сколько локаций открыто (1 = только Кафе)
    barista_cat_id: Mapped[int | None] = mapped_column(Integer, nullable=True)  # кто стоит за стойкой
    game_attempts: Mapped[int] = mapped_column(Integer, default=3)          # попытки в мини-играх
    attempts_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)  # от чего считаем +1 попытку
    game_best: Mapped[int] = mapped_column(Integer, default=0)              # рекорд Десертопада
    game_points_season: Mapped[int] = mapped_column(BigInteger, default=0, index=True)  # сумма проверенных очков — рейтинг «Мини-игры»
    games_played: Mapped[int] = mapped_column(Integer, default=0)           # проверенные игры (для правила активного друга)
    last_served_window: Mapped[int] = mapped_column(BigInteger, default=0)    # окно последнего обслуженного гостя
    guests_served: Mapped[int] = mapped_column(Integer, default=0)            # сколько гостей с заказом обслужил
    daily_streak: Mapped[int] = mapped_column(Integer, default=0)             # какой день серии забран последним (1..7)
    daily_last_day: Mapped[int] = mapped_column(Integer, default=0)           # номер дня (по Москве), когда забирал
    days_active: Mapped[int] = mapped_column(Integer, default=0)              # в сколько разных дней заходил
    last_active_day: Mapped[int] = mapped_column(Integer, default=0)
    is_active_ref: Mapped[bool] = mapped_column(Boolean, default=False)       # стал «активным другом» (3 дня + 3 игры)
    ref_active_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)  # когда стал активным — для рейтинга сезона
    ref_bank: Mapped[int] = mapped_column(BigInteger, default=0)              # банк друзей, в сотых
    ref_collect_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    ref_given: Mapped[int] = mapped_column(BigInteger, default=0)             # сколько этот игрок принёс пригласившему
    banned: Mapped[bool] = mapped_column(Boolean, default=False)              # убран из рейтингов (ручная проверка)
    tutorial_done: Mapped[bool] = mapped_column(Boolean, default=False)       # прошёл обучение
    avatar_cat_id: Mapped[int | None] = mapped_column(Integer, nullable=True)  # какой кот на аватарке
    avatar_decor: Mapped[str] = mapped_column(String(16), default="")         # украшение на аватарке

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    cats: Mapped[list["UserCat"]] = relationship(back_populates="user", cascade="all, delete-orphan")


class UserCat(Base):
    __tablename__ = "user_cats"
    __table_args__ = (UniqueConstraint("user_id", "cat_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.tg_id"), index=True)
    cat_id: Mapped[int] = mapped_column(Integer)           # 0..19 = редкость × 4 + номер
    slot: Mapped[int | None] = mapped_column(Integer, nullable=True)   # место в комнате (касса, столик, плита…)
    level: Mapped[int] = mapped_column(Integer, default=1)  # 1..5, повторка = +1
    location: Mapped[int | None] = mapped_column(Integer, nullable=True)  # 0 = Кафе, None = запас

    user: Mapped[User] = relationship(back_populates="cats")


class UserPity(Base):
    """Счётчики гаранта: свои на каждую коробку."""
    __tablename__ = "user_pity"

    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.tg_id"), primary_key=True)
    box_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    leg_count: Mapped[int] = mapped_column(Integer, default=0)
    myth_count: Mapped[int] = mapped_column(Integer, default=0)


class BoxOpening(Base):
    """Журнал открытий: для аналитики и разбора спорных случаев («мне не выпадает легендарка!»)."""
    __tablename__ = "box_openings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    box_id: Mapped[int] = mapped_column(Integer)
    cat_id: Mapped[int] = mapped_column(Integer)
    was_pity: Mapped[bool] = mapped_column(Boolean, default=False)
    was_free: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class GameSession(Base):
    """Одна партия мини-игры. Награду считает сервер по тапам."""
    __tablename__ = "game_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    seed: Mapped[int] = mapped_column(BigInteger)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    score: Mapped[int] = mapped_column(Integer, default=0)
    hits: Mapped[int] = mapped_column(Integer, default=0)
    misses: Mapped[int] = mapped_column(Integer, default=0)
    flagged: Mapped[bool] = mapped_column(Boolean, default=False)
    reasons: Mapped[str] = mapped_column(String(128), default="")
    reward: Mapped[int] = mapped_column(BigInteger, default=0)  # в сотых
    doubled: Mapped[bool] = mapped_column(Boolean, default=False)  # награду уже удвоили за рекламу


class UserTask(Base):
    """Забранные награды за задания: квесты (q_...) и спонсоров (sp_@канал). Одна строка = одна награда навсегда."""
    __tablename__ = "user_tasks"

    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.tg_id"), primary_key=True)
    task_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    reward: Mapped[int] = mapped_column(BigInteger, default=0)  # в сотых
    claimed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Season(Base):
    """Сезон. Пока одна строка: создаётся сама при первом запуске и длится SEASON_DAYS дней."""
    __tablename__ = "seasons"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(64), default="")
    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    ends_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class AdView(Base):
    """
    Просмотр рекламы. pending — показ начался; confirmed — Adsgram подтвердил досмотр (Reward URL);
    used — награда выдана. Награду выдаём только за confirmed, поэтому подделать «досмотр» с телефона нельзя.
    """
    __tablename__ = "ad_views"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    kind: Mapped[str] = mapped_column(String(16))             # free_box | game_x2 | attempt
    ref: Mapped[int | None] = mapped_column(Integer, nullable=True)   # для game_x2 — номер партии
    status: Mapped[str] = mapped_column(String(12), default="pending")
    day: Mapped[int] = mapped_column(Integer, default=0)      # номер дня по Москве — для лимитов
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class PromoCode(Base):
    """Промокод. Создаётся командой: python admin.py promo add КОД --coins 50000 --box 2 --uses 100 --days 7"""
    __tablename__ = "promo_codes"

    code: Mapped[str] = mapped_column(String(32), primary_key=True)     # всегда ЗАГЛАВНЫМИ
    coins: Mapped[int] = mapped_column(BigInteger, default=0)           # мяуконы (целые, не сотые)
    box_id: Mapped[int | None] = mapped_column(Integer, nullable=True)  # какую коробку открыть в подарок
    max_uses: Mapped[int] = mapped_column(Integer, default=0)           # 0 — без ограничения
    uses: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class PromoUse(Base):
    """Кто какой промокод уже ввёл: один код — один раз на игрока."""
    __tablename__ = "promo_uses"

    user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    code: Mapped[str] = mapped_column(String(32), primary_key=True)
    used_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
