"""
Ядро v2: кафе работает руками котов.

Комнаты и места:
  Главный зал: касса + 2 столика   Кухня: 2 повара   Доп. зал: 3 столика   Игровая: 2 кота-игрока
Столик приводит гостей, только если он куплен и за ним стоит кот-официант.
Кухня готовит, только если там есть хотя бы один повар. Без кассира продаж нет.

  гостей/с   = Σ ставка_столика(ур) × (1 + 0,1 × официант)
  заказов/с  = Σ оборудование(ур) × (1 + 0,1 × Σ поваров)
  продажи/с  = min(гостей, заказов) × средний чек × (1 + 0,04 × кассир + касса)
  игровая/с  = Σ 0,01 × (1 + 0,1 × игрок) × цена входа

Это доход в секунду: копилка и «доход, пока тебя нет» считают его как раньше.
"""
from config import (CASH_PER_LEVEL, CASHIER_BONUS, CAT_LEVEL_STEP, CAT_STATS, COOK_BONUS, DISH_MAX, DISH_PRICE_GROWTH,
                    DISH_UP, DISH_UP_GROWTH, DISHES, EQUIP, EQUIP_MAX, EQUIP_RATE_GROWTH, EQUIP_UP_GROWTH, MENU_VARIETY,
                    PLAY_BONUS, PLAY_MAX, PLAY_RATE, PLAY_TICKET, PLAY_TICKET_GROWTH, PLAY_UP, PLAY_UP_GROWTH, ROOM_ROLES,
                    STAT_KEYS, TABLE_BUY, TABLE_BUY_GROWTH, TABLE_MAX, TABLE_RATE, TABLE_RATE_GROWTH, TABLE_SEATS, TABLE_UP,
                    TABLE_UP_GROWTH, WAIT_BONUS)

DEFAULT_TABLES = "1,0;0,0,0"           # на старте один столик в Главном зале
ROOM_KEYS = list(TABLE_SEATS)          # порядок частей в строке: Главный зал, Доп. зал


# ---------- столики ----------
def parse_tables(s: str | None) -> dict[int, list[int]]:
    parts = (s or DEFAULT_TABLES).split(";")
    out = {}
    for k, room in enumerate(ROOM_KEYS):
        vals = [int(x) for x in parts[k].split(",")] if k < len(parts) and parts[k] else []
        out[room] = (vals + [0] * TABLE_SEATS[room])[:TABLE_SEATS[room]]
    return out


def dump_tables(t: dict[int, list[int]]) -> str:
    return ";".join(",".join(str(v) for v in t[room]) for room in ROOM_KEYS)


def table_of_slot(room: int, slot: int) -> int | None:
    """Какой столик обслуживает место (в Главном зале место 0 — касса)."""
    if room == 0:
        return slot - 1 if slot >= 1 else None
    if room == 2:
        return slot
    return None


def table_rate(level: int) -> float:
    return 0 if level <= 0 else TABLE_RATE * TABLE_RATE_GROWTH ** (level - 1)


def table_buy_cost(tables: dict[int, list[int]]) -> int:
    bought = sum(1 for levels in tables.values() for l in levels if l > 0)
    return int(round(TABLE_BUY * TABLE_BUY_GROWTH ** max(0, bought - 1), -2))


def table_up_cost(level: int) -> int:
    return int(round(TABLE_UP * TABLE_UP_GROWTH ** (level - 1), -2))


# ---------- коты ----------
def cat_stats(cat_id: int, level: int) -> dict[str, float]:
    base = CAT_STATS.get(cat_id, (3, 3, 3, 3))
    k = 1 + CAT_LEVEL_STEP * (max(1, level) - 1)
    return {key: round(v * k, 2) for key, v in zip(STAT_KEYS, base)}


def placement(user) -> dict[tuple[int, int], object]:
    """(комната, место) → кот. Коты без места — в запасе."""
    out = {}
    for c in user.cats:
        if c.location is not None and c.slot is not None:
            out[(c.location, c.slot)] = c
    return out


def role_of(room: int, slot: int) -> str | None:
    roles = ROOM_ROLES.get(room, ())
    return roles[slot] if 0 <= slot < len(roles) else None


# ---------- кухня, меню, игровая ----------
def equip_levels(user) -> dict[str, int]:
    return {"oven": user.kitchen_level if user.kitchen_level is not None else 1,
            "coffee": user.coffee_level if user.coffee_level is not None else 1,
            "fridge": user.fridge_level or 0}


def equip_rate(item: str, level: int) -> float:
    return 0 if level <= 0 else EQUIP[item][1] * EQUIP_RATE_GROWTH ** (level - 1)


def equip_cost(item: str, level: int) -> int:
    """Цена следующего уровня; для холодильника с уровнем 0 — цена покупки."""
    return int(round(EQUIP[item][3] * EQUIP_UP_GROWTH ** max(0, level - 1), -2))


def dish_price(key: str, level: int) -> float:
    return DISHES[key][1] * DISH_PRICE_GROWTH ** (level - 1)


def avg_check(dish_levels: dict[str, int]) -> float:
    have = [dish_price(k, l) for k, l in dish_levels.items() if l > 0]
    if not have:
        return 0.0
    return sum(have) / len(have) * (1 + MENU_VARIETY * (len(have) - 1))


def dish_up_cost(key: str, level: int) -> int:
    return int(round(DISHES[key][1] * DISH_UP * DISH_UP_GROWTH ** (level - 1), -2))


def play_ticket(level: int) -> float:
    return 0 if level <= 0 else PLAY_TICKET * PLAY_TICKET_GROWTH ** (level - 1)


def play_up_cost(level: int) -> int:
    return int(round(PLAY_UP * PLAY_UP_GROWTH ** max(0, level - 1), -2))


# ---------- всё вместе ----------
def breakdown(user, dish_levels: dict[str, int]) -> dict:
    """Полный расчёт кафе: что даёт каждое место и откуда берётся доход."""
    rooms_open = user.locations_open or 2
    tables = parse_tables(user.tables)
    place = placement(user)
    stats = {c.cat_id: cat_stats(c.cat_id, c.level) for c in user.cats}

    slots, guests, cooks, cook_sum, cashier, play_cats = [], 0.0, 0, 0.0, None, []
    for room, roles in ROOM_ROLES.items():
        for slot, role in enumerate(roles):
            c = place.get((room, slot))
            is_open = room < rooms_open
            t = table_of_slot(room, slot)
            tlevel = tables[room][t] if t is not None else None
            effect = 0.0
            if c is not None and is_open:
                st = stats[c.cat_id][role]
                if role == "wait" and tlevel:
                    effect = table_rate(tlevel) * (1 + WAIT_BONUS * st)
                    guests += effect
                elif role == "cook":
                    cooks += 1; cook_sum += st
                elif role == "cash":
                    cashier = st
                elif role == "play":
                    play_cats.append(st)
            slots.append({"room": room, "slot": slot, "role": role, "cat_id": c.cat_id if c else None,
                          "table": t, "table_level": tlevel, "open": is_open, "per_min": round(effect * 60, 2)})

    eq = equip_levels(user)
    kitchen_base = sum(equip_rate(k, l) for k, l in eq.items())
    kitchen = kitchen_base * (1 + COOK_BONUS * cook_sum) if cooks else 0.0
    check = avg_check(dish_levels)
    cash_mult = (1 + CASHIER_BONUS * cashier + CASH_PER_LEVEL * ((user.cash_level or 1) - 1)) if cashier is not None else 0.0
    served = min(guests, kitchen)
    sales = served * check * cash_mult
    play_level = user.play_level or 0
    play = sum(PLAY_RATE * (1 + PLAY_BONUS * s) for s in play_cats) * play_ticket(play_level) if rooms_open > 3 else 0.0

    if cashier is None:
        neck = "cashier"
    elif cooks == 0:
        neck = "cook"
    elif guests == 0:
        neck = "waiter"
    elif abs(guests - kitchen) / max(guests, kitchen) < .05:
        neck = "ok"
    else:
        neck = "kitchen" if kitchen < guests else "guests"
    return {"slots": slots, "tables": tables, "guests": guests, "kitchen": kitchen, "kitchen_base": kitchen_base,
            "cook_bonus": COOK_BONUS * cook_sum if cooks else 0.0, "check": check, "cash_mult": cash_mult,
            "sales": sales, "play": play, "total": sales + play, "neck": neck, "equip": eq, "play_level": play_level}


__all__ = ["DEFAULT_TABLES", "TABLE_MAX", "EQUIP_MAX", "DISH_MAX", "PLAY_MAX", "DISHES", "EQUIP"]
