"""
Запросы сервера к Telegram (через тот же прокси, что у бота).
Нужен для проверки подписки на канал спонсора: getChatMember.
"""
import aiohttp

from config import BOT_TOKEN, PROXY_URL

SUBSCRIBED = {"creator", "administrator", "member", "restricted"}


class TelegramError(Exception):
    pass


async def call(method: str, **params) -> dict:
    connector = None
    if PROXY_URL:
        from aiohttp_socks import ProxyConnector
        connector = ProxyConnector.from_url(PROXY_URL)
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"
    try:
        async with aiohttp.ClientSession(connector=connector, timeout=aiohttp.ClientTimeout(total=10)) as s:
            async with s.post(url, json=params) as r:
                data = await r.json(content_type=None)
    except Exception as e:  # сеть, прокси, таймаут
        raise TelegramError(f"нет связи с Telegram ({type(e).__name__})")
    if not data.get("ok"):
        raise TelegramError(data.get("description", "ошибка Telegram"))
    return data["result"]


async def is_subscribed(channel: str, user_id: int) -> bool:
    member = await call("getChatMember", chat_id=channel, user_id=user_id)
    if member.get("status") == "restricted":
        return bool(member.get("is_member"))
    return member.get("status") in SUBSCRIBED
