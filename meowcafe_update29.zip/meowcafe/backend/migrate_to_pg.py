"""
Переезд со SQLite на PostgreSQL (один раз).

    ../.venv/bin/python migrate_to_pg.py sqlite:///./meowcafe.db postgresql://meowcafe:пароль@127.0.0.1:5432/meowcafe

Копирует все таблицы как есть. Сервер (mc-api) на время переезда должен быть остановлен.
Если в PostgreSQL уже есть игроки — откажется (защита от двойного запуска). --force перезапишет.
"""
import sys
from datetime import datetime, timezone

from sqlalchemy import create_engine, inspect, select, text

FORCE = "--force" in sys.argv
args = [a for a in sys.argv[1:] if a != "--force"]
if len(args) != 2:
    sys.exit(__doc__)
src_url, dst_url = args
if dst_url.startswith("postgresql://"):
    dst_url = "postgresql+psycopg://" + dst_url[len("postgresql://"):]

import os  # noqa: E402
os.environ["DATABASE_URL"] = dst_url          # models/db берут адрес отсюда
import db as dbmod  # noqa: E402
import models  # noqa: E402,F401

src = create_engine(src_url)
dst = dbmod.engine
dbmod.auto_migrate()                          # создаём таблицы в PostgreSQL

with dst.connect() as c:
    users = c.execute(text("SELECT count(*) FROM users")).scalar()
if users and not FORCE:
    sys.exit(f"В PostgreSQL уже {users} игроков — переезд, похоже, уже был. Запусти с --force, чтобы перезаписать.")

src_tables = set(inspect(src).get_table_names())


def fix(v):
    # SQLite хранит время без часового пояса — у нас это всегда UTC
    if isinstance(v, datetime) and v.tzinfo is None:
        return v.replace(tzinfo=timezone.utc)
    return v


with src.connect() as s, dst.begin() as d:
    for table in reversed(dbmod.Base.metadata.sorted_tables):
        d.execute(table.delete())
    for table in dbmod.Base.metadata.sorted_tables:
        if table.name not in src_tables:
            print(f"{table.name:<14} нет в старой базе — пропускаю")
            continue
        have = {c["name"] for c in inspect(src).get_columns(table.name)}
        cols = [c for c in table.columns if c.name in have]
        rows = s.execute(select(*[text(c.name) for c in cols]).select_from(text(table.name))).all()
        batch = []
        for r in rows:
            batch.append({c.name: fix(v) for c, v in zip(cols, r)})
            if len(batch) >= 1000:
                d.execute(table.insert(), batch)
                batch = []
        if batch:
            d.execute(table.insert(), batch)
        print(f"{table.name:<14} {len(rows)} строк")
    # счётчики id: следующая запись получит номер после последнего скопированного
    for table in dbmod.Base.metadata.sorted_tables:
        for col in table.primary_key.columns:
            if col.autoincrement is True or (col.autoincrement == "auto" and col.type.python_type is int
                                             and len(table.primary_key.columns) == 1 and col.name == "id"):
                d.execute(text(f"SELECT setval(pg_get_serial_sequence('{table.name}', '{col.name}'), "
                               f"COALESCE((SELECT MAX({col.name}) FROM {table.name}), 0) + 1, false)"))
print("Готово: данные в PostgreSQL.")
