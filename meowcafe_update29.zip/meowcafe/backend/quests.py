"""
Задания: ежедневный вход и квесты. Только расчёты, без запросов — их легко тестировать.

Квест выполняется сам, когда игрок дошёл до цели (открыл 10 коробок и т.п.).
Награду он забирает кнопкой, и забрать её можно один раз (таблица user_tasks).
"""
from datetime import datetime

import economy as eco
from config import ACTIVE_CATS, CENTS, DAILY_REWARDS, DAY_OFFSET_HOURS

# id, раздел, название, что считаем, цель, мяуконы (минимум, минут дохода), коробка в подарок (номер / "leg" / None)
QUESTS = [
    # Друзья — главные награды игры
    ("q_friend1", "friends", "Пригласи активного друга", "friends", 1, (10_000, 120), None),
    ("q_friend3", "friends", "Пригласи 3 активных друзей", "friends", 3, (15_000, 120), 0),
    ("q_friend5", "friends", "Пригласи 5 активных друзей", "friends", 5, (20_000, 180), 0),
    ("q_friend10", "friends", "Пригласи 10 активных друзей", "friends", 10, (40_000, 300), "leg"),
    ("q_friend20", "friends", "Пригласи 20 активных друзей", "friends", 20, (100_000, 600), "leg"),
    # Коробки
    ("q_box1", "boxes", "Открой первую коробку", "boxes", 1, (2_000, 20), None),
    ("q_box10", "boxes", "Открой 10 коробок", "boxes", 10, (5_000, 60), None),
    ("q_box50", "boxes", "Открой 50 коробок", "boxes", 50, (20_000, 180), 0),
    ("q_box100", "boxes", "Открой 100 коробок", "boxes", 100, (40_000, 300), 0),
    # Коллекция
    ("q_col5", "collection", "Собери 5 разных котов", "collection", 5, (3_000, 30), None),
    ("q_col10", "collection", "Собери 8 разных котов", "collection", 8, (10_000, 120), None),
    ("q_col20", "collection", "Собери всю коллекцию", "collection", len(ACTIVE_CATS), (100_000, 600), None),
    ("q_epic", "collection", "Получи эпического кота", "rarity", 2, (5_000, 60), None),
    ("q_leg", "collection", "Получи легендарного кота", "rarity", 3, (20_000, 180), None),
    # Мини-игры
    ("q_game1", "games", "Сыграй в Десертопад", "games", 1, (1_000, 10), None),
    ("q_game10", "games", "Сыграй в Десертопад 10 раз", "games", 10, (6_000, 90), None),
    ("q_game30", "games", "Сыграй в Десертопад 30 раз", "games", 30, (15_000, 180), 0),
    ("q_score40", "games", "Набери 40 очков за одну игру", "best", 40, (5_000, 60), None),
    ("q_score60", "games", "Набери 60 очков за одну игру", "best", 60, (10_000, 120), 0),
    # Кафе
    ("q_barista", "cafe", "Поставь кота на кассу", "barista", 1, (1_000, 10), None),
    ("q_guest3", "cafe", "Обслужи 3 гостей с заказом", "guests", 3, (3_000, 40), None),
    ("q_guest20", "cafe", "Обслужи 20 гостей с заказом", "guests", 20, (15_000, 180), None),
    ("q_cash5", "cafe", "Улучши кассу до 5 уровня", "cash", 5, (5_000, 60), None),
    ("q_bank3", "cafe", "Улучши копилку до 3 уровня", "bank", 3, (4_000, 45), None),
    ("q_terrace", "cafe", "Открой Доп. зал", "locations", 3, (10_000, 180), None),
    ("q_space", "cafe", "Открой Игровую", "locations", 4, (60_000, 600), None),
]
QUEST_IDS = {q[0] for q in QUESTS}


def box_name(box) -> str | None:
    from config import BOXES
    if box is None:
        return None
    return "Редкая коробка" if box == "leg" else BOXES[0][0]


def scaled_reward(income: float, rule: tuple[int, int] | None) -> int:
    """Награда в сотых: max(минимум, доход × минуты)."""
    if rule is None:
        return 0
    floor, minutes = rule
    return int(max(floor, income * minutes * 60) * CENTS)


def day_index(now: datetime) -> int:
    """Номер дня с 1970 года по московскому времени: новый день в 00:00 МСК."""
    return int((eco.as_utc(now).timestamp() + DAY_OFFSET_HOURS * 3600) // 86400)


def seconds_to_next_day(now: datetime) -> int:
    t = eco.as_utc(now).timestamp() + DAY_OFFSET_HOURS * 3600
    return int(86400 - t % 86400)


def daily_next(streak: int, last_day: int, today: int) -> tuple[int, bool]:
    """
    Какой день серии сейчас (1..7) и забран ли он уже сегодня.
    Пропустил день — серия начинается заново. После 7-го дня снова 1-й.
    """
    if last_day == today and streak:
        return streak, True
    if last_day == today - 1 and streak:
        return streak % len(DAILY_REWARDS) + 1, False
    return 1, False


def progress_values(user, boxes_opened: int, friends_active: int = 0) -> dict[str, int]:
    """Текущие значения всего, что считают квесты."""
    return {
        "boxes": boxes_opened,
        "collection": len({c.cat_id for c in user.cats} & set(ACTIVE_CATS)),
        "rarity": max((eco.cat_rarity(c.cat_id) for c in user.cats), default=-1),
        "barista": 1 if user.barista_cat_id is not None else 0,
        "guests": user.guests_served or 0,
        "games": user.games_played or 0,
        "best": user.game_best or 0,
        "cash": user.cash_level or 1,
        "bank": user.bank_level or 1,
        "locations": user.locations_open or 1,
        "friends": friends_active,
    }


def quests_view(values: dict[str, int], claimed: set[str], income: float) -> list[dict]:
    out = []
    for qid, cat, title, kind, goal, rule, box in QUESTS:
        val = values[kind]
        if kind == "rarity":  # «получи эпика»: прогресс 0/1, а не номер редкости
            have, need = (1 if val >= goal else 0), 1
        else:
            have, need = min(val, goal), goal
        status = "claimed" if qid in claimed else ("ready" if have >= need else "progress")
        out.append({"id": qid, "cat": cat, "title": title, "have": have, "need": need, "status": status,
                    "reward": scaled_reward(income, rule) / CENTS, "box": box, "box_name": box_name(box)})
    return out
