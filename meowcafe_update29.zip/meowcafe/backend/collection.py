"""
Коллекция игрока: открытые рецепты и декор. Одна JSON-строка в users.collection:
{"rec": {"donut": 2}, "decor": ["monstera"]}
Воспоминания котов не хранятся: кот уровня N помнит первые N кусочков своей истории.
"""
import json

from config import DECOR, MEMORY_MAX, RECIPES
import story


def load(user) -> dict:
    try:
        d = json.loads(user.collection or "{}")
    except ValueError:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("rec", {}); d.setdefault("decor", [])
    return d


def save(user, d: dict) -> None:
    user.collection = json.dumps(d, separators=(",", ":"))


def dish_levels(user) -> dict[str, int]:
    rec = load(user)["rec"]
    out = {"coffee": 1 if user.dish_coffee is None else user.dish_coffee, "bun": 1 if user.dish_bun is None else user.dish_bun}
    for k in RECIPES:
        out[k] = int(rec.get(k, 0))
    return out


def memories(cat_id: int, level: int) -> dict:
    n = min(MEMORY_MAX, max(1, level))
    return {"n": n, "max": MEMORY_MAX, "texts": [story.memory(cat_id, i) for i in range(1, n + 1)]}


def view(user) -> dict:
    d = load(user)
    return {
        "decor": [{"key": k, "name": v[0], "room": v[1], "rarity": v[2], "have": k in d["decor"]} for k, v in DECOR.items()],
        "recipes_left": sum(1 for k in RECIPES if not d["rec"].get(k)),
    }
