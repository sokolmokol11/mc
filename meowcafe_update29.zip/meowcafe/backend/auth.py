"""
Проверка подписи Telegram Mini App (initData).

Telegram подписывает данные о пользователе токеном твоего бота.
Подделать подпись без токена нельзя, поэтому tg_id мы берём ТОЛЬКО отсюда,
а не из того, что прислал фронт.
Документация: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
"""
import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

MAX_AGE_SECONDS = 24 * 3600  # initData старше суток не принимаем


class AuthError(Exception):
    pass


def verify_init_data(init_data: str, bot_token: str, max_age: int = MAX_AGE_SECONDS) -> dict:
    """Возвращает словарь с полями initData (user уже разобран из JSON) или бросает AuthError."""
    if not init_data:
        raise AuthError("пустой initData")

    pairs = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=False))
    received_hash = pairs.pop("hash", None)
    if not received_hash:
        raise AuthError("нет подписи")

    # строка для проверки: все поля кроме hash, отсортированы, через перевод строки
    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(expected, received_hash):
        raise AuthError("подпись не совпадает")

    auth_date = int(pairs.get("auth_date", "0"))
    if time.time() - auth_date > max_age:
        raise AuthError("initData устарел")

    if "user" in pairs:
        pairs["user"] = json.loads(pairs["user"])
    else:
        raise AuthError("нет пользователя")
    return pairs
