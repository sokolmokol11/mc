"""Общие зависимости запросов: кто делает запрос."""
from fastapi import Header, HTTPException

from auth import AuthError, verify_init_data
from config import BOT_TOKEN, DEV_MODE


def telegram_data(authorization: str = Header(default="")) -> dict:
    """
    Фронт шлёт заголовок:  Authorization: tma <initData>
    Возвращает проверенные данные Telegram. Без валидной подписи — 401.
    """
    if DEV_MODE and authorization == "tma dev":
        # локальная отладка в обычном браузере, на сервере DEV_MODE всегда 0!
        return {"user": {"id": 1, "first_name": "Dev", "username": "dev"}, "start_param": ""}

    if not authorization.startswith("tma "):
        raise HTTPException(status_code=401, detail="Нет данных Telegram")
    try:
        return verify_init_data(authorization[4:], BOT_TOKEN)
    except AuthError as e:
        raise HTTPException(status_code=401, detail=f"Неверная подпись: {e}")
