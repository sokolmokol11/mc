"""
Чистая математика экономики: без базы и без FastAPI, поэтому её легко тестировать.
Сервер НЕ «тикает» каждую секунду: он хранит время последнего сбора
и пересчитывает накопленное в момент запроса.
"""
import hashlib
import random
import secrets
from datetime import datetime, timezone

from config import (ACTIVE_CATS, BANK_START_HOURS, BOXES, CASH_PER_LEVEL, CAT_INCOME, CATS, CENTS, DUP_BONUS,
                    LOCATIONS, MAX_LEVEL, RARITY_NAMES, TABLES_PER_LEVEL, UPGRADE_GROWTH, UPGRADES)

RNG = secrets.SystemRandom()  # честный генератор, клиент на него не влияет
CATS_PER_RARITY = 4


# ---------- время ----------
def as_utc(dt: datetime) -> datetime:
    """SQLite теряет часовой пояс при сохранении — возвращаем его обратно."""
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


# ---------- коты ----------
def cat_rarity(cat_id: int) -> int:
    return cat_id // CATS_PER_RARITY


def pool(rarity: int) -> list[int]:
    """Коты этой редкости, которые сейчас выпадают. Если в .env забыли редкость — берём всех её котов."""
    ids = [c for c in ACTIVE_CATS if cat_rarity(c) == rarity]
    return ids or [rarity * CATS_PER_RARITY + i for i in range(CATS_PER_RARITY)]


def pick_cat(rarity: int, rng: random.Random = RNG) -> int:
    ids = pool(rarity)
    return ids[rng.randrange(len(ids))]


def cat_info(cat_id: int) -> dict:
    r = cat_rarity(cat_id)
    return {"cat_id": cat_id, "name": CATS[r][cat_id % CATS_PER_RARITY], "rarity": r,
            "rarity_name": RARITY_NAMES[r], "base_income": CAT_INCOME[r]}


def cat_income(cat_id: int, level: int, location: int | None) -> float:
    """Доход кота в секунду. Кот в запасе (location=None) не зарабатывает."""
    if location is None:
        return 0.0
    base = CAT_INCOME[cat_rarity(cat_id)]
    return base * (1 + DUP_BONUS * (min(level, MAX_LEVEL) - 1)) * LOCATIONS[location][3]


def total_income(cats: list[tuple[int, int, int | None]], cash_level: int) -> float:
    """cats = [(cat_id, level, location), ...] → доход кафе в секунду с учётом кассы."""
    raw = sum(cat_income(c, lvl, loc) for c, lvl, loc in cats)
    return raw * (1 + CASH_PER_LEVEL * (cash_level - 1))


# ---------- копилка ----------
def cap_seconds(bank_level: int) -> int:
    return (BANK_START_HOURS + bank_level - 1) * 3600


def pending_cents(income_per_sec: float, last_collect_at: datetime, now: datetime, bank_level: int) -> int:
    """Сколько накопилось с последнего сбора (в сотых мяукона), но не больше лимита копилки."""
    elapsed = max(0.0, (as_utc(now) - as_utc(last_collect_at)).total_seconds())
    return int(income_per_sec * min(elapsed, cap_seconds(bank_level)) * CENTS)


# ---------- случайности ----------
def roll_rarity(chances: list[float], rng: random.Random = RNG) -> int:
    x = rng.random() * sum(chances)
    for r, c in enumerate(chances):
        if x < c:
            return r
        x -= c
    return max(r for r, c in enumerate(chances) if c > 0)


def roll_cat(chances: list[float], rng: random.Random = RNG) -> int:
    """Редкость по шансам, внутри редкости — любой из доступных котов поровну."""
    return pick_cat(roll_rarity(chances, rng), rng)


# ---------- коробки ----------
def box_chances(box_id: int, tables_level: int = 1) -> list[float]:
    """
    Шансы коробки с учётом улучшения «Столики»: бонус в процентных пунктах забираем
    у самой частой (низшей) редкости и раздаём более редким пропорционально их шансам.
    Редкости с нулевым шансом остаются нулевыми — мифик из дешёвых коробок не появится.
    """
    chances = list(BOXES[box_id][2])
    bonus = TABLES_PER_LEVEL * 100 * (tables_level - 1)
    low = next(i for i, c in enumerate(chances) if c > 0)
    higher = [i for i in range(low + 1, len(chances)) if chances[i] > 0]
    if bonus <= 0 or not higher:
        return chances
    bonus = min(bonus, chances[low] / 2)
    total = sum(chances[i] for i in higher)
    chances[low] -= bonus
    for i in higher:
        chances[i] += bonus * BOXES[box_id][2][i] / total
    return [round(c, 3) for c in chances]


def upgrade_cost(kind: str, level: int) -> int:
    """Цена следующего уровня (в мяуконах) для улучшения текущего уровня level."""
    return int(round(UPGRADES[kind] * UPGRADE_GROWTH ** (level - 1), -2))


def open_box_roll(box_id: int, leg_count: int, myth_count: int, rng: random.Random = RNG,
                  chances: list[float] | None = None):
    """
    Одна коробка с учётом гаранта. Счётчики свои у каждой коробки и есть только там, где задан порог.
    Возвращает (cat_id, новый счётчик легендарного, новый счётчик мифического, сработал ли гарант).
    """
    _name, _price, base_chances, leg_pity, myth_pity = BOXES[box_id]
    chances = chances or base_chances
    if leg_pity:
        leg_count += 1
    if myth_pity:
        myth_count += 1

    was_pity = False
    if myth_pity and myth_count >= myth_pity:
        rarity, was_pity = 4, True
    elif leg_pity and leg_count >= leg_pity:
        rarity, was_pity = 3, True
    else:
        rarity = roll_rarity(chances, rng)

    if rarity >= 3:
        leg_count = 0
    if rarity == 4:
        myth_count = 0
    return pick_cat(rarity, rng), leg_count, myth_count, was_pity


# ---------- гости с заказами ----------
def guest_window(now: datetime) -> int:
    from config import GUEST_WINDOW_MIN
    return int(as_utc(now).timestamp() // (GUEST_WINDOW_MIN * 60))


def guest_order(user_id: int, window: int, secret: str) -> int | None:
    """
    Есть ли в этом окне гость с заказом и какую редкость он хочет (0..2).
    Считается из секрета сервера, поэтому одинаково при каждом запросе, но клиент не может предсказать.
    """
    from config import GUEST_ORDER_CHANCE, GUEST_WANT_WEIGHTS
    seed = hashlib.sha256(f"{secret}:{user_id}:{window}".encode()).digest()
    rng = random.Random(seed)
    if rng.random() >= GUEST_ORDER_CHANCE:
        return None
    return roll_rarity(GUEST_WANT_WEIGHTS, rng)
