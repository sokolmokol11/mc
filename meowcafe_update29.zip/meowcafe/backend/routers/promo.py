"""
Промокоды (вкладка «Задания»).
  POST /api/promo  {"code": "MEOW2026"}  → мяуконы и/или коробка в подарок

Создаются и выключаются на сервере командой admin.py (см. README).
Мяуконы из промокода НЕ идут в рейтинг «Игроки» — иначе код давал бы место в топе.
"""
import time
from collections import defaultdict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import or_, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

import economy as eco
from config import BOXES, CENTS
from db import get_db
from deps import telegram_data
from models import PromoCode, PromoUse, utcnow
from routers.boxes import boxes_view, open_boxes_core
from routers.player import get_user, state

router = APIRouter(prefix="/api/promo", tags=["promo"])
MAX_FAILS_PER_HOUR = 10          # защита от перебора кодов
_fails: dict[int, list[float]] = defaultdict(list)


class PromoRequest(BaseModel):
    code: str


def normalize(code: str) -> str:
    return "".join(code.split()).upper()[:32]


def note_fail(user_id: int, text: str):
    _fails[user_id].append(time.time())
    raise HTTPException(status_code=400, detail=text)


@router.post("")
def use_promo(req: PromoRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    recent = [t for t in _fails[user.tg_id] if time.time() - t < 3600]
    _fails[user.tg_id] = recent
    if len(recent) >= MAX_FAILS_PER_HOUR:
        raise HTTPException(status_code=429, detail="Слишком много попыток, попробуй через час")

    code = normalize(req.code)
    promo = db.get(PromoCode, code) if code else None
    if promo is None or not promo.active:
        note_fail(user.tg_id, "Такого промокода нет")
    if promo.expires_at and eco.as_utc(promo.expires_at) < eco.as_utc(now):
        note_fail(user.tg_id, "Срок промокода закончился")
    if db.get(PromoUse, (user.tg_id, code)):
        raise HTTPException(status_code=400, detail="Ты уже вводил этот промокод")

    # Занимаем одну активацию одной командой: два игрока не заберут последнюю одновременно.
    res = db.execute(update(PromoCode).where(PromoCode.code == code,
                                             or_(PromoCode.max_uses == 0, PromoCode.uses < PromoCode.max_uses))
                     .values(uses=PromoCode.uses + 1).execution_options(synchronize_session=False))
    if res.rowcount == 0:
        db.rollback()
        raise HTTPException(status_code=400, detail="Активации этого промокода закончились")
    db.add(PromoUse(user_id=user.tg_id, code=code, used_at=now))
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Ты уже вводил этот промокод")

    user.coins += (promo.coins or 0) * CENTS
    results = []
    if promo.box_id is not None and 0 <= promo.box_id < len(BOXES):
        results = open_boxes_core(db, user, promo.box_id, 1, False, now, gift=True)
    db.commit()
    return {**state(user, now), **boxes_view(db, user, now), "coins_added": promo.coins or 0,
            "box_name": BOXES[promo.box_id][0] if results else None, "results": results}
