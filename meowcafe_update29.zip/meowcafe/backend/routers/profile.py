"""
Профиль игрока.
  GET  /api/profile                         — аватар, украшения (открытые и закрытые), места во всех рейтингах
  POST /api/profile {"avatar_cat_id": 9, "decor": "headphones"}

Аватар — любой из своих котов. Украшения открываются за достижения; проверяет сервер.
"""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import economy as eco
from config import ACTIVE_CATS, BETA_UNTIL
from db import get_db
from deps import telegram_data
from models import User, utcnow
from routers.player import get_user, state
from routers.rating import BOARDS, my_place, my_value

router = APIRouter(prefix="/api/profile", tags=["profile"])

# id, название, условие (текст), проверка
DECORS = [
    ("", "Без украшения", "", lambda u, p: True),
    ("beta", "Повязка бета-тестера", "Играть в бета-тесте", lambda u, p: is_beta(u)),
    ("headphones", "Неоновые наушники", "Сыграть 10 мини-игр", lambda u, p: (u.games_played or 0) >= 10),
    ("visor", "Кибер-визор", "Заходить 7 разных дней", lambda u, p: (u.days_active or 0) >= 7),
    ("cap", "Кепка баристы", "Обслужить 20 гостей", lambda u, p: (u.guests_served or 0) >= 20),
    ("halo", "Неоновый нимб", "Собрать всю коллекцию", lambda u, p: set(ACTIVE_CATS) <= {c.cat_id for c in u.cats}),
    ("crown", "Корона", "Попасть в топ-3 любого рейтинга", lambda u, p: any(x and x <= 3 for x in p.values())),
]
DECOR_IDS = {d[0] for d in DECORS}


def is_beta(user: User) -> bool:
    if not BETA_UNTIL:
        return True
    try:
        until = datetime.fromisoformat(BETA_UNTIL).replace(tzinfo=timezone.utc)
    except ValueError:
        return True
    return eco.as_utc(user.created_at) < until


def avatar_of(user: User) -> int | None:
    owned = {c.cat_id for c in user.cats}
    if user.avatar_cat_id in owned:
        return user.avatar_cat_id
    return max(owned, default=None)   # по умолчанию — самый редкий кот


def places_of(db: Session, user: User) -> dict[str, int | None]:
    return {b: my_place(db, user, b) for b in BOARDS}


def profile_view(db: Session, user: User) -> dict:
    places = places_of(db, user)
    decors = [{"id": i, "name": n, "need": need, "open": bool(check(user, places))} for i, n, need, check in DECORS]
    decor = user.avatar_decor or ""
    if not any(d["id"] == decor and d["open"] for d in decors):
        decor = ""
    return {
        "avatar_cat_id": avatar_of(user), "decor": decor, "decors": decors,
        "ratings": {b: {"place": places[b], "value": my_value(user, db, b)} for b in BOARDS},
        "stats": {"cats": len(user.cats), "games": user.games_played or 0, "best": user.game_best or 0,
                  "days": user.days_active or 0, "guests": user.guests_served or 0},
        "beta": is_beta(user),
    }


class ProfileRequest(BaseModel):
    avatar_cat_id: int | None = None
    decor: str | None = None


@router.get("")
def get_profile(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    return {**state(user, utcnow()), "profile": profile_view(db, user)}


@router.post("")
def set_profile(req: ProfileRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    if req.avatar_cat_id is not None:
        if req.avatar_cat_id not in {c.cat_id for c in user.cats}:
            raise HTTPException(status_code=400, detail="Этого кота у тебя ещё нет")
        user.avatar_cat_id = req.avatar_cat_id
    if req.decor is not None:
        if req.decor not in DECOR_IDS:
            raise HTTPException(status_code=400, detail="Нет такого украшения")
        places = places_of(db, user)
        check = next(d[3] for d in DECORS if d[0] == req.decor)
        if not check(user, places):
            raise HTTPException(status_code=400, detail="Это украшение ещё не открыто")
        user.avatar_decor = req.decor
    db.commit()
    return {**state(user, utcnow()), "profile": profile_view(db, user)}
