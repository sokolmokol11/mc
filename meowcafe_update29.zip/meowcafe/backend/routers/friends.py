"""
Шаг 8: друзья.
  GET  /api/friends          — реферальная ссылка, банк друзей, список друзей
  POST /api/friends/collect  — забрать весь банк

Как работает: друг заходит по ссылке t.me/<бот>?startapp=ref_<id> — при первом входе у него записывается referrer_id.
Каждый раз, когда друг собирает доход, 5% падает в банк пригласившего (у друга ничего не отнимается).
«Активный друг» — заходил в 3 разных дня и сыграл 3 засчитанные мини-игры. Только такие идут в рейтинг рефоводов.
"""
import asyncio
import threading
import time
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session, selectinload

import economy as eco
import tg_api
from config import BOT_USERNAME, CENTS, REF_ACTIVE_DAYS, REF_ACTIVE_GAMES, REF_COLLECT_HOURS, REF_SHARE
from db import get_db
from deps import telegram_data
from models import User, utcnow
from routers.player import display_name, get_user, income_of, state

router = APIRouter(prefix="/api/friends", tags=["friends"])
LIST_LIMIT = 100
_bot_username = BOT_USERNAME
_bot_lock = threading.Lock()
_bot_retry_at = 0.0


def _fetch_bot_username():
    global _bot_username, _bot_retry_at
    try:
        _bot_username = asyncio.run(tg_api.call("getMe")).get("username", "")
    except tg_api.TelegramError as e:
        _bot_retry_at = time.time() + 60
        print("[friends] getMe:", e)
    finally:
        _bot_lock.release()


def bot_username() -> str:
    """Имя бота для ссылки. Если не задано в .env (BOT_USERNAME) — спрашиваем у Telegram В ФОНЕ.
    Раньше запрос ждал ответа Telegram (до 10 с через прокси) — из-за этого вкладка «Друзья» долго грузилась."""
    if not _bot_username and time.time() >= _bot_retry_at and _bot_lock.acquire(blocking=False):
        threading.Thread(target=_fetch_bot_username, daemon=True).start()
    return _bot_username


bot_username()   # спросить сразу при запуске сервера


def collect_in(user: User, now) -> int:
    if user.ref_collect_at is None or REF_COLLECT_HOURS <= 0:
        return 0
    ready = eco.as_utc(user.ref_collect_at) + timedelta(hours=REF_COLLECT_HOURS)
    return max(0, int((ready - eco.as_utc(now)).total_seconds()))


def friends_view(db: Session, user: User, now, username: str) -> dict:
    base = select(User).where(User.referrer_id == user.tg_id)
    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    active = db.scalar(select(func.count()).select_from(
        base.where(User.is_active_ref.is_(True)).subquery())) or 0
    rows = db.scalars(base.options(selectinload(User.cats))
                      .order_by(User.is_active_ref.desc(), User.ref_given.desc()).limit(LIST_LIMIT)).all()
    friends, per_hour = [], 0.0
    for f in rows:
        inc = income_of(f)
        per_hour += inc * 3600 * REF_SHARE
        owned = {c.cat_id for c in f.cats}
        friends.append({
            "name": display_name(f),
            "avatar": f.avatar_cat_id if f.avatar_cat_id in owned else max(owned, default=None),
            "decor": f.avatar_decor or "",
            "active": bool(f.is_active_ref),
            "days": min(f.days_active or 0, REF_ACTIVE_DAYS), "games": min(f.games_played or 0, REF_ACTIVE_GAMES),
            "given": (f.ref_given or 0) / CENTS,
        })
    link = f"https://t.me/{username}?startapp=ref_{user.tg_id}" if username else ""
    return {
        "link": link, "bank": (user.ref_bank or 0) / CENTS, "collect_in": collect_in(user, now),
        "per_hour": round(per_hour, 1), "total": total, "active": active, "friends": friends,
        "share_pct": round(REF_SHARE * 100), "need_days": REF_ACTIVE_DAYS, "need_games": REF_ACTIVE_GAMES,
    }


@router.get("")
def get_friends(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    name = bot_username()                # сеть — до блокировки игрока
    user = get_user(db, tg)
    now = utcnow()
    return {**state(user, now), "friends": friends_view(db, user, now, name)}


@router.post("/collect")
def collect_bank(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    name = bot_username()
    user = get_user(db, tg)
    now = utcnow()
    if collect_in(user, now) > 0:
        raise HTTPException(status_code=400, detail="Банк пока нельзя забрать — подожди немного")
    db.refresh(user)
    bank = user.ref_bank or 0
    if bank <= 0:
        raise HTTPException(status_code=400, detail="В банке пока пусто — пригласи друзей")
    amount = bank      # забираем весь банк целиком
    # Мяуконы от друзей не идут в рейтинг «Игроки» — там только свой заработок (для друзей есть свой рейтинг).
    db.execute(update(User).where(User.tg_id == user.tg_id)
               .values(ref_bank=User.ref_bank - amount, coins=User.coins + amount, ref_collect_at=now)
               .execution_options(synchronize_session=False))
    db.commit()
    db.refresh(user)
    return {**state(user, now), "friends": friends_view(db, user, now, name),
            "collected": amount / CENTS}
