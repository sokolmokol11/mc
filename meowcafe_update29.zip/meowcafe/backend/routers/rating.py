"""
Шаг 9: рейтинг сезона.
  GET /api/rating?board=players|games|refs  — топ-100, моё место, сезон и призы

  players — сумма мяуконов, заработанных за сезон (coins_earned_season)
  games   — сумма засчитанных очков мини-игр (game_points_season; подозрительные партии сюда не попадают)
  refs    — число АКТИВНЫХ друзей (3 дня + 3 игры)
Игроки с banned=True в рейтинг не попадают. Таблицы пересчитываем не чаще раза в 30 секунд.
"""
import time
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session, aliased, selectinload

import economy as eco
from config import CENTS, PRIZE_POOL_USD, RATING_TOP, SEASON_DAYS, SEASON_NAME
from db import get_db
from deps import telegram_data
from models import Season, User, utcnow
from prizes import board_prizes
from routers.player import display_name, get_user

router = APIRouter(prefix="/api/rating", tags=["rating"])
BOARDS = ("players", "games", "refs")
CACHE_SEC = 30
_cache: dict[str, tuple[float, list[dict], int]] = {}


def current_season(db: Session) -> Season:
    season = db.scalars(select(Season).order_by(Season.id.desc()).limit(1)).first()
    if season is None:
        now = utcnow()
        season = Season(name=SEASON_NAME, starts_at=now, ends_at=now + timedelta(days=SEASON_DAYS))
        db.add(season)
        db.commit()
    return season




_season_start = {"t": 0.0, "v": None}


def season_start(db: Session):
    """Начало текущего сезона (кэш на 30 с): в рейтинг «Друзья» идут те, кто стал активным в этом сезоне."""
    if time.time() - _season_start["t"] > CACHE_SEC or _season_start["v"] is None:
        _season_start["v"], _season_start["t"] = current_season(db).starts_at, time.time()
    return _season_start["v"]


def _refs_counts(db: Session):
    friend = aliased(User)
    return (select(friend.referrer_id.label("rid"), func.count().label("n"))
            .where(friend.is_active_ref.is_(True), friend.banned.is_not(True), friend.referrer_id.is_not(None),
                   friend.ref_active_at >= season_start(db))
            .group_by(friend.referrer_id).subquery())


def _value_col(board: str):
    return User.coins_earned_season if board == "players" else User.game_points_season


def board_rows(db: Session, board: str, limit: int | None = RATING_TOP):
    """Топ (пользователь, значение) по убыванию. При равенстве выше тот, кто раньше начал играть."""
    if board == "refs":
        cnt = _refs_counts(db)
        q = (select(User, cnt.c.n).join(cnt, cnt.c.rid == User.tg_id)
             .where(User.banned.is_not(True)).order_by(cnt.c.n.desc(), User.created_at))
        scale = 1
    else:
        col = _value_col(board)
        q = select(User, col).where(User.banned.is_not(True), col > 0).order_by(col.desc(), User.created_at)
        scale = CENTS if board == "players" else 1
    if limit:
        q = q.limit(limit)
    q = q.options(selectinload(User.cats))
    return [(u, (v or 0) / scale) for u, v in db.execute(q)]


def board_total(db: Session, board: str) -> int:
    if board == "refs":
        cnt = _refs_counts(db)
        return db.scalar(select(func.count()).select_from(cnt.join(User, User.tg_id == cnt.c.rid))
                         .where(User.banned.is_not(True))) or 0
    col = _value_col(board)
    return db.scalar(select(func.count()).select_from(User).where(User.banned.is_not(True), col > 0)) or 0


def board_cached(db: Session, board: str):
    """Топ-100 и число участников. Пересчитываем не чаще раза в 30 секунд."""
    hit = _cache.get(board)
    if hit and time.time() - hit[0] < CACHE_SEC:
        return hit[1], hit[2]

    def avatar(u):
        owned = {c.cat_id for c in u.cats}
        return (u.avatar_cat_id if u.avatar_cat_id in owned else max(owned, default=None)), (u.avatar_decor or "")
    top = []
    for i, (u, v) in enumerate(board_rows(db, board)):
        a, d = avatar(u)
        top.append({"place": i + 1, "id": u.tg_id, "name": display_name(u), "value": v, "avatar": a, "decor": d})
    total = board_total(db, board)
    _cache[board] = (time.time(), top, total)
    return top, total


def my_value(user: User, db: Session, board: str) -> float:
    if board == "players":
        return (user.coins_earned_season or 0) / CENTS
    if board == "games":
        return float(user.game_points_season or 0)
    return float(db.scalar(select(func.count()).select_from(User)
                           .where(User.referrer_id == user.tg_id, User.is_active_ref.is_(True),
                                  User.banned.is_not(True), User.ref_active_at >= season_start(db))) or 0)


def my_place(db: Session, user: User, board: str) -> int | None:
    """Место игрока одним запросом COUNT: сколько людей выше него (+1)."""
    if user.banned:
        return None
    top, _ = board_cached(db, board)
    hit = next((r["place"] for r in top if r["id"] == user.tg_id), None)
    if hit:
        return hit
    if board == "refs":
        mine = int(my_value(user, db, board))
        if mine <= 0:
            return None
        cnt = _refs_counts(db)
        above = db.scalar(select(func.count()).select_from(cnt.join(User, User.tg_id == cnt.c.rid))
                          .where(User.banned.is_not(True),
                                 (cnt.c.n > mine) | ((cnt.c.n == mine) & (User.created_at < user.created_at)))) or 0
        return above + 1
    col = _value_col(board)
    mine = getattr(user, col.key) or 0
    if mine <= 0:
        return None
    above = db.scalar(select(func.count()).select_from(User)
                      .where(User.banned.is_not(True),
                             (col > mine) | ((col == mine) & (User.created_at < user.created_at)))) or 0
    return above + 1


@router.get("")
def get_rating(board: str = Query("players"), tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if board not in BOARDS:
        raise HTTPException(status_code=400, detail="Нет такого рейтинга")
    user = get_user(db, tg)
    now = utcnow()
    season = current_season(db)
    top, total = board_cached(db, board)
    place = my_place(db, user, board)
    prizes = board_prizes(board) if PRIZE_POOL_USD > 0 else []
    ends_in = max(0, int((eco.as_utc(season.ends_at) - eco.as_utc(now)).total_seconds()))
    return {
        "board": board,
        "season": {"name": season.name, "ends_in": ends_in, "ended": ends_in == 0,
                   "pool": PRIZE_POOL_USD, "days": SEASON_DAYS},
        "prizes": prizes,
        "top": [{**r, "me": r["id"] == user.tg_id, "prize": prizes[r["place"] - 1] if r["place"] <= len(prizes) else 0}
                for r in top],
        "me": {"place": place, "value": my_value(user, db, board), "name": display_name(user),
               "banned": bool(user.banned), "total": total},
    }
