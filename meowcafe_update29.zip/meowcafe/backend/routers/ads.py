"""
Шаг 10: реклама Adsgram с подтверждением на сервере.

  POST /api/ads/start   {"kind": "free_box"|"game_x2"|"attempt", "ref": 12}  → {"ad_id": 1}
       Игрок нажал «Смотреть». Проверяем, что награда сейчас доступна, и записываем начало показа.
  GET  /api/ads/reward?userid=[userId]&secret=...
       Это вызывает САМ Adsgram, когда реклама досмотрена (Reward URL в кабинете). Помечаем показ подтверждённым.
  POST /api/ads/claim   {"ad_id": 1}
       Фронт после рекламы спрашивает: «подтвердили?». Если да — выдаём награду (один раз).

Почему так: если верить фронту на слово, любой может вызвать «реклама досмотрена» без рекламы.
Reward URL приходит от Adsgram, а секрет в нём знают только Adsgram и наш сервер.
"""
import hmac
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

import economy as eco
import quests as qs
from config import (AD_CONFIRM_MINUTES, ADS_ATTEMPTS_PER_DAY, ADS_PER_DAY, ADS_TEST_MODE, ADSGRAM_BLOCK_ID,
                    ADSGRAM_SECRET, CENTS, GAME_ATTEMPTS_MAX)
from db import get_db
from deps import telegram_data
from models import AdView, GameSession, User, utcnow
from routers.boxes import boxes_view, free_box_in, open_boxes_core
from routers.game import game_view, refresh_attempts
from routers.player import get_user, state

router = APIRouter(prefix="/api/ads", tags=["ads"])
KINDS = ("free_box", "game_x2", "attempt")
X2_WINDOW_MIN = 10   # удвоить награду партии можно в течение 10 минут после неё


class StartRequest(BaseModel):
    kind: str
    ref: int | None = None


class ClaimRequest(BaseModel):
    ad_id: int


def used_today(db: Session, user_id: int, day: int, kind: str | None = None) -> int:
    q = select(func.count()).select_from(AdView).where(AdView.user_id == user_id, AdView.day == day,
                                                      AdView.status == "used")
    if kind:
        q = q.where(AdView.kind == kind)
    return db.scalar(q) or 0


def ads_left(db: Session, user_id: int, now) -> dict:
    day = qs.day_index(now)
    return {"total": max(0, ADS_PER_DAY - used_today(db, user_id, day)),
            "attempts": max(0, ADS_ATTEMPTS_PER_DAY - used_today(db, user_id, day, "attempt"))}


def x2_session(db: Session, user: User, ref: int | None, now) -> GameSession:
    s = db.get(GameSession, ref) if ref is not None else None
    if s is None or s.user_id != user.tg_id or s.finished_at is None:
        raise HTTPException(status_code=400, detail="Партия не найдена")
    if s.doubled:
        raise HTTPException(status_code=400, detail="Награда за эту партию уже удвоена")
    if (s.reward or 0) <= 0:
        raise HTTPException(status_code=400, detail="Удваивать нечего")
    if eco.as_utc(now) - eco.as_utc(s.finished_at) > timedelta(minutes=X2_WINDOW_MIN):
        raise HTTPException(status_code=400, detail="Удвоить можно только сразу после игры")
    return s


def check_available(db: Session, user: User, kind: str, ref: int | None, now) -> None:
    """Награда должна быть доступна ДО показа рекламы — иначе игрок посмотрит зря."""
    left = ads_left(db, user.tg_id, now)
    if left["total"] <= 0:
        raise HTTPException(status_code=400, detail="На сегодня реклама закончилась — приходи завтра")
    if kind == "free_box" and free_box_in(user, now) > 0:
        raise HTTPException(status_code=400, detail="Бесплатная коробка ещё не готова")
    if kind == "attempt":
        refresh_attempts(user, now)
        if left["attempts"] <= 0:
            raise HTTPException(status_code=400, detail="Попытки за рекламу на сегодня закончились")
        if user.game_attempts >= GAME_ATTEMPTS_MAX:
            raise HTTPException(status_code=400, detail="Попытки и так полные")
    if kind == "game_x2":
        x2_session(db, user, ref, now)


@router.post("/start")
def start_ad(req: StartRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if not ADSGRAM_BLOCK_ID:
        raise HTTPException(status_code=400, detail="Реклама выключена")
    if req.kind not in KINDS:
        raise HTTPException(status_code=400, detail="Неизвестная награда")
    user = get_user(db, tg)
    now = utcnow()
    check_available(db, user, req.kind, req.ref, now)
    ad = AdView(user_id=user.tg_id, kind=req.kind, ref=req.ref, status="pending", day=qs.day_index(now), created_at=now)
    db.add(ad)
    db.commit()
    return {"ad_id": ad.id}


@router.get("/reward")
def adsgram_reward(userid: int = Query(...), secret: str = Query(""), db: Session = Depends(get_db)):
    """Вызывает Adsgram. Подтверждаем последний начатый показ этого игрока."""
    if not ADSGRAM_SECRET or not hmac.compare_digest(secret.encode(), ADSGRAM_SECRET.encode()):
        raise HTTPException(status_code=403, detail="bad secret")
    now = utcnow()
    since = now - timedelta(minutes=AD_CONFIRM_MINUTES)
    ad = db.scalars(select(AdView).where(AdView.user_id == userid, AdView.status == "pending",
                                         AdView.created_at >= since)
                    .order_by(AdView.id.desc()).limit(1)).first()
    if ad is None:
        print(f"[ads] reward для {userid}: нет ожидающего показа")
        return {"ok": False}
    ad.status, ad.confirmed_at = "confirmed", now
    db.commit()
    return {"ok": True}


@router.post("/claim")
def claim_ad(req: ClaimRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    ad = db.get(AdView, req.ad_id)
    if ad is None or ad.user_id != user.tg_id:
        raise HTTPException(status_code=404, detail="Показ не найден")
    if ad.status == "used":
        raise HTTPException(status_code=400, detail="Награда уже получена")
    if ad.status == "pending":
        if not ADS_TEST_MODE:
            # 409 — фронт подождёт и спросит ещё раз: Reward URL приходит через пару секунд
            raise HTTPException(status_code=409, detail="Ждём подтверждения просмотра")
        ad.status = "confirmed"
        db.flush()

    # Ставим used одной командой с условием — двойной запрос не выдаст награду дважды.
    res = db.execute(update(AdView).where(AdView.id == ad.id, AdView.status == "confirmed")
                     .values(status="used").execution_options(synchronize_session=False))
    if res.rowcount == 0:
        db.rollback()
        raise HTTPException(status_code=400, detail="Награда уже получена")

    out: dict = {}
    if ad.kind == "free_box":
        out["results"] = open_boxes_core(db, user, 0, 1, True, now)
    elif ad.kind == "attempt":
        refresh_attempts(user, now)
        user.game_attempts = min(GAME_ATTEMPTS_MAX, (user.game_attempts or 0) + 1)
        if user.game_attempts >= GAME_ATTEMPTS_MAX:
            user.attempts_at = None
    elif ad.kind == "game_x2":
        s = x2_session(db, user, ad.ref, now)
        s.doubled = True
        user.coins += s.reward
        user.coins_earned_season += s.reward
        out["reward"] = s.reward / CENTS
    db.commit()
    return {**state(user, now), **out, "kind": ad.kind, "game": game_view(user, now),
            **boxes_view(db, user, now), "ads_left": ads_left(db, user.tg_id, now)}
