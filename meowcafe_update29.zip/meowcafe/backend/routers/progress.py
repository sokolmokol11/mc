"""
Шаг 5: развитие кафе.
  POST /api/locations/open  — открыть следующую локацию
  POST /api/upgrades/buy    — {"kind": "cash" | "bank"}
  POST /api/level/claim     — забрать награды за новые уровни кафе
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import economy as eco
import levels
import quests as qs
from config import LOCATIONS, UPGRADE_MAX
from db import get_db
from deps import telegram_data
from models import utcnow
from routers.player import UPGRADE_INFO, collect, get_user, income_of, location_counts, spend, state

router = APIRouter(prefix="/api", tags=["progress"])


class UpgradeRequest(BaseModel):
    kind: str


class MoveRequest(BaseModel):
    cat_id: int
    location: int | None = None


@router.post("/locations/open")
def open_location(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    nxt = user.locations_open or 2
    if nxt >= len(LOCATIONS):
        raise HTTPException(status_code=400, detail="Все локации уже открыты")
    if levels.level_of(user.xp or 0) < LOCATIONS[nxt][4]:
        raise HTTPException(status_code=400, detail=f"{LOCATIONS[nxt][0]} откроется на {LOCATIONS[nxt][4]} уровне кафе")
    spend(db, user, LOCATIONS[nxt][1], now)
    user.locations_open = nxt + 1
    levels.add(user, "room")
    db.commit()
    return {**state(user, now), "opened": LOCATIONS[nxt][0]}


@router.post("/upgrades/buy")
def buy_upgrade(req: UpgradeRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if req.kind not in UPGRADE_INFO:
        raise HTTPException(status_code=400, detail="Нет такого улучшения")
    user = get_user(db, tg)
    now = utcnow()
    field = f"{req.kind}_level"
    level = getattr(user, field) or 1
    if level >= UPGRADE_MAX[req.kind]:
        raise HTTPException(status_code=400, detail="Максимальный уровень")
    # Касса меняет доход, а копилка — лимит: spend() сначала собирает накопленное по старым правилам.
    spend(db, user, eco.upgrade_cost(req.kind, level), now)
    setattr(user, field, level + 1)
    levels.add(user, "upgrade")
    db.commit()
    return {**state(user, now), "upgraded": UPGRADE_INFO[req.kind][0], "upgrade_level": level + 1}


@router.post("/level/claim")
def claim_level(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    """Забрать награды за все достигнутые, но ещё не забранные уровни."""
    from routers.boxes import give_box
    from routers.tasks import give
    user = get_user(db, tg)
    now = utcnow()
    lvl = levels.level_of(user.xp or 0)
    start = user.level_claimed or 1
    if lvl <= start:
        raise HTTPException(status_code=400, detail="Новых наград за уровень нет")
    coins, results, unlocks, boxes = 0, [], [], []
    for l in range(start + 1, lvl + 1):
        rule, box = levels.reward_of(l)
        amount = qs.scaled_reward(income_of(user), rule)
        if amount:
            give(db, user, f"lvl_{l}", amount)   # ключ с номером уровня: дважды не выдаст
            coins += amount
        if box is not None:
            results += give_box(db, user, box, now)
            boxes.append(qs.box_name(box))
        unlocks += levels.unlocks_of(l)
    user.level_claimed = lvl
    db.commit()
    return {**state(user, now), "reward": coins / 100, "results": results, "boxes": boxes, "unlocks": unlocks,
            "from_level": start + 1, "to_level": lvl}
