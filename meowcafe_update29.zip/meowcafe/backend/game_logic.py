"""
Десертопад: генератор партии по seed и проверка тапов.

ВАЖНО: тот же генератор (mulberry32 + schedule) повторён во frontend/index.html.
Если меняешь здесь числа или формулы — поменяй и там, иначе честные тапы перестанут засчитываться.
Тест tests/test_game.py сверяет Python и JavaScript на одних и тех же seed.

Координаты в процентах поля: x — по ширине, y — по высоте. Время — миллисекунды от старта.
"""
import math

DURATION_MS = 30_000
SPAWN_BASE_MS = 450
SPEEDUP = 1.3                        # к концу игры всё падает и появляется в 2,3 раза быстрее
# тип: (очки, вес выпадения); rock — камень, отнимает 25% очков
ITEM_TYPES = [("cup", 1, 32), ("donut", 1, 24), ("cake", 2, 16), ("gold", 5, 6), ("rock", 0, 22)]
HIT_X = 10.0                         # допуск попадания по ширине, %
HIT_Y = 7.0                          # допуск по высоте, %
ROCK_PENALTY = 0.25

MAX_TAPS = 240                       # больше 8 тапов в секунду человек не делает
MIN_HUMAN_REACTION_MS = 150          # если почти все попадания быстрее — это скрипт
MIN_HITS_FOR_MISS_CHECK = 35         # 35+ попаданий и ни одного промаха — подозрительно

M32 = 0xFFFFFFFF


def _imul(a: int, b: int) -> int:
    return (a * b) & M32


def mulberry32(seed: int):
    """Тот же генератор случайных чисел, что Math.imul-версия в JS: одинаковые числа в обоих языках."""
    a = seed & M32

    def rnd() -> float:
        nonlocal a
        a = (a + 0x6D2B79F5) & M32
        t = _imul(a ^ (a >> 15), 1 | a)
        t = ((t + _imul(t ^ (t >> 7), 61 | t)) & M32) ^ t
        return ((t ^ (t >> 14)) & M32) / 4294967296
    return rnd


def schedule(seed: int) -> list[dict]:
    """Все предметы партии: когда появляется (t0), где (x), как быстро падает (v, % высоты в секунду)."""
    rnd = mulberry32(seed)
    total_w = sum(w for _, _, w in ITEM_TYPES)
    items = []
    t = 0.0
    while True:
        t += SPAWN_BASE_MS / (1 + t / DURATION_MS * SPEEDUP)
        if t >= DURATION_MS:
            break
        r = rnd() * total_w
        kind = ITEM_TYPES[-1]
        for it in ITEM_TYPES:
            if r < it[2]:
                kind = it
                break
            r -= it[2]
        x = 10 + rnd() * 80
        v = (20 + rnd() * 14) * (1 + t / DURATION_MS * SPEEDUP)
        items.append({"t0": t, "kind": kind[0], "pts": kind[1], "x": x, "v": v})
    return items


def y_at(item: dict, t: float) -> float:
    return -8 + item["v"] * (t - item["t0"]) / 1000


def verify(seed: int, taps: list) -> dict:
    """
    Проигрывает партию и считает очки по тапам [[t, x, y], ...].
    Возвращает очки и флаг подозрения (флаг игроку не показываем).
    """
    items = schedule(seed)
    caught = set()
    score = hits = misses = rocks = 0
    reactions = []
    reasons = []
    last_t = -1.0

    if len(taps) > MAX_TAPS:
        reasons.append("too_many_taps")
        taps = taps[:MAX_TAPS]

    for tap in taps:
        try:
            t, x, y = float(tap[0]), float(tap[1]), float(tap[2])
        except (TypeError, ValueError, IndexError):
            reasons.append("bad_tap")
            continue
        if not (0 <= t <= DURATION_MS + 500 and -5 <= x <= 105 and -10 <= y <= 115) or t < last_t:
            reasons.append("bad_tap")
            continue
        last_t = t

        best, best_d = None, None
        for i, it in enumerate(items):
            if i in caught or it["t0"] > t:
                continue
            iy = y_at(it, t)
            if iy < -8 or iy > 108:
                continue
            dx, dy = abs(x - it["x"]), abs(y - iy)
            if dx <= HIT_X and dy <= HIT_Y and (best_d is None or dx + dy < best_d):
                best, best_d = i, dx + dy
        if best is None:
            misses += 1
            continue

        it = items[best]
        caught.add(best)
        hits += 1
        visible_at = it["t0"] + 8 * 1000 / it["v"]  # когда предмет показался сверху поля
        reactions.append(t - visible_at)
        if it["kind"] == "rock":
            rocks += 1
            score -= math.ceil(score * ROCK_PENALTY)
        else:
            score += it["pts"]

    if len(reactions) >= 10:
        fast = sum(1 for r in reactions if r < MIN_HUMAN_REACTION_MS)
        if fast / len(reactions) > 0.8:
            reasons.append("inhuman_reaction")
    if hits >= MIN_HITS_FOR_MISS_CHECK and misses == 0:
        reasons.append("no_misses")

    return {"score": max(0, score), "hits": hits, "misses": misses, "rocks": rocks,
            "flagged": bool(reasons), "reasons": sorted(set(reasons))}
