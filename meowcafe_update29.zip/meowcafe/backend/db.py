"""
Подключение к базе.
  В бою — PostgreSQL:  DATABASE_URL=postgresql://meowcafe:пароль@127.0.0.1:5432/meowcafe
  Для отладки можно SQLite: DATABASE_URL=sqlite:///./meowcafe.db (только один процесс сервера!)
"""
from sqlalchemy import create_engine, event, inspect, text
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from config import DATABASE_URL

IS_PG = DATABASE_URL.startswith("postgresql")

if IS_PG:
    engine = create_engine(
        DATABASE_URL, pool_size=10, max_overflow=20, pool_pre_ping=True, pool_recycle=1800,
        # ждём чужую блокировку не дольше 5 с, а запрос целиком — не дольше 15 с: зависший запрос не повесит сервер
        connect_args={"options": "-c lock_timeout=5000 -c statement_timeout=15000 -c timezone=UTC"})
else:
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False, "timeout": 15})

    @event.listens_for(engine, "connect")
    def _sqlite_pragmas(conn, _):
        conn.isolation_level = None                  # транзакции открываем сами (ниже)
        cur = conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA busy_timeout=15000")
        cur.close()

    @event.listens_for(engine, "begin")
    def _sqlite_begin(conn):
        # SQLite не умеет блокировать одну строку, поэтому запросы выполняются строго по очереди.
        # Для отладки хватает, для игры — PostgreSQL.
        conn.exec_driver_sql("BEGIN IMMEDIATE")

SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    """Зависимость FastAPI: одна сессия базы на запрос."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def auto_migrate() -> list[str]:
    """
    Добавляет в существующую базу новые колонки из models.py, чтобы при обновлении не удалять meowcafe.db.
    Умеет только ДОБАВЛЯТЬ колонки (и создавать новые таблицы). Переименования и удаления — руками.
    Несколько процессов сервера стартуют одновременно — в PostgreSQL миграцию делает только один (advisory lock).
    """
    if IS_PG:
        with engine.connect() as conn:
            conn.execute(text("SELECT pg_advisory_lock(424242)"))
            try:
                return _migrate()
            finally:
                conn.execute(text("SELECT pg_advisory_unlock(424242)"))
                conn.commit()
    return _migrate()


def _migrate() -> list[str]:
    added = []
    with engine.begin() as conn:                # всё одной транзакцией и одним соединением
        Base.metadata.create_all(conn)          # новые таблицы
        insp = inspect(conn)
        for table in Base.metadata.sorted_tables:
            have = {c["name"] for c in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name in have:
                    continue
                ddl_type = col.type.compile(dialect=engine.dialect)
                conn.execute(text(f'ALTER TABLE {table.name} ADD COLUMN {col.name} {ddl_type}'))
                default = col.default.arg if col.default is not None and not callable(col.default.arg) else None
                if default is not None:
                    conn.execute(text(f"UPDATE {table.name} SET {col.name} = :v"), {"v": default})
                added.append(f"{table.name}.{col.name}")
        for table in Base.metadata.sorted_tables:   # индексы на новых колонках
            for index in table.indexes:
                index.create(conn, checkfirst=True)
    return added
