#!/bin/bash
# Отправить себе сообщение (или файл) от бота:  tg_send.sh "текст" [файл]
# Берёт BOT_TOKEN, ADMIN_ID и PROXY_URL из backend/.env. Без ADMIN_ID молча ничего не делает.
ENVF="$(cd "$(dirname "$0")/.." && pwd)/backend/.env"
getenv() { grep -E "^$1=" "$ENVF" | tail -1 | cut -d= -f2- ; }
TOKEN=$(getenv BOT_TOKEN); ADMIN=$(getenv ADMIN_ID); PROXY=$(getenv PROXY_URL)
[ -n "$TOKEN" ] && [ -n "$ADMIN" ] || exit 0
P=()
[ -n "$PROXY" ] && P=(--proxy "${PROXY/socks5:\/\//socks5h://}")
if [ -n "${2:-}" ]; then
  curl -sS -m 120 "${P[@]}" -F chat_id="$ADMIN" -F caption="$1" -F document=@"$2" \
       "https://api.telegram.org/bot$TOKEN/sendDocument" >/dev/null
else
  curl -sS -m 30 "${P[@]}" --data-urlencode chat_id="$ADMIN" --data-urlencode text="$1" \
       "https://api.telegram.org/bot$TOKEN/sendMessage" >/dev/null
fi
