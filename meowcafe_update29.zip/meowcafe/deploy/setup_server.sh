#!/bin/bash
# Одноразовая настройка сервера MeowCafe (AlmaLinux):
#   1) PostgreSQL вместо SQLite + перенос всех данных
#   2) 2–4 процесса сервера вместо одного
#   3) ежедневный бэкап базы (на сервер + файлом тебе в Telegram)
#   4) сторож: каждые 2 минуты проверяет сервер, если лёг — перезапускает и пишет тебе
#
# Запуск:  bash /root/meowcafe/deploy/setup_server.sh ТВОЙ_TELEGRAM_ID
# Повторный запуск безопасен: уже сделанные шаги пропускаются.
set -euo pipefail

ADMIN="${1:-}"
APP=${APP:-/root/meowcafe}
BE=$APP/backend
ENVF=$BE/.env
LOG() { echo -e "\n\033[1;36m== $*\033[0m"; }
die() { echo -e "\033[1;31mОШИБКА: $*\033[0m"; exit 1; }

[ "$(id -u)" = 0 ] || die "запусти от root"
[ -f "$ENVF" ] || die "нет файла $ENVF"
getenv() { grep -E "^$1=" "$ENVF" | tail -1 | cut -d= -f2- || true; }
setenv() {   # заменить строку KEY=... в .env или дописать
  if grep -qE "^$1=" "$ENVF"; then
    "$VBIN/python" - "$ENVF" "$1" "$2" <<'PY'
import sys
path, key, val = sys.argv[1:]
lines = open(path).read().splitlines()
lines = [f"{key}={val}" if l.startswith(key + "=") else l for l in lines]
open(path, "w").write("\n".join(lines) + "\n")
PY
  else echo "$1=$2" >> "$ENVF"; fi
}

# --- где живёт сервер: путь к uvicorn берём из systemd ---
CMD=$(systemctl show -p ExecStart --value mc-api | sed -n 's/.*argv\[\]=\([^;]*\);.*/\1/p' | sed 's/[[:space:]]*$//')
[ -n "$CMD" ] || die "не нашёл сервис mc-api"
UVI=${CMD%% *}
VBIN=$(dirname "$UVI")
[ -x "$VBIN/python" ] || die "не нашёл python рядом с $UVI"
PORT=$(echo "$CMD" | grep -oE -- '--port[ =][0-9]+' | grep -oE '[0-9]+' || echo 8000)
echo "Сервер: $CMD"

chmod 600 "$ENVF"   # токен бота и пароль базы видит только root

if [ -n "$ADMIN" ]; then
  [[ "$ADMIN" =~ ^[0-9]+$ ]] || die "Telegram id — это только цифры"
  setenv ADMIN_ID "$ADMIN"
fi

# ---------- 1. PostgreSQL ----------
LOG "1/4 PostgreSQL"
if ! rpm -q postgresql-server >/dev/null 2>&1; then
  dnf -y -q module reset postgresql >/dev/null 2>&1 || true
  dnf -y -q module enable postgresql:16 >/dev/null 2>&1 || true
  dnf -y -q install postgresql-server postgresql
fi
[ -f /var/lib/pgsql/data/PG_VERSION ] || postgresql-setup --initdb
HBA=/var/lib/pgsql/data/pg_hba.conf
# вход по паролю с самого сервера (снаружи база закрыта: слушает только localhost)
sed -i -E 's/^(host[[:space:]]+all[[:space:]]+all[[:space:]]+(127\.0\.0\.1\/32|::1\/128)[[:space:]]+)ident/\1scram-sha-256/' "$HBA"
systemctl enable -q --now postgresql
systemctl reload postgresql
psqlq() { (cd /tmp && runuser -u postgres -- psql -v ON_ERROR_STOP=1 -tAq "$@"); }

"$VBIN/pip" install -q "psycopg[binary]>=3.1"

if getenv DATABASE_URL | grep -q '^postgresql'; then
  echo "База уже PostgreSQL — перенос пропускаю"
else
  PW=$(openssl rand -hex 16)
  if [ "$(psqlq -c "SELECT 1 FROM pg_roles WHERE rolname='meowcafe'")" = 1 ]; then
    psqlq -c "ALTER ROLE meowcafe LOGIN PASSWORD '$PW'"
  else
    psqlq -c "CREATE ROLE meowcafe LOGIN PASSWORD '$PW'"
  fi
  [ "$(psqlq -c "SELECT 1 FROM pg_database WHERE datname='meowcafe'")" = 1 ] || (cd /tmp && runuser -u postgres -- createdb -O meowcafe meowcafe)
  PGURL="postgresql://meowcafe:$PW@127.0.0.1:5432/meowcafe"

  OLD=$(getenv DATABASE_URL); OLD=${OLD:-sqlite:///./meowcafe.db}
  systemctl stop mc-api
  cd "$BE"
  OLDFILE=${OLD#sqlite:///}
  [ -f "$OLDFILE" ] && cp "$OLDFILE" "$OLDFILE.before-pg-$(date +%F-%H%M)" && echo "Копия старой базы: $OLDFILE.before-pg-*"
  if [ -f "$OLDFILE" ]; then
    "$VBIN/python" migrate_to_pg.py "$OLD" "$PGURL" || { systemctl start mc-api; die "перенос не удался, сервер оставлен на старой базе"; }
  fi
  setenv DATABASE_URL "$PGURL"
  echo "DATABASE_URL записан в .env"
fi

# ---------- 2. несколько процессов ----------
LOG "2/4 Процессы сервера"
W=$(nproc); [ "$W" -lt 2 ] && W=2; [ "$W" -gt 4 ] && W=4
NEWCMD=$(echo "$CMD" | sed -E 's/ --workers[ =][0-9]+//')" --workers $W"
mkdir -p /etc/systemd/system/mc-api.service.d
cat > /etc/systemd/system/mc-api.service.d/override.conf <<EOF
[Unit]
After=network.target postgresql.service
Wants=postgresql.service

[Service]
ExecStart=
ExecStart=$NEWCMD
Restart=always
RestartSec=3
LimitNOFILE=65535
EOF
systemctl daemon-reload
systemctl restart mc-api
echo "Запущено процессов: $W"
for i in $(seq 1 30); do curl -sf "http://127.0.0.1:$PORT/api/health" >/dev/null && break; sleep 1; done
curl -sf "http://127.0.0.1:$PORT/api/health" >/dev/null || { journalctl -u mc-api -n 30 --no-pager; die "сервер не поднялся, смотри лог выше"; }
echo "Сервер отвечает ✔"

# ---------- 3–4. бэкапы и сторож ----------
LOG "3/4 Бэкапы и сторож"
rpm -q cronie >/dev/null 2>&1 || dnf -y -q install cronie
systemctl enable -q --now crond
cat > /etc/cron.d/meowcafe <<EOF
# MeowCafe: бэкап базы каждую ночь в 04:00 и проверка сервера каждые 2 минуты
0 4 * * * root /bin/bash $APP/deploy/backup.sh >> /var/log/meowcafe-backup.log 2>&1
*/2 * * * * root /bin/bash $APP/deploy/watchdog.sh $PORT >> /var/log/meowcafe-watchdog.log 2>&1
EOF
chmod 644 /etc/cron.d/meowcafe
echo "Расписание записано в /etc/cron.d/meowcafe"

LOG "4/4 Пробный бэкап"
bash "$APP/deploy/backup.sh" || echo "Бэкап не получился — пришли мне вывод выше"

LOG "Готово!"
[ -z "$(getenv ADMIN_ID)" ] && echo "⚠ Не указан твой Telegram id — бэкапы и тревоги в Telegram приходить не будут. Запусти скрипт ещё раз с id."
exit 0
