#!/bin/bash
# Ночной бэкап базы: файл в /root/backups (храним 14 дней) + копия тебе в Telegram.
# Восстановить:  runuser -u postgres -- pg_restore --clean --if-exists -d meowcafe /root/backups/meowcafe-ДАТА.dump
set -uo pipefail
D=$(dirname "$0")
ENVF="$(cd "$(dirname "$0")/.." && pwd)/backend/.env"
URL=$(grep -E '^DATABASE_URL=' "$ENVF" | tail -1 | cut -d= -f2-)
mkdir -p /root/backups && chmod 700 /root/backups
F=/root/backups/meowcafe-$(date +%F).dump

if [[ "$URL" == postgresql* ]]; then
  pg_dump -Fc --dbname="${URL/postgresql+psycopg:/postgresql:}" -f "$F" || { bash "$D/tg_send.sh" "⚠️ MeowCafe: бэкап базы НЕ получился"; exit 1; }
else
  F=${F%.dump}.db
  cp "$(dirname "$ENVF")/${URL#sqlite:///./}" "$F" || exit 1
fi
find /root/backups -name 'meowcafe-*' -mtime +14 -delete
SIZE=$(du -h "$F" | cut -f1)
echo "$(date '+%F %T') бэкап $F ($SIZE)"
# Telegram принимает файлы ботов до 50 МБ
if [ "$(stat -c %s "$F")" -lt 49000000 ]; then
  bash "$D/tg_send.sh" "💾 MeowCafe: бэкап базы $(date +%d.%m), $SIZE" "$F"
else
  bash "$D/tg_send.sh" "💾 MeowCafe: бэкап $(date +%d.%m) готов ($SIZE) — лежит на сервере в /root/backups"
fi
