#!/bin/bash
# Сторож: раз в 2 минуты проверяет, что игра отвечает. Если нет — перезапускает и пишет тебе в Telegram.
# Если лёг весь сервер целиком, этот скрипт тоже не работает — на этот случай UptimeRobot (см. README).
PORT=${1:-8000}
D=$(dirname "$0")
STATE=/run/meowcafe-down
ok() { curl -sf -m 10 "http://127.0.0.1:$PORT/api/health" >/dev/null; }

if ok; then
  if [ -f "$STATE" ]; then rm -f "$STATE"; bash "$D/tg_send.sh" "✅ MeowCafe снова работает"; fi
else
  sleep 15; ok && exit 0                          # одна неудача — может, просто перезапуск
  echo "$(date '+%F %T') сервер не отвечает, перезапускаю"
  systemctl restart postgresql mc-api
  sleep 15
  if ok; then
    bash "$D/tg_send.sh" "⚠️ MeowCafe не отвечал — перезапустил, сейчас работает"
  elif [ ! -f "$STATE" ]; then
    touch "$STATE"
    bash "$D/tg_send.sh" "🔴 MeowCafe лежит и перезапуск не помог! Посмотри: journalctl -u mc-api -n 50"
  fi
fi

# места на диске меньше 10% — предупредим (раз в сутки)
USE=$(df --output=pcent / | tail -1 | tr -dc 0-9)
if [ "${USE:-0}" -ge 90 ] && [ ! -f "/run/meowcafe-disk-$(date +%F)" ]; then
  touch "/run/meowcafe-disk-$(date +%F)"
  bash "$D/tg_send.sh" "💽 MeowCafe: диск занят на ${USE}% — пора чистить /root/backups или логи"
fi
