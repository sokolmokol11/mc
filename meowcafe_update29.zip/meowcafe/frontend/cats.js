// Спрайты котов MeowCafe: векторные, рисуются кодом. Две позы: "sit" (анфас) и "walk" (в профиль).
// У каждого кота свой окрас, узор, глаза и аксессуар; у редких — аксессуары, у легендарных и мифических — свечение.
// Использование: CatArt.svg(catId, "sit" | "walk", размер_в_px)
(function (root) {
  // fur — шерсть, dark — узор/тени, belly — грудка/мордочка, eye — глаза, pattern, acc — аксессуар
  // id = редкость × 4 + номер. Какие из них сейчас в игре — решает сервер (ACTIVE_CATS), остальные — запас на будущее.
  const CATS = [
    // Обычные
    { fur: "#E8B57A", dark: "#B9824F", belly: "#FFE7C2", eye: "#7FE0B5", pattern: "plain", acc: null, kind: "loaf" },      // 0 Батон — кот-буханка
    { fur: "#A8653A", dark: "#7A4424", belly: "#E8B98A", eye: "#9BE36B", pattern: "plain", acc: "ledcollar", kind: "long" }, // 1 Сосиска — очень длинный
    { fur: "#B8B8C4", dark: "#8A8A98", belly: "#EDEDF2", eye: "#7FB8FF", pattern: "tabby", acc: "grandpa" },                // 2 Дед — очки и брови (в бете)
    { fur: "#F28C3C", dark: "#D46A1E", belly: "#FFD9B0", eye: "#FFD34D", pattern: "plain", acc: null },                     // 3 (запас)
    // Редкие
    { fur: "#9AA3B5", dark: "#6B7385", belly: "#E3E7EF", eye: "#FFD34D", pattern: "tabby", acc: null, kind: "box" },       // 4 Коробкин — живёт в коробке
    { fur: "#C9B8E8", dark: "#9E8CC4", belly: "#F0E9FF", eye: "#7FD0FF", pattern: "plain", acc: "nightcap", kind: "sleepy" }, // 5 Соня — всегда спит
    { fur: "#2A2638", dark: "#17141F", belly: "#3A3550", eye: "#FFE14D", pattern: "plain", acc: "bell" },                   // 6 (запас)
    { fur: "#E8B98A", dark: "#B9824F", belly: "#FFF0DD", eye: "#FF8FC4", pattern: "patch", acc: "chef" },                   // 7 (запас)
    // Эпические
    { fur: "#C9CDE8", dark: "#9AA0C8", belly: "#F0F1FF", eye: "#B388FF", pattern: "moon", acc: "stars" },        // 8 Луна
    { fur: "#2B2050", dark: "#5EE7FF", belly: "#3A2C6B", eye: "#FF5CA8", pattern: "neon", acc: "headphones" },   // 9 Неон
    { fur: "#8E8AA6", dark: "#66627E", belly: "#BDB9D6", eye: "#E2B6FF", pattern: "smoke", acc: "mist" },        // 10 (запас)
    { fur: "#4A4060", dark: "#2E2640", belly: "#F4F1FA", eye: "#B5FF7A", pattern: "tuxedo", acc: "tophat" },     // 11 (запас)
    // Легендарные
    { fur: "#B8C4D9", dark: "#7A869C", belly: "#E3EAF5", eye: "#5EE7FF", pattern: "cyber", acc: "visor" },       // 12 Кибер
    { fur: "#FF9A4D", dark: "#FF5C2E", belly: "#FFE0B8", eye: "#FFF27A", pattern: "flame", acc: "comet" },       // 13 Комета
    { fur: "#2E2A3E", dark: "#17141F", belly: "#F4F1FA", eye: "#FFC94D", pattern: "tuxedo", acc: "tie" },        // 14 Бизнес-кот (в бете)
    { fur: "#3A3550", dark: "#1F1B2E", belly: "#5A5470", eye: "#FF4D6D", pattern: "plain", acc: "headband" },    // 15 Самурай (в бете)
    // Мифические
    { fur: "#1C1B26", dark: "#39FF88", belly: "#2A2838", eye: "#39FF88", pattern: "code", acc: "hood" },         // 16 0xКОТ — хакер без лица
    { fur: "#F2A65A", dark: "#C77A35", belly: "#FFE3C0", eye: "#FFD34D", pattern: "tiger", acc: "shades" },      // 17 Турбо — водитель красного кабриолета
    { fur: "#1E2B5C", dark: "#3E5AA8", belly: "#2C3C78", eye: "#FFD34D", pattern: "constellation", acc: "orbit" }, // 18 (запас)
    { fur: "#3A1F6B", dark: "#B388FF", belly: "#4E2C8C", eye: "#5EE7FF", pattern: "pulse", acc: "rings" },      // 19 (запас)
  ];
  const GLOW = [null, null, null, "#FFB74D", "#FF5CA8"];
  const lum = (h) => { const n = parseInt(h.slice(1), 16); return (0.299 * (n >> 16) + 0.587 * (n >> 8 & 255) + 0.114 * (n & 255)) / 255; };
  // тёмным котам — светлый контур, чтобы не терялись на тёмном фоне
  const rim = (c) => lum(c.fur) < 0.35 ? ` stroke="#8C7FD0" stroke-width="2"` : "";
  const glowDef = (k, col) => `<radialGradient id="${k}g"><stop offset="0" stop-color="${col}" stop-opacity=".55"/><stop offset=".55" stop-color="${col}" stop-opacity=".18"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></radialGradient>`;
  let uid = 0;

  // ---------- узоры (поверх шерсти, обрезаются по силуэту) ----------
  function patternFront(c) {
    const d = c.dark;
    switch (c.pattern) {
      case "tabby": return `<path d="M42 22 L44 32 M50 20 V31 M58 22 L56 32" stroke="${d}" stroke-width="3" stroke-linecap="round"/>
        <path d="M22 66 q6 4 0 8 M78 66 q-6 4 0 8 M28 80 q5 3 0 7 M72 80 q-5 3 0 7" stroke="${d}" stroke-width="3" fill="none" stroke-linecap="round"/>`;
      case "tiger": return `<path d="M40 20 L45 34 M50 18 V33 M60 20 L55 34 M22 40 l10 3 M78 40 l-10 3 M24 48 l8 1 M76 48 l-8 1" stroke="${d}" stroke-width="3.4" stroke-linecap="round"/>
        <path d="M24 64 q8 5 0 10 M76 64 q-8 5 0 10 M27 79 q7 4 0 9 M73 79 q-7 4 0 9" stroke="${d}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`;
      case "fluffy": return `<path d="M18 46 l-6 2 l5 3 M82 46 l6 2 l-5 3 M24 62 l-6 4 l6 2 M76 62 l6 4 l-6 2" fill="${c.fur}" stroke="${d}" stroke-width="1.5" stroke-linejoin="round"/>`;
      case "tuxedo": return `<path d="M36 60 Q50 98 64 60 Q50 70 36 60 Z" fill="${c.belly}"/>`;
      case "spots": return `<circle cx="30" cy="34" r="5" fill="${d}"/><circle cx="68" cy="70" r="6" fill="${d}"/><circle cx="31" cy="78" r="4" fill="${d}"/>`;
      case "moon": return `<path d="M45 21 a8 8 0 1 0 9 9 a6 6 0 1 1 -9 -9 Z" fill="#FFF6C9"/>`;
      case "neon": return `<path d="M40 20 L44 32 M60 20 L56 32 M24 66 q7 4 0 9 M76 66 q-7 4 0 9" stroke="${d}" stroke-width="2.6" stroke-linecap="round" fill="none"/>`;
      case "smoke": return `<ellipse cx="50" cy="30" rx="18" ry="8" fill="${d}" opacity=".5"/><ellipse cx="50" cy="86" rx="22" ry="8" fill="${d}" opacity=".45"/>`;
      case "patch": return `<path d="M24 22 Q38 18 40 34 Q30 40 22 34 Z" fill="${d}"/><circle cx="70" cy="76" r="8" fill="${d}"/>`;
      case "cyber": return `<path d="M62 24 h10 v8 M66 28 h6 M28 70 h8 v6 M72 80 h-6 v-5" stroke="${d}" stroke-width="2" fill="none" stroke-linecap="round"/><circle cx="72" cy="32" r="2" fill="#5EE7FF"/><circle cx="36" cy="76" r="2" fill="#5EE7FF"/>`;
      case "flame": return `<path d="M44 26 q6 -10 6 -14 q4 6 6 14 q-6 -4 -12 0 Z" fill="${d}"/><path d="M24 74 q-4 -8 2 -12 q0 6 4 8 Z M76 74 q4 -8 -2 -12 q0 6 -4 8 Z" fill="${d}"/>`;
      case "sparkle": return `${star(30, 34, 3, "#fff")}${star(70, 72, 3.4, "#fff")}${star(32, 80, 2.6, "#fff")}${star(64, 24, 2.4, "#fff")}`;
      case "constellation": return `<path d="M26 30 L34 38 L30 48 M66 64 L74 70 L70 82 L62 86" stroke="#9FB6FF" stroke-width="1" fill="none" opacity=".8"/>
        ${[[26, 30], [34, 38], [30, 48], [66, 64], [74, 70], [70, 82], [62, 86]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="1.8" fill="#fff"/>`).join("")}`;
      case "pulse": return `<circle cx="50" cy="74" r="7" fill="none" stroke="${d}" stroke-width="2"/><circle cx="50" cy="74" r="2.6" fill="#5EE7FF"/><path d="M30 30 q4 -4 8 0 M62 30 q4 -4 8 0" stroke="${d}" stroke-width="2" fill="none"/>`;
      case "code": return `<g font-family="monospace" font-size="7" font-weight="700" fill="${d}" opacity=".75"><text x="30" y="70">01</text><text x="56" y="80">1F</text><text x="36" y="88">0x</text><text x="60" y="66">&lt;/&gt;</text></g>`;
      default: return "";
    }
  }
  function patternSide(c) {
    const d = c.dark;
    switch (c.pattern) {
      case "tabby": case "tiger": case "neon": {
        const w = c.pattern === "tiger" ? 3.6 : 3;
        return `<path d="M40 38 q3 8 0 16 M52 36 q3 9 0 18 M64 36 q3 9 0 18 M88 18 l2 8 M96 18 l-1 8" stroke="${d}" stroke-width="${w}" fill="none" stroke-linecap="round"/>`;
      }
      case "tuxedo": return `<path d="M64 60 Q82 66 92 50 L96 58 Q86 72 66 66 Z" fill="${c.belly}"/>`;
      case "spots": return `<circle cx="44" cy="42" r="5" fill="${d}"/><circle cx="60" cy="50" r="4" fill="${d}"/><circle cx="96" cy="22" r="3.5" fill="${d}"/>`;
      case "moon": return `<path d="M92 14 a6 6 0 1 0 7 7 a4.5 4.5 0 1 1 -7 -7 Z" fill="#FFF6C9"/>`;
      case "smoke": return `<ellipse cx="54" cy="40" rx="22" ry="6" fill="${d}" opacity=".5"/>`;
      case "patch": return `<path d="M40 36 Q54 32 58 46 Q46 52 38 46 Z" fill="${d}"/>`;
      case "cyber": return `<path d="M44 40 h12 v6 M60 52 h10" stroke="${d}" stroke-width="2" fill="none"/><circle cx="56" cy="46" r="2" fill="#5EE7FF"/>`;
      case "flame": return `<path d="M40 40 q4 -10 10 -12 q-2 6 2 12 Z M56 38 q4 -8 8 -8 q-2 5 1 9 Z" fill="${d}"/>`;
      case "sparkle": return `${star(44, 42, 3, "#fff")}${star(62, 50, 2.6, "#fff")}${star(96, 22, 2.2, "#fff")}`;
      case "constellation": return `<path d="M38 40 L48 46 L58 40 L68 48" stroke="#9FB6FF" stroke-width="1" fill="none"/>${[[38, 40], [48, 46], [58, 40], [68, 48]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="1.8" fill="#fff"/>`).join("")}`;
      case "pulse": return `<circle cx="54" cy="46" r="6" fill="none" stroke="${d}" stroke-width="2"/><circle cx="54" cy="46" r="2.2" fill="#5EE7FF"/>`;
      case "code": return `<g font-family="monospace" font-size="7" font-weight="700" fill="${d}" opacity=".75"><text x="36" y="48">0x1F</text><text x="58" y="58">01</text></g>`;
      case "fluffy": return `<path d="M30 52 l-5 4 l6 1 M44 62 l-2 5 l5 -2 M70 62 l2 5 l-5 -2" fill="${c.fur}" stroke="${d}" stroke-width="1.4"/>`;
      default: return "";
    }
  }
  const star = (x, y, r, col) => `<path d="M${x} ${y - r * 2} L${x + r * 0.6} ${y - r * 0.6} L${x + r * 2} ${y} L${x + r * 0.6} ${y + r * 0.6} L${x} ${y + r * 2} L${x - r * 0.6} ${y + r * 0.6} L${x - r * 2} ${y} L${x - r * 0.6} ${y - r * 0.6} Z" fill="${col}"/>`;

  // ---------- аксессуары ----------
  function accFront(c) {
    switch (c.acc) {
      case "bow": return `<path d="M50 60 l-10 -6 v12 Z M50 60 l10 -6 v12 Z" fill="#FF5CA8"/><circle cx="50" cy="60" r="3" fill="#FF8FC4"/>`;
      case "nightcap": return `<path d="M26 26 Q40 -2 74 22 Q60 14 50 18 Z" fill="#4A5CC8"/><path d="M26 26 Q50 16 76 24" stroke="#F0E9FF" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M74 22 Q88 26 86 40" stroke="#4A5CC8" stroke-width="5" fill="none" stroke-linecap="round"/><circle cx="86" cy="42" r="5" fill="#F0E9FF"/>
        <g class="cat-z"><text x="82" y="8" font-size="12" font-weight="800" fill="#B9C8FF" font-family="sans-serif">z</text><text x="92" y="-4" font-size="9" font-weight="800" fill="#B9C8FF" font-family="sans-serif">z</text></g>`;
      case "ledcollar": return `<path d="M30 62 Q50 72 70 62" stroke="#21E6FF" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M30 62 Q50 72 70 62" stroke="#fff" stroke-width="1" fill="none" opacity=".7" stroke-dasharray="2 4"/><rect x="45" y="66" width="10" height="7" rx="2" fill="#0B0A18" stroke="#21E6FF" stroke-width="1"/><circle cx="50" cy="69.5" r="1.6" fill="#FF2E88" class="cat-led"/>`;
      case "grandpa": return `<path d="M28 34 q8 -6 16 -2 M56 32 q8 -4 16 2" stroke="#F4F4F8" stroke-width="4" fill="none" stroke-linecap="round"/>
        <circle cx="38" cy="44" r="9" fill="#9FD8FF" fill-opacity=".18" stroke="#3A3550" stroke-width="2"/><circle cx="62" cy="44" r="9" fill="#9FD8FF" fill-opacity=".18" stroke="#3A3550" stroke-width="2"/><path d="M47 44 h6 M29 42 l-8 -3 M71 42 l8 -3" stroke="#3A3550" stroke-width="2"/>
        <path d="M40 58 q5 4 10 0 q5 4 10 0" stroke="#F4F4F8" stroke-width="4" fill="none" stroke-linecap="round"/>`;
      case "tie": return `<path d="M38 62 L50 66 L62 62 L60 68 L50 70 L40 68 Z" fill="#F4F1FA"/><path d="M50 67 l-4 4 l2 16 l2 3 l2 -3 l2 -16 Z" fill="#E21B3C"/><path d="M47 67 h6 l-1 4 h-4 Z" fill="#B5122C"/>
        <g transform="translate(68 74)"><path d="M0 0 h11 l-1.5 12 h-8 Z" fill="#F4F1FA"/><path d="M11 3 q4 1 0 6" stroke="#F4F1FA" stroke-width="1.6" fill="none"/><rect x="0" y="4" width="11" height="3" fill="#8A4B2F"/></g>`;
      case "scarf": return `<path d="M28 58 Q50 68 72 58 L72 64 Q50 74 28 64 Z" fill="#5EC8FF"/><path d="M62 64 l4 16 l6 -2 l-3 -15 Z" fill="#3FA6E0"/>`;
      case "pilotscarf": return `<path d="M28 60 Q50 70 72 60 L72 66 Q50 76 28 66 Z" fill="#F4F1FA"/><path d="M66 64 q18 2 30 -8 q-6 12 -26 16 Z" fill="#F4F1FA" class="cat-scarf"/>`;
      case "bell": return `<path d="M30 58 Q50 66 70 58" stroke="#FF5CA8" stroke-width="4" fill="none"/><circle cx="50" cy="66" r="5" fill="#FFC94D"/><path d="M47 67 h6" stroke="#B5851A" stroke-width="1.5"/>`;
      case "flower": return `<g transform="translate(70 22)">${[0, 72, 144, 216, 288].map(a => `<ellipse cx="0" cy="-5" rx="3.4" ry="5" fill="#FF8FC4" transform="rotate(${a})"/>`).join("")}<circle r="3" fill="#FFE14D"/></g>`;
      case "stars": return `${star(20, 18, 2.6, "#FFF6C9")}${star(82, 14, 2.2, "#FFF6C9")}${star(88, 30, 1.6, "#FFF6C9")}`;
      case "headphones": return `<path d="M20 40 Q20 6 50 6 Q80 6 80 40" stroke="#5EE7FF" stroke-width="4" fill="none"/><rect x="14" y="36" width="10" height="16" rx="4" fill="#FF5CA8"/><rect x="76" y="36" width="10" height="16" rx="4" fill="#FF5CA8"/>`;
      case "mist": return `<path d="M8 92 q10 -8 20 0 q10 -8 20 0 q10 -8 20 0 q10 -8 20 0" stroke="#E2B6FF" stroke-width="3" fill="none" opacity=".55"/>`;
      case "chef": return `<path d="M34 20 Q30 6 42 8 Q46 0 54 4 Q64 2 66 10 Q74 12 66 22 Z" fill="#FFFFFF"/><rect x="36" y="18" width="28" height="6" rx="2" fill="#F0E6FF"/>`;
      case "headband": return `<path d="M22 30 Q50 22 78 30 L78 36 Q50 28 22 36 Z" fill="#FF3B5C"/><path d="M78 32 l12 -4 l-4 8 Z M78 34 l10 6 l-10 0 Z" fill="#FF3B5C"/><circle cx="50" cy="29" r="3" fill="#FFF"/>`;
      case "visor": return `<rect x="24" y="36" width="52" height="12" rx="6" fill="#0E0B1E" stroke="#5EE7FF" stroke-width="2"/><rect x="30" y="40" width="40" height="4" rx="2" fill="#5EE7FF" opacity=".85"/>`;
      case "comet": return "";
      case "tophat": return `<rect x="36" y="2" width="28" height="20" rx="2" fill="#17141F"/><rect x="30" y="20" width="40" height="5" rx="2" fill="#17141F"/><rect x="36" y="16" width="28" height="4" fill="#B388FF"/><circle cx="62" cy="44" r="7" fill="none" stroke="#FFC94D" stroke-width="2"/><path d="M69 44 q6 8 2 20" stroke="#FFC94D" stroke-width="1.2" fill="none"/>`;
      case "helmet": return `<circle cx="50" cy="42" r="38" fill="#9FE8FF" opacity=".18" stroke="#DFF8FF" stroke-width="3"/><path d="M28 24 Q36 12 50 10" stroke="#fff" stroke-width="3" fill="none" opacity=".8" stroke-linecap="round"/><rect x="40" y="76" width="20" height="6" rx="3" fill="#C9C2E0"/>`;
      case "halo": return `<ellipse cx="50" cy="6" rx="18" ry="4.5" fill="none" stroke="#FFF27A" stroke-width="3"/>`;
      case "orbit": return `<ellipse cx="50" cy="76" rx="46" ry="9" fill="none" stroke="#FFD34D" stroke-width="1.4" opacity=".75" transform="rotate(-10 50 76)"/><circle cx="93" cy="70" r="3.2" fill="#FFD34D"/><circle cx="8" cy="84" r="2" fill="#FFD34D"/>`;
      case "rings": return `<circle cx="50" cy="56" r="44" fill="none" stroke="#5EE7FF" stroke-width="1.5" opacity=".5"/><circle cx="50" cy="56" r="36" fill="none" stroke="#B388FF" stroke-width="1.5" opacity=".6"/>`;
      case "hood":   // худи с прорезями для ушей: лицо в тени, видны только глаза
        return `<path fill-rule="evenodd" d="M12 50 Q10 8 50 6 Q90 8 88 50 Q88 74 50 76 Q12 74 12 50 Z M24 46 Q26 26 50 26 Q74 26 76 46 Q74 66 50 68 Q26 66 24 46 Z" fill="#14131C" stroke="#39FF88" stroke-width="1.2" stroke-opacity=".5"/>
          <path d="M24 46 Q26 26 50 26 Q74 26 76 46 Q74 66 50 68 Q26 66 24 46 Z" fill="#05050A" opacity=".82"/>
          <g class="cat-led"><ellipse cx="39" cy="45" rx="5.5" ry="3.2" fill="#39FF88"/><ellipse cx="61" cy="45" rx="5.5" ry="3.2" fill="#39FF88"/></g>
          <ellipse cx="39" cy="45" rx="11" ry="7" fill="#39FF88" opacity=".18"/><ellipse cx="61" cy="45" rx="11" ry="7" fill="#39FF88" opacity=".18"/>
          <path d="M42 74 v10 M58 74 v10" stroke="#39FF88" stroke-width="1.6" stroke-linecap="round" opacity=".8"/>
          <g font-family="monospace" font-size="8" font-weight="700" fill="#39FF88" class="cat-z"><text x="86" y="10">1</text><text x="94" y="0">0</text><text x="4" y="4">x</text></g>`;
      case "shades":   // авиаторы с неоновым бликом + белый шарф пилота
        return `<path d="M24 40 Q24 36 30 36 H46 Q49 36 49 40 Q48 52 37 52 Q25 51 24 40 Z M51 40 Q51 36 54 36 H70 Q76 36 76 40 Q75 51 63 52 Q52 52 51 40 Z" fill="#0B0A18"/>
          <path d="M46 39 h8" stroke="#0B0A18" stroke-width="2.4"/><path d="M28 41 l7 -3 M55 41 l7 -3" stroke="#FF5CA8" stroke-width="2" stroke-linecap="round" opacity=".9"/><path d="M30 46 l10 -4" stroke="#5EE7FF" stroke-width="1.4" stroke-linecap="round" opacity=".7"/>
          <path d="M30 24 q8 -12 20 -8 q-4 2 -4 6 q8 -8 18 -2" fill="none" stroke="${c.dark}" stroke-width="3" stroke-linecap="round"/>`;
      default: return "";
    }
  }
  function accSide(c) {
    switch (c.acc) {
      case "bow": return `<path d="M80 50 l-8 -5 v10 Z M80 50 l8 -5 v10 Z" fill="#FF5CA8"/>`;
      case "nightcap": return `<path d="M82 18 Q94 -4 112 14 Q100 8 92 12 Z" fill="#4A5CC8"/><path d="M82 18 Q98 10 113 16" stroke="#F0E9FF" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M84 16 Q70 10 70 24" stroke="#4A5CC8" stroke-width="4" fill="none"/><circle cx="70" cy="26" r="4" fill="#F0E9FF"/><g class="cat-z"><text x="114" y="4" font-size="10" font-weight="800" fill="#B9C8FF" font-family="sans-serif">z</text></g>`;
      case "ledcollar": return `<path d="M78 42 Q88 52 100 46" stroke="#21E6FF" stroke-width="3.5" fill="none" stroke-linecap="round"/><rect x="85" y="48" width="8" height="6" rx="2" fill="#0B0A18" stroke="#21E6FF" stroke-width="1"/><circle cx="89" cy="51" r="1.4" fill="#FF2E88" class="cat-led"/>`;
      case "grandpa": return `<path d="M96 20 q6 -4 12 0" stroke="#F4F4F8" stroke-width="3.5" fill="none" stroke-linecap="round"/><circle cx="103" cy="30" r="7" fill="#9FD8FF" fill-opacity=".18" stroke="#3A3550" stroke-width="1.8"/><path d="M96 29 l-10 -3" stroke="#3A3550" stroke-width="1.8"/><path d="M106 40 q4 3 9 -1" stroke="#F4F4F8" stroke-width="3.5" fill="none" stroke-linecap="round"/>`;
      case "tie": return `<path d="M84 44 L94 48 L104 44" stroke="#F4F1FA" stroke-width="3" fill="none"/><path d="M94 48 l-3 3 l1.5 12 l1.5 2 l1.5 -2 l1.5 -12 Z" fill="#E21B3C"/>`;
      case "scarf": return `<path d="M74 44 Q84 54 96 46 L98 52 Q84 62 74 50 Z" fill="#5EC8FF"/><path d="M78 52 l-6 14 l6 2 l4 -14 Z" fill="#3FA6E0"/>`;
      case "bell": return `<path d="M76 46 Q86 54 98 48" stroke="#FF5CA8" stroke-width="3.5" fill="none"/><circle cx="88" cy="56" r="4.4" fill="#FFC94D"/>`;
      case "flower": return `<g transform="translate(84 10)">${[0, 72, 144, 216, 288].map(a => `<ellipse cx="0" cy="-4" rx="2.8" ry="4" fill="#FF8FC4" transform="rotate(${a})"/>`).join("")}<circle r="2.4" fill="#FFE14D"/></g>`;
      case "stars": return `${star(76, 8, 2.2, "#FFF6C9")}${star(112, 14, 1.8, "#FFF6C9")}`;
      case "headphones": return `<path d="M80 22 Q90 2 104 18" stroke="#5EE7FF" stroke-width="3.5" fill="none"/><rect x="84" y="24" width="9" height="13" rx="4" fill="#FF5CA8"/>`;
      case "mist": return `<path d="M14 82 q8 -6 16 0 q8 -6 16 0 q8 -6 16 0 q8 -6 16 0" stroke="#E2B6FF" stroke-width="3" fill="none" opacity=".55"/>`;
      case "chef": return `<path d="M82 14 Q78 2 88 4 Q92 -2 98 2 Q106 2 106 10 Z" fill="#FFFFFF"/><rect x="82" y="11" width="24" height="5" rx="2" fill="#F0E6FF"/>`;
      case "headband": return `<path d="M78 20 Q94 12 110 20 L110 25 Q94 18 78 26 Z" fill="#FF3B5C"/><path d="M78 22 l-10 -4 l2 8 Z M78 24 l-8 6 l8 0 Z" fill="#FF3B5C"/>`;
      case "visor": return `<rect x="94" y="24" width="18" height="9" rx="4" fill="#0E0B1E" stroke="#5EE7FF" stroke-width="1.8"/><rect x="98" y="27" width="12" height="3" rx="1.5" fill="#5EE7FF"/>`;
      case "comet": return "";
      case "tophat": return `<rect x="84" y="-4" width="20" height="16" rx="2" fill="#17141F"/><rect x="80" y="10" width="28" height="4" rx="2" fill="#17141F"/><rect x="84" y="7" width="20" height="3" fill="#B388FF"/>`;
      case "helmet": return `<circle cx="96" cy="32" r="24" fill="#9FE8FF" opacity=".18" stroke="#DFF8FF" stroke-width="2.5"/><path d="M84 16 Q90 10 98 9" stroke="#fff" stroke-width="2.5" fill="none" opacity=".8"/>`;
      case "halo": return `<ellipse cx="96" cy="2" rx="13" ry="3.4" fill="none" stroke="#FFF27A" stroke-width="2.6"/>`;
      case "orbit": return `<ellipse cx="62" cy="46" rx="56" ry="9" fill="none" stroke="#FFD34D" stroke-width="1.4" opacity=".8" transform="rotate(-8 62 46)"/><circle cx="114" cy="40" r="3" fill="#FFD34D"/>`;
      case "rings": return `<ellipse cx="60" cy="48" rx="54" ry="34" fill="none" stroke="#5EE7FF" stroke-width="1.4" opacity=".5"/>`;
      case "hood": return `<path d="M76 30 Q76 4 98 6 Q118 8 118 32 Q118 52 98 52 L80 52 Z" fill="#14131C" stroke="#39FF88" stroke-width="1" stroke-opacity=".5"/>
          <path d="M94 22 Q112 22 114 34 Q112 46 96 46 Q90 34 94 22 Z" fill="#05050A" opacity=".85"/><ellipse cx="104" cy="31" rx="4.4" ry="2.6" fill="#39FF88" class="cat-led"/><ellipse cx="104" cy="31" rx="8" ry="5" fill="#39FF88" opacity=".2"/>`;
      case "shades": return `<path d="M96 26 H112 Q113 36 104 37 Q96 37 96 26 Z" fill="#0B0A18"/><path d="M99 29 l6 -2" stroke="#FF5CA8" stroke-width="1.8" stroke-linecap="round"/><path d="M96 27 l-12 -2" stroke="#0B0A18" stroke-width="2"/>
          <path d="M78 44 Q88 52 100 46 L102 50 Q88 58 78 50 Z" fill="#F4F1FA"/><path d="M80 48 q-14 -2 -26 4 q12 2 24 0 Z" fill="#F4F1FA" class="cat-scarf"/>`;
      default: return "";
    }
  }

  // ---------- хвост ----------
  function tailFront(c) {
    if (c.acc === "comet") return `<path d="M70 82 Q100 70 92 40 Q90 30 98 22" stroke="${c.fur}" stroke-width="9" fill="none" stroke-linecap="round"/>
      <path d="M98 22 q2 -12 -6 -18 q10 2 12 10 q4 -8 2 -14 q8 8 2 22 Z" fill="#FFF27A"/>`;
    if (c.pattern === "fluffy") return `<path d="M70 82 Q100 74 90 44" stroke="${c.fur}" stroke-width="14" fill="none" stroke-linecap="round"/><path d="M70 82 Q100 74 90 44" stroke="${c.dark}" stroke-width="2" fill="none" stroke-dasharray="3 6"/>`;
    if (c.acc === "mist") return `<path d="M70 82 Q100 74 92 46 Q88 34 96 28" stroke="${c.fur}" stroke-width="9" fill="none" stroke-linecap="round" opacity=".75"/>`;
    const tip = ["tabby", "tiger"].includes(c.pattern) ? `<path d="M92 50 Q90 42 94 36" stroke="${c.dark}" stroke-width="9" fill="none" stroke-linecap="round"/>` : "";
    return `<path d="M70 82 Q100 74 92 46 Q90 38 94 34" stroke="${c.fur}" stroke-width="8" fill="none" stroke-linecap="round"/>${tip}`;
  }
  function tailSide(c) {
    if (c.acc === "comet") return `<path d="M30 46 Q10 40 12 20" stroke="${c.fur}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M12 20 q-8 -10 -2 -18 q2 8 8 8 q-2 -8 4 -12 q2 12 -4 22 Z" fill="#FFF27A"/>`;
    const w = c.pattern === "fluffy" ? 13 : 7;
    return `<path class="cat-tail" d="M30 46 Q8 42 12 18" stroke="${c.fur}" stroke-width="${w}" fill="none" stroke-linecap="round"/>`;
  }

  // ---------- позы ----------
  // кибер-детали по редкости: 1+ светящиеся глаза, 2+ светодиоды на ушах, 3+ имплант на щеке
  function cyberFront(c, r) {
    let h = "";
    if (r >= 2) h += `<circle cx="19" cy="7" r="2.6" fill="${c.eye}" class="cat-led"/><circle cx="81" cy="7" r="2.6" fill="${c.eye}" class="cat-led" style="animation-delay:.7s"/><circle cx="19" cy="7" r="6" fill="${c.eye}" opacity=".25"/><circle cx="81" cy="7" r="6" fill="${c.eye}" opacity=".25"/>`;
    if (r >= 3) h += `<path d="M24 50 h6 l3 4 h5" stroke="#21E6FF" stroke-width="1.6" fill="none" stroke-linecap="round"/><circle cx="24" cy="50" r="1.8" fill="#21E6FF"/><rect x="72" y="26" width="7" height="5" rx="1.5" fill="#0B0A18" stroke="#21E6FF" stroke-width="1"/>`;
    return h;
  }
  function cyberSide(c, r) {
    let h = "";
    if (r >= 2) h += `<circle cx="84" cy="3" r="2.2" fill="${c.eye}" class="cat-led"/><circle cx="110" cy="1" r="2.2" fill="${c.eye}" class="cat-led" style="animation-delay:.7s"/>`;
    if (r >= 3) h += `<path d="M90 38 h5 l3 3 h4" stroke="#21E6FF" stroke-width="1.4" fill="none" stroke-linecap="round"/><circle cx="90" cy="38" r="1.5" fill="#21E6FF"/>`;
    return h;
  }
  function eyesFront(c, r) {
    if (c.acc === "visor" || c.acc === "shades" || c.acc === "hood") return "";
    if (c.kind === "sleepy") return `<path d="M32 45 q6 5 12 0 M56 45 q6 5 12 0" stroke="#140F2A" stroke-width="2.4" fill="none" stroke-linecap="round"/>`;
    const glowE = r >= 1 ? `<ellipse cx="38" cy="44" rx="10" ry="11" fill="${c.eye}" opacity=".22"/><ellipse cx="62" cy="44" rx="10" ry="11" fill="${c.eye}" opacity=".22"/>` : "";
    return `${glowE}<g class="cat-eyes"><ellipse cx="38" cy="44" rx="6" ry="7" fill="${c.eye}"/><ellipse cx="62" cy="44" rx="6" ry="7" fill="${c.eye}"/>
      <ellipse cx="38" cy="45" rx="2.6" ry="5" fill="#140F2A"/><ellipse cx="62" cy="45" rx="2.6" ry="5" fill="#140F2A"/>
      <circle cx="40" cy="41" r="1.8" fill="#fff"/><circle cx="64" cy="41" r="1.8" fill="#fff"/></g>`;
  }

  function sit(c, id) {
    const r = rarityOf(id), glow = GLOW[r];
    const k = "c" + (uid++);
    const loaf = c.kind === "loaf", box = c.kind === "box", long = c.kind === "long";
    const headY = loaf ? 14 : box ? 4 : long ? -10 : 0;          // голова ниже у батона, выше у длинного
    const bodyRy = long ? 32 : 22, bodyCy = long ? 64 : 74;
    const body = loaf
      ? `<path d="M10 98 Q6 62 50 60 Q94 62 90 98 Z" fill="${c.fur}"/><path d="M14 74 Q50 56 86 74 Q50 64 14 74 Z" fill="${c.dark}" opacity=".55"/><path d="M28 70 l6 -4 M46 66 l6 -3 M64 67 l6 -2" stroke="#FFE7C2" stroke-width="2" stroke-linecap="round" opacity=".7"/>`
      : `<ellipse cx="50" cy="${bodyCy}" rx="27" ry="${bodyRy}" fill="${c.fur}"${rim(c)}/>
         <g clip-path="url(#${k}b)"><ellipse cx="50" cy="${bodyCy + 6}" rx="14" ry="${bodyRy - 6}" fill="${c.belly}"/>${patternFront(c)}</g>
         <ellipse cx="38" cy="94" rx="8" ry="5" fill="${c.belly}"/><ellipse cx="62" cy="94" rx="8" ry="5" fill="${c.belly}"/>`;
    const boxFront = box ? `<path d="M10 64 L4 52 L30 58 Z M90 64 L96 52 L70 58 Z" fill="#B88A58"/><rect x="10" y="62" width="80" height="36" rx="2" fill="#C89B6A"/><rect x="10" y="62" width="80" height="6" fill="#A87A4A"/>
       <rect x="44" y="62" width="12" height="36" fill="#E2C49A" opacity=".55"/><text x="27" y="88" font-size="8" font-weight="800" fill="#7A5236" font-family="sans-serif">MEOW</text><path d="M66 80 l6 -6 l6 6 M72 74 v12" stroke="#7A5236" stroke-width="1.6" fill="none"/>` : "";
    const tail = loaf ? `<path d="M84 96 Q98 96 94 84" stroke="${c.fur}" stroke-width="8" fill="none" stroke-linecap="round"/>` : box ? "" : tailFront(c);
    return `<svg viewBox="-6 -8 112 112" aria-hidden="true" style="overflow:visible">
      <defs>${glow ? glowDef(k, glow) : ""}<clipPath id="${k}b"><ellipse cx="50" cy="${bodyCy}" rx="27" ry="${bodyRy}"/></clipPath><clipPath id="${k}h"><path d="M20 44 Q20 18 50 18 Q80 18 80 44 Q80 68 50 68 Q20 68 20 44 Z"/></clipPath></defs>
      ${glow ? `<ellipse cx="50" cy="58" rx="58" ry="54" fill="url(#${k}g)"/>` : ""}
      <ellipse cx="50" cy="97" rx="${loaf ? 42 : 30}" ry="5" fill="#000" opacity=".25"/>
      ${tail}${body}
      <g transform="translate(0 ${headY})">
        <path d="M22 34 L18 6 L42 22 Z" fill="${c.fur}"${rim(c)} stroke-linejoin="round"/><path d="M78 34 L82 6 L58 22 Z" fill="${c.fur}"${rim(c)} stroke-linejoin="round"/>
        <path d="M25 28 L23 12 L36 22 Z" fill="#FF8FC4" opacity=".75"/><path d="M75 28 L77 12 L64 22 Z" fill="#FF8FC4" opacity=".75"/>
        <path d="M20 44 Q20 18 50 18 Q80 18 80 44 Q80 68 50 68 Q20 68 20 44 Z" fill="${c.fur}"${rim(c)}/>
        <g clip-path="url(#${k}h)">${patternFront(c)}<ellipse cx="50" cy="58" rx="15" ry="10" fill="${c.belly}"/></g>
        ${eyesFront(c, r)}
        <path d="M47 53 h6 l-3 3 Z" fill="#FF8FC4"/>${c.kind === "sleepy" ? `<ellipse cx="50" cy="60" rx="3" ry="2" fill="#140F2A" opacity=".7"/>` : `<path d="M44 58 q3 3 6 0 q3 3 6 0" stroke="#140F2A" stroke-width="1.6" fill="none" stroke-linecap="round"/>`}
        <ellipse cx="30" cy="54" rx="5" ry="3" fill="#FF8FC4" opacity=".35"/><ellipse cx="70" cy="54" rx="5" ry="3" fill="#FF8FC4" opacity=".35"/>
        <path d="M22 52 l-12 -2 M22 56 l-12 2 M78 52 l12 -2 M78 56 l12 2" stroke="${c.pattern === "neon" ? "#5EE7FF" : "#fff"}" stroke-width="1" opacity=".55"/>
        ${cyberFront(c, r)}
        ${["ledcollar", "tie", "bell", "bow", "scarf"].includes(c.acc) ? "" : accFront(c)}
      </g>
      ${["ledcollar", "tie", "bell", "bow", "scarf"].includes(c.acc) ? `<g transform="translate(0 ${long ? -6 : 0})">${accFront(c)}</g>` : ""}
      ${c.acc === "shades" ? accFront({ acc: "pilotscarf" }) : ""}
      ${boxFront}
    </svg>`;
  }
  function walk(c, id) {
    const r = rarityOf(id), glow = GLOW[r];
    const k = "c" + (uid++);
    const long = c.kind === "long", stretch = long ? 18 : 0;     // сосиска: тело длиннее, голова дальше
    const leg = (x, cls, col) => `<rect class="${cls}" x="${x}" y="58" width="7" height="22" rx="3.5" fill="${col}"${rim(c)} style="transform-origin:${x + 3.5}px 60px"/>`;
    const eye = ["visor", "shades", "hood"].includes(c.acc) ? "" : c.kind === "sleepy"
      ? `<path d="M98 31 q4 3 8 0" stroke="#140F2A" stroke-width="2" fill="none" stroke-linecap="round"/>`
      : `${r >= 1 ? `<ellipse cx="102" cy="30" rx="7.5" ry="8.5" fill="${c.eye}" opacity=".22"/>` : ""}<g class="cat-eyes"><ellipse cx="102" cy="30" rx="4.4" ry="5.4" fill="${c.eye}"/><ellipse cx="103.4" cy="30.6" rx="2" ry="4" fill="#140F2A"/><circle cx="104" cy="28" r="1.4" fill="#fff"/></g>`;
    const boxBack = c.kind === "box" ? `<g transform="translate(36 14)"><rect x="0" y="0" width="34" height="22" rx="2" fill="#C89B6A"/><rect x="0" y="0" width="34" height="4" fill="#A87A4A"/><rect x="14" y="0" width="6" height="22" fill="#E2C49A" opacity=".55"/></g>` : "";
    return `<svg viewBox="${long ? -10 : 0} -6 ${124 + stretch} 96" aria-hidden="true" style="overflow:visible">
      <defs>${glow ? glowDef(k, glow) : ""}<clipPath id="${k}b"><ellipse cx="${56 + stretch / 2}" cy="48" rx="${30 + stretch / 2}" ry="17"/></clipPath><clipPath id="${k}h"><ellipse cx="96" cy="32" rx="19" ry="17"/></clipPath></defs>
      ${glow ? `<ellipse cx="62" cy="44" rx="66" ry="46" fill="url(#${k}g)"/>` : ""}
      <ellipse cx="${60 + stretch / 2}" cy="84" rx="${40 + stretch / 2}" ry="4" fill="#000" opacity=".22"/>
      ${tailSide(c)}
      ${leg(34, "leg-b", c.dark)}${leg(70 + stretch, "leg-b", c.dark)}
      <ellipse cx="${56 + stretch / 2}" cy="48" rx="${30 + stretch / 2}" ry="17" fill="${c.fur}"${rim(c)}/>
      <g clip-path="url(#${k}b)"><ellipse cx="${60 + stretch / 2}" cy="62" rx="${24 + stretch / 2}" ry="8" fill="${c.belly}"/>${patternSide(c)}</g>
      ${leg(42, "leg-a", c.fur)}${leg(78 + stretch, "leg-a", c.fur)}
      ${boxBack}
      <g transform="translate(${stretch} 0)">
        <path d="M84 22 L84 2 L98 16 Z" fill="${c.fur}"${rim(c)} stroke-linejoin="round"/><path d="M100 16 L110 0 L112 20 Z" fill="${c.fur}"${rim(c)} stroke-linejoin="round"/>
        <path d="M87 18 L87 8 L94 15 Z" fill="#FF8FC4" opacity=".75"/>
        <ellipse cx="96" cy="32" rx="19" ry="17" fill="${c.fur}"${rim(c)}/>
        <g clip-path="url(#${k}h)">${patternSide(c)}<ellipse cx="106" cy="40" rx="10" ry="7" fill="${c.belly}"/></g>
        ${eye}
        <path d="M113 35 l2.6 2 l-3 1.4 Z" fill="#FF8FC4"/><path d="M110 41 q2 2 4 0" stroke="#140F2A" stroke-width="1.3" fill="none"/>
        <ellipse cx="98" cy="40" rx="3.6" ry="2.2" fill="#FF8FC4" opacity=".35"/>
        ${cyberSide(c, r)}${accSide(c)}
      </g>
    </svg>`;
  }
  const rarityOf = (id) => Math.floor(id / 4);

  // Анимация: ноги переставляются, хвост покачивается, глаза моргают. Подключается один раз.
  const CSS = `.cat-art .leg-a{animation:catleg .32s ease-in-out infinite alternate}.cat-art .leg-b{animation:catleg .32s ease-in-out infinite alternate-reverse}
    @keyframes catleg{from{transform:rotate(18deg)}to{transform:rotate(-18deg)}}
    .cat-art .cat-tail{animation:cattail 1.6s ease-in-out infinite alternate;transform-origin:30px 46px}
    @keyframes cattail{from{transform:rotate(-6deg)}to{transform:rotate(8deg)}}
    .cat-art .cat-eyes{animation:catblink 4.2s infinite;transform-origin:50% 45%;transform-box:fill-box}
    @keyframes catblink{0%,94%,100%{transform:scaleY(1)}96%{transform:scaleY(.1)}}
    .cat-art.still .leg-a,.cat-art.still .leg-b{animation:none}
    .cat-art .cat-led{animation:catled 1.6s ease-in-out infinite alternate}@keyframes catled{from{opacity:.4}to{opacity:1}}
    .cat-art .cat-scarf{animation:catscarf 1.2s ease-in-out infinite alternate;transform-origin:70px 66px;transform-box:view-box}@keyframes catscarf{from{transform:rotate(-4deg)}to{transform:rotate(6deg)}}
    .cat-art.art.hop img{animation:cathop .42s ease-in-out infinite alternate;transform-origin:50% 100%}
    .cat-art.art.hop img[style*="scaleX(-1)"]{animation-name:cathopf}
    @keyframes cathop{from{translate:0 0;scale:1 1}to{translate:0 -6%;scale:1.03 .97}}
    @keyframes cathopf{from{translate:0 0;scale:1 1}to{translate:0 -6%;scale:1.03 .97}}
    .cat-art .cat-z{animation:catz 2.4s ease-out infinite}@keyframes catz{0%{transform:translate(0,4px);opacity:0}40%{opacity:1}100%{transform:translate(6px,-8px);opacity:0}}`;
  function injectCss() {
    if (typeof document === "undefined" || document.getElementById("catArtCss")) return;
    const st = document.createElement("style"); st.id = "catArtCss"; st.textContent = CSS; document.head.appendChild(st);
  }

  // Нарисованные от руки коты: PNG без фона в папке cats/. Пока картинки нет — рисуется векторный кот.
  //   sit  — сидит (комната, коллекция, коробки); walk — идёт (если нет — тот же рисунок, кот «скачет»)
  //   faces — куда смотрит на рисунке ("left" / "right"), чтобы при ходьбе разворачивать правильно
  const ART = {
    // 9: { sit: "cats/9_sit.png", ratio: 489 / 512, faces: "left" },   // Неон — включим, когда Полина нарисует всех
  };
  function artImg(catId, pose, size, opts) {
    const a = ART[catId], src = (pose === "walk" && a.walk) || a.sit;
    const flip = pose === "walk" && !a.walk && a.faces === "left";   // по умолчанию идёт вправо
    const h = Math.round(size * a.ratio);
    return `<span class="cat-art art ${pose === "walk" && !a.walk ? "hop" : ""} ${opts.still ? "still" : ""}" style="display:inline-block;width:${size}px;height:${h}px;line-height:0">
      <img src="${src}" alt="" draggable="false" style="width:100%;height:100%;object-fit:contain;${flip ? "transform:scaleX(-1);" : ""}${opts.dark ? "filter:brightness(0) opacity(.55);" : ""}"></span>`;
  }

  function svg(catId, pose, size, opts = {}) {
    injectCss();
    if (ART[catId]) return artImg(catId, pose, size, opts);
    const c = CATS[catId] || CATS[0];
    const inner = pose === "walk" ? walk(c, catId) : sit(c, catId);
    const h = pose === "walk" ? size * 0.78 : size;
    return `<span class="cat-art ${opts.still ? "still" : ""}" style="display:inline-block;width:${size}px;height:${h}px;line-height:0">${inner.replace("<svg ", `<svg width="${size}" height="${h}" `)}</span>`;
  }
  // Силуэт для закрытых котов в коллекции
  function silhouette(catId, size, color = "#2C2352") {
    if (ART[catId]) return artImg(catId, "sit", size, { dark: true, still: true });
    return svg(catId, "sit", size).replace(/fill="#[0-9A-Fa-f]{3,6}"/g, `fill="${color}"`).replace(/stroke="#[0-9A-Fa-f]{3,6}"/g, `stroke="${color}"`)
      .replace(/stop-opacity="[.0-9]+"/g, 'stop-opacity="0"').replace("cat-eyes", "");
  }

  root.CatArt = { svg, silhouette, CATS, ART };
  if (typeof module !== "undefined") module.exports = root.CatArt;
})(typeof window !== "undefined" ? window : globalThis);
