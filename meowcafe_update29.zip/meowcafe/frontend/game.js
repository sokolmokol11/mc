// Десертопад: генератор партии по seed. ДОЛЖЕН совпадать с backend/game_logic.py
// (тест backend/tests/test_game.py сверяет оба на одних и тех же seed).
(function (root) {
  const DURATION_MS = 30000, SPAWN_BASE_MS = 450, SPEEDUP = 1.3;
  const ITEM_TYPES = [["cup", 1, 32], ["donut", 1, 24], ["cake", 2, 16], ["gold", 5, 6], ["rock", 0, 22]];
  const HIT_X = 10, HIT_Y = 7, ROCK_PENALTY = 0.25;

  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function schedule(seed) {
    const rnd = mulberry32(seed);
    const totalW = ITEM_TYPES.reduce((s, it) => s + it[2], 0);
    const items = [];
    let t = 0;
    while (true) {
      t += SPAWN_BASE_MS / (1 + t / DURATION_MS * SPEEDUP);
      if (t >= DURATION_MS) break;
      let r = rnd() * totalW, kind = ITEM_TYPES[ITEM_TYPES.length - 1];
      for (const it of ITEM_TYPES) { if (r < it[2]) { kind = it; break; } r -= it[2]; }
      const x = 10 + rnd() * 80;
      const v = (20 + rnd() * 14) * (1 + t / DURATION_MS * SPEEDUP);
      items.push({ t0: t, kind: kind[0], pts: kind[1], x, v });
    }
    return items;
  }

  const yAt = (item, t) => -8 + item.v * (t - item.t0) / 1000;

  // Тот же подсчёт попадания, что на сервере — для мгновенного отклика. Итог всё равно считает сервер.
  function hitTest(items, caught, t, x, y) {
    let best = -1, bestD = Infinity;
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (caught.has(i) || it.t0 > t) continue;
      const iy = yAt(it, t);
      if (iy < -8 || iy > 108) continue;
      const dx = Math.abs(x - it.x), dy = Math.abs(y - iy);
      if (dx <= HIT_X && dy <= HIT_Y && dx + dy < bestD) { best = i; bestD = dx + dy; }
    }
    return best;
  }

  root.Dessert = { DURATION_MS, ROCK_PENALTY, mulberry32, schedule, yAt, hitTest };
  if (typeof module !== "undefined") module.exports = root.Dessert;
})(typeof window !== "undefined" ? window : globalThis);
