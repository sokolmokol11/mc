// MeowCafe: пролог — иллюстрированная заставка при первом входе.
// Ночной город → башня «Арго» → гроза → кончился бензин → старое кафе и Коробкин → объявления → MEOW CAFE.
// Вся графика и звук рисуются кодом. Сцены 360×640, растягиваются под экран.
(() => {
  const LW = 360, LH = 640;
  let cv = null, ctx = null;
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const ease = t => { t = clamp(t); return t * t * (3 - 2 * t); };
  const easeOut = t => { t = clamp(t); return 1 - Math.pow(1 - t, 3); };
  const easeIn = t => { t = clamp(t); return t * t * t; };
  function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  const INK = "#140A16", SFXF = "'Russo One', 'Rubik', Impact, sans-serif";

  // ---------- режим рисования: «vec» — иллюстрация, «comic» — плоский цвет и чернильный контур ----------
  let MODE = "vec";
  const pick = (v, f) => MODE === "comic" ? f : v;
  const comic = () => MODE === "comic";
  function lg(c, x0, y0, x1, y1, stops) { const g = c.createLinearGradient(x0, y0, x1, y1); stops.forEach(([o, col]) => g.addColorStop(o, col)); return g; }
  function rg(c, x, y, r0, r1, stops) { const g = c.createRadialGradient(x, y, r0, x, y, r1); stops.forEach(([o, col]) => g.addColorStop(o, col)); return g; }
  function ink(c, w = 2.6) { if (comic()) { c.lineWidth = w; c.strokeStyle = INK; c.lineJoin = "round"; c.stroke(); } }
  function F(c, path, vecStyle, comicColor, inkW = 2.6) { path(c); c.fillStyle = pick(vecStyle, comicColor); c.fill(); if (inkW) ink(c, inkW); }
  function halftone(c, x0, y0, w, h, col, step = 5, r = 1.2) { c.fillStyle = col; for (let y = y0; y < y0 + h; y += step) for (let x = x0 + ((y / step) % 2) * step / 2; x < x0 + w; x += step) { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); } }
  function glowDot(c, x, y, r, col, a = 1) { if (comic()) return; c.fillStyle = rg(c, x, y, 0, r, [[0, col.replace(")", `,${a})`).replace("rgb", "rgba")], [1, col.replace(")", ",0)").replace("rgb", "rgba")]]); c.fillRect(x - r, y - r, r * 2, r * 2); }
  const flashAt = (t, times) => times.reduce((m, s) => Math.max(m, t >= s && t < s + .12 ? 1 : t >= s + .12 && t < s + .5 ? .35 * (1 - (t - s - .12) / .38) : 0), 0);

  // ---------- город: слои домов (для проезда и фона) ----------
  function makeLayer(seed, period, minW, maxW, minH, maxH, winP) {
    const r = rng(seed), items = []; let x = 0;
    while (x < period) { const w = lerp(minW, maxW, r()), h = lerp(minH, maxH, r()); const wins = []; for (let y = 10; y < h - 8; y += 10) for (let wx = 5; wx < w - 6; wx += 9) if (r() < winP) wins.push([wx, y, r() * 3 | 0, r() < .1]); items.push({ x, w, h, wins, ant: r() < .3 }); x += w + 2 + r() * 6; }
    return { items, period: x };
  }
  const L1 = makeLayer(3, 720, 30, 70, 200, 360, .18), L2 = makeLayer(11, 720, 34, 80, 120, 260, .3), L3 = makeLayer(29, 720, 40, 90, 70, 170, .42);
  const WINC = ["#FFC94D", "#21E6FF", "#FF8FC4"];
  function cityLayer(c, L, off, base, col, comicCol, t, winA = 1) {
    const o = ((off % L.period) + L.period) % L.period;
    for (let k = -1; k <= 1; k++) for (const b of L.items) {
      const x = b.x - o + k * L.period; if (x > LW + 10 || x + b.w < -10) continue;
      c.beginPath(); c.rect(x, base - b.h, b.w, b.h); c.fillStyle = pick(col, comicCol); c.fill(); ink(c, 1.6);
      if (b.ant) { c.fillStyle = pick(col, comicCol); c.fillRect(x + b.w / 2 - 1, base - b.h - 16, 2, 16); if (Math.sin(t * 3 + b.x) > .4) { c.fillStyle = "#FF2A3D"; c.fillRect(x + b.w / 2 - 1.5, base - b.h - 18, 3, 3); } }
      c.globalAlpha = winA;
      for (const [wx, wy, ci, fl] of b.wins) { if (fl && Math.sin(t * 6 + wx) > .3) continue; c.fillStyle = WINC[ci]; c.fillRect(x + wx, base - b.h + wy, 4, 5); }
      c.globalAlpha = 1;
    }
  }

  // ---------- дождь (в координатах кадра 360×640) ----------
  const DROPS = Array.from({ length: 240 }, () => ({ x: Math.random() * 480, y: Math.random() * LH, v: 520 + Math.random() * 260, l: 9 + Math.random() * 10 }));
  function stepRain(dt) { for (const d of DROPS) { d.y += d.v * dt; d.x -= d.v * dt * .18; if (d.y > LH) { d.y = -20; d.x = Math.random() * 480; } } }
  function rain(c, amount, col = "#C8D0FF", a = .32) {
    if (amount <= 0) return;
    c.strokeStyle = pick(col, "#FFFFFF"); c.lineWidth = pick(1.1, 1.5); c.globalAlpha = pick(a, .45); c.beginPath();
    const n = Math.round(DROPS.length * amount);
    for (let i = 0; i < n; i++) { const d = DROPS[i]; c.moveTo(d.x, d.y); c.lineTo(d.x + d.l * .18, d.y - d.l); }
    c.stroke(); c.globalAlpha = 1;
  }

  // ---------- машина (вид сбоку) ----------
  const ROADB = 594;
  function carPath(c, x, b) { c.beginPath(); c.moveTo(x + 6, b - 22); c.lineTo(x + 6, b - 46); c.quadraticCurveTo(x + 8, b - 58, x + 26, b - 60); c.lineTo(x + 58, b - 62); c.lineTo(x + 80, b - 90); c.quadraticCurveTo(x + 84, b - 94, x + 92, b - 94); c.lineTo(x + 130, b - 94); c.quadraticCurveTo(x + 136, b - 94, x + 140, b - 90); c.lineTo(x + 158, b - 64); c.lineTo(x + 176, b - 60); c.quadraticCurveTo(x + 186, b - 57, x + 186, b - 46); c.lineTo(x + 186, b - 22); c.closePath(); }
  function car(c, o) {
    const x = o.x, b = o.b || ROADB;
    if (o.lights > .05) {
      c.save(); c.globalAlpha = pick(.3, .4) * o.lights;
      c.fillStyle = pick(lg(c, x + 186, 0, x + 400, 0, [[0, "#FFF2C8"], [1, "rgba(255,242,200,0)"]]), "#FFF4C8");
      c.beginPath(); c.moveTo(x + 184, b - 50); c.lineTo(x + 410, b - 84); c.lineTo(x + 410, b + 6); c.lineTo(x + 184, b - 42); c.fill(); c.restore();
    }
    if (!comic()) { c.fillStyle = "rgba(0,0,0,.4)"; c.beginPath(); c.ellipse(x + 96, b + 2, 98, 6, 0, 0, 7); c.fill(); }
    carPath(c, x, b); c.fillStyle = pick(lg(c, 0, b - 94, 0, b - 20, [[0, "#5BE0D2"], [.45, "#2BB8AA"], [1, "#16756E"]]), "#2ED1C0"); c.fill(); ink(c);
    c.fillStyle = pick("rgba(255,255,255,.35)", "#9FF5EA"); c.fillRect(x + 12, b - 54, 166, pick(2, 3));
    const win = (pts) => { c.beginPath(); c.moveTo(pts[0], pts[1]); for (let i = 2; i < pts.length; i += 2) c.lineTo(pts[i], pts[i + 1]); c.closePath(); };
    for (const pts of [[x + 66, b - 64, x + 84, b - 88, x + 106, b - 88, x + 106, b - 64], [x + 112, b - 88, x + 130, b - 88, x + 150, b - 64, x + 112, b - 64]]) {
      win(pts); c.fillStyle = pick(lg(c, x, b - 90, x + 40, b - 60, [[0, "#3A5272"], [1, "#141C2E"]]), "#3A5272"); c.fill(); ink(c);
    }
    if (o.door < .4 && !o.empty) {   // водитель
      const hx = x + 126, hy = b - 74;
      c.fillStyle = "#F2C9A6"; c.beginPath(); c.arc(hx, hy, 7, 0, 7); c.fill();
      c.fillStyle = "#3B3F7A"; c.beginPath(); c.arc(hx, hy - 2, 8.5, Math.PI * .95, Math.PI * 2.05); c.fill();
      c.fillStyle = INK;
      if (o.look === "cam") { c.fillRect(hx - 3, hy - 1, 2, 2); c.fillRect(hx + 2, hy - 1, 2, 2); }
      else if (o.look === "up") { c.fillRect(hx + 4, hy - 4, 2, 2); }
      else if (o.look === "back") { c.fillRect(hx - 5, hy - 1, 2, 2); }
      else c.fillRect(hx + 5, hy - 1, 2, 2);
    }
    c.strokeStyle = pick("rgba(0,0,0,.35)", INK); c.lineWidth = pick(1.4, 2); c.beginPath(); c.moveTo(x + 108, b - 64); c.lineTo(x + 108, b - 24); c.moveTo(x + 156, b - 62); c.lineTo(x + 156, b - 24); c.stroke();
    if (o.door > 0) {
      c.fillStyle = "#0B0A14"; c.fillRect(x + 108, b - 64, 48, 40);
      c.save(); c.translate(x + 156, b - 44); c.scale(1 - o.door * .55, 1); c.translate(-(x + 156), -(b - 44));
      c.beginPath(); c.moveTo(x + 108, b - 64); c.lineTo(x + 156, b - 62); c.lineTo(x + 156, b - 22); c.lineTo(x + 108, b - 24); c.closePath(); c.fillStyle = pick("#2BB8AA", "#2ED1C0"); c.fill(); ink(c); c.restore();
    }
    c.fillStyle = "#FFF2C8"; c.beginPath(); c.ellipse(x + 182, b - 46, 4, 6, 0, 0, 7); c.fill();
    if (!comic() && o.lights > .1) { c.fillStyle = rg(c, x + 182, b - 46, 1, 30, [[0, `rgba(255,240,200,${.8 * o.lights})`], [1, "rgba(255,240,200,0)"]]); c.fillRect(x + 150, b - 80, 64, 64); }
    c.fillStyle = "#FF3348"; c.fillRect(x + 6, b - 50, 5, 10);
    for (const wx of [x + 48, x + 148]) {
      c.beginPath(); c.arc(wx, b - 20, 19, 0, 7); c.fillStyle = "#0E0C16"; c.fill(); ink(c);
      c.beginPath(); c.arc(wx, b - 20, 10, 0, 7); c.fillStyle = pick("#C9CFE0", "#E8ECF6"); c.fill(); ink(c);
      c.strokeStyle = pick("#7A8094", INK); c.lineWidth = 2;
      for (let k = 0; k < 5; k++) { const a = o.wheel + k * 1.2566; c.beginPath(); c.moveTo(wx, b - 20); c.lineTo(wx + Math.cos(a) * 9, b - 20 + Math.sin(a) * 9); c.stroke(); }
    }
    if (comic() && o.speedLines) { c.strokeStyle = INK; c.lineWidth = 2; for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(x - 14 - i * 6, b - 76 + i * 16); c.lineTo(x - 70 - i * 12, b - 76 + i * 16); c.stroke(); } }
  }

  // ---------- герой: худи с капюшоном и неоновой полосой (вид сбоку, идёт вправо) ----------
  function hero(c, x, b, s = 1, walk = 0, dir = 1) {
    c.save(); c.translate(x, b); c.scale(s * dir, s);
    const sw = Math.sin(walk) * .45;
    const leg = (a, col) => { c.save(); c.translate(0, -38); c.rotate(a); c.beginPath(); c.roundRect(-5, 0, 10, 36, 4); c.fillStyle = col; c.fill(); ink(c, 2); c.beginPath(); c.roundRect(-5, 30, 15, 8, 3); c.fillStyle = "#0B0A14"; c.fill(); ink(c, 2); c.restore(); };
    leg(-sw, pick("#1A1830", "#2A2650")); leg(sw, pick("#24223F", "#3A3670"));
    c.save(); c.translate(0, -70); c.rotate(sw * .6); c.beginPath(); c.roundRect(-4, 0, 9, 30, 4); c.fillStyle = pick("#232650", "#3B3F7A"); c.fill(); ink(c, 2); c.restore();
    c.beginPath(); c.roundRect(-14, -78, 28, 44, 9); c.fillStyle = pick(lg(c, -14, 0, 14, 0, [[0, "#3B3F7A"], [1, "#262A55"]]), "#3B3F7A"); c.fill(); ink(c);
    c.fillStyle = "#21E6FF"; c.fillRect(-14, -54, 28, 3);
    c.save(); c.translate(0, -70); c.rotate(-sw * .6); c.beginPath(); c.roundRect(-4, 0, 9, 30, 4); c.fillStyle = pick("#2E3266", "#4A4F94"); c.fill(); ink(c, 2); c.beginPath(); c.arc(1, 31, 4.5, 0, 7); c.fillStyle = "#F2C9A6"; c.fill(); c.restore();
    c.beginPath(); c.arc(2, -90, 12, 0, 7); c.fillStyle = "#F2C9A6"; c.fill(); ink(c, 2);
    c.beginPath(); c.moveTo(-12, -82); c.quadraticCurveTo(-16, -106, 2, -106); c.quadraticCurveTo(16, -106, 15, -94); c.lineTo(6, -96); c.quadraticCurveTo(-4, -94, -6, -80); c.closePath(); c.fillStyle = pick("#2E3266", "#4A4F94"); c.fill(); ink(c, 2);
    c.fillStyle = INK; c.fillRect(8, -92, 2.5, 2.5);
    c.restore();
  }

  // ---------- Коробкин в коробке с табличкой ----------
  function kitty(c, cx, by, o = {}) {   // cx — центр, by — низ коробки
    const s = o.s || 1; c.save(); c.translate(cx, by); c.scale(s, s); c.translate(-205, -472);
    c.beginPath(); c.rect(227, 372, 3, 54); c.fillStyle = pick("#8A5A33", "#A8703F"); c.fill(); ink(c, 2);
    c.lineWidth = 7; c.lineCap = "round"; c.strokeStyle = pick("#8C95A8", "#A9B3C6"); c.beginPath(); c.moveTo(222, 442); c.quadraticCurveTo(246, 432, 238, 412); c.stroke();
    if (comic()) { c.lineWidth = 2; c.strokeStyle = INK; c.stroke(); }
    c.beginPath(); c.ellipse(205, 440, 19, 22, 0, 0, 7); c.fillStyle = pick(lg(c, 186, 0, 224, 0, [[0, "#A9B2C4"], [1, "#7E8799"]]), "#A9B3C6"); c.fill(); ink(c);
    c.fillStyle = pick("#E8EAF2", "#FFFFFF"); c.beginPath(); c.ellipse(205, 444, 9, 13, 0, 0, 7); c.fill();
    c.beginPath(); c.ellipse(205, 412, 17, 15, 0, 0, 7); c.moveTo(190, 406); c.lineTo(188, 388); c.lineTo(200, 399); c.moveTo(220, 406); c.lineTo(222, 388); c.lineTo(210, 399);
    c.fillStyle = pick(lg(c, 188, 0, 222, 0, [[0, "#B0B9CB"], [1, "#8A93A6"]]), "#A9B3C6"); c.fill(); ink(c);
    c.fillStyle = "#FF9EC4"; c.beginPath(); c.moveTo(191, 403); c.lineTo(190, 393); c.lineTo(197, 400); c.fill(); c.beginPath(); c.moveTo(219, 403); c.lineTo(220, 393); c.lineTo(213, 400); c.fill();
    c.strokeStyle = pick("#5E6578", INK); c.lineWidth = 2;
    for (const dx of [-5, 0, 5]) { c.beginPath(); c.moveTo(205 + dx, 398); c.lineTo(205 + dx * 1.2, 404); c.stroke(); }
    if (o.blink) { c.beginPath(); c.moveTo(194, 412); c.lineTo(201, 412); c.moveTo(209, 412); c.lineTo(216, 412); c.lineWidth = 2; c.strokeStyle = "#2A2236"; c.stroke(); }
    else for (const ex of [197.5, 212.5]) { c.fillStyle = "#FFD23F"; c.beginPath(); c.ellipse(ex, 411, 4.6, 5.2, 0, 0, 7); c.fill(); c.fillStyle = "#140F2A"; c.beginPath(); c.ellipse(ex + (o.look || 0), 411, 1.6, 4, 0, 0, 7); c.fill(); c.fillStyle = "#fff"; c.fillRect(ex + 1, 408, 1.6, 1.6); }
    c.fillStyle = "#FF8FC4"; c.beginPath(); c.moveTo(202, 417); c.lineTo(208, 417); c.lineTo(205, 420); c.fill();
    c.strokeStyle = pick("rgba(255,255,255,.6)", INK); c.lineWidth = 1;
    for (const sg of [-1, 1]) for (const k of [-1, 1]) { c.beginPath(); c.moveTo(205 + sg * 6, 419 + k); c.lineTo(205 + sg * 22, 417 + k * 3); c.stroke(); }
    c.beginPath(); c.rect(178, 444, 54, 28); c.fillStyle = pick(lg(c, 178, 0, 232, 0, [[0, "#D7AC78"], [1, "#B38556"]]), "#E0A868"); c.fill(); ink(c);
    c.fillStyle = pick("#9C6B3E", "#A8703F"); c.fillRect(202, 444, 6, 28);
    c.beginPath(); c.moveTo(178, 444); c.lineTo(166, 434); c.lineTo(190, 436); c.lineTo(196, 444); c.moveTo(232, 444); c.lineTo(246, 433); c.lineTo(222, 436); c.lineTo(214, 444);
    c.lineWidth = pick(3, 2.6); c.strokeStyle = pick("#C99A64", INK); c.stroke();
    c.save(); c.translate(206, 373); c.rotate(-.04); c.translate(-206, -373);
    c.beginPath(); c.rect(158, 360, 96, 26); c.fillStyle = pick("#F4EDE4", "#FFFFFF"); c.fill(); ink(c);
    if (!comic()) { c.fillStyle = "rgba(120,100,90,.25)"; c.fillRect(158, 383, 96, 3); }
    c.font = "800 15px Rubik, sans-serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillStyle = "#3A1A30"; c.fillText("ПОМОГИТЕ", 206, 374);
    c.restore();
    if (comic()) { c.save(); c.beginPath(); c.ellipse(205, 440, 19, 22, 0, 0, 7); c.clip(); halftone(c, 214, 420, 20, 44, "rgba(20,10,22,.4)"); c.restore(); }
    c.restore();
  }
  function heartP(c, x, y, s, a, col = "#FF5CA8") { if (a <= 0) return; c.globalAlpha = a; c.beginPath(); c.moveTo(x, y + 6 * s); c.bezierCurveTo(x - 12 * s, y - 2 * s, x - 6 * s, y - 12 * s, x, y - 5 * s); c.bezierCurveTo(x + 6 * s, y - 12 * s, x + 12 * s, y - 2 * s, x, y + 6 * s); c.fillStyle = col; c.fill(); ink(c, 2); c.globalAlpha = 1; }

  // ---------- общие куски улицы ----------
  function nightSky(c, storm, flash) {
    c.fillStyle = storm ? pick(lg(c, 0, 0, 0, 480, [[0, "#05040F"], [.6, "#17122C"], [1, "#2A1A3A"]]), "#1E1A3A") : pick(lg(c, 0, 0, 0, 480, [[0, "#0B0A26"], [.6, "#2A1748"], [1, "#4A2350"]]), "#2B2160");
    c.fillRect(-400, -1200, 1200, 1680);
    if (flash) { c.fillStyle = `rgba(210,210,255,${flash * .55})`; c.fillRect(-400, -1200, 1200, 1680); }
  }
  function moon(c) {
    if (comic()) { c.beginPath(); c.arc(80, 90, 22, 0, 7); c.fillStyle = "#FFF1C8"; c.fill(); ink(c); return; }
    c.fillStyle = rg(c, 80, 90, 4, 90, [[0, "rgba(255,240,220,.6)"], [.25, "rgba(200,170,255,.18)"], [1, "rgba(0,0,0,0)"]]); c.fillRect(-10, 0, 180, 180);
  }
  function street(c, off, wet, lamps = true) {
    c.beginPath(); c.rect(-400, 472, 1200, 22); c.fillStyle = pick(lg(c, 0, 472, 0, 494, [[0, "#3E3350"], [1, "#2C2440"]]), "#5A4A80"); c.fill();
    c.fillStyle = pick("#5A4A70", INK); c.fillRect(-400, 492, 1200, 3);
    c.beginPath(); c.rect(-400, 494, 1200, 400); c.fillStyle = pick(lg(c, 0, 494, 0, LH, [[0, "#1D1830"], [1, "#100D1C"]]), "#2A2448"); c.fill();
    const o = ((off % 60) + 60) % 60;
    for (let x = -o - 60; x < LW + 60; x += 60) { c.fillStyle = pick("rgba(200,190,240,.35)", "#FFF4E0"); c.fillRect(x, 548, 30, 3); }
    if (lamps) {
      const p = 230, lo = ((off * 1.0 % p) + p) % p;
      for (let x = -lo - 30; x < LW + 60; x += p) {
        c.beginPath(); c.rect(x, 330, 6, 142); c.fillStyle = pick("#2E2840", "#3A3266"); c.fill(); ink(c, 2);
        c.beginPath(); c.moveTo(x - 8, 330); c.lineTo(x + 14, 330); c.lineTo(x + 8, 318); c.lineTo(x - 2, 318); c.closePath(); c.fillStyle = pick("#2E2840", "#3A3266"); c.fill(); ink(c, 2);
        if (!comic()) { c.fillStyle = rg(c, x + 3, 334, 2, 110, [[0, "rgba(255,230,170,.8)"], [.12, "rgba(255,210,130,.28)"], [1, "rgba(255,200,120,0)"]]); c.fillRect(x - 120, 220, 240, 260); }
        else { c.globalAlpha = .3; c.fillStyle = "#FFF1C8"; c.beginPath(); c.moveTo(x - 4, 331); c.lineTo(x + 10, 331); c.lineTo(x + 54, 472); c.lineTo(x - 48, 472); c.fill(); c.globalAlpha = 1; }
        if (wet && !comic()) { c.globalAlpha = .22 * wet; c.fillStyle = lg(c, 0, 500, 0, 600, [[0, "#FFE6A8"], [1, "rgba(255,230,168,0)"]]); c.fillRect(x - 2, 498, 10, 90); c.globalAlpha = 1; }
      }
    }
  }

  // ======================= СЦЕНЫ (кадры 360×640) =======================
  // 1. Проезд по ночному городу; водитель оглядывается
  function shotDrive(c, t, o = {}) {
    const storm = !!o.storm, off = (o.t0 || 0) + t * 90, fl = storm ? flashAt(t, o.flashes || []) : 0;
    nightSky(c, storm, fl);
    if (!storm) moon(c);
    else {
      for (let i = 0; i < 7; i++) { const x = ((i * 70 - t * 10) % 520 + 520) % 520 - 90; c.beginPath(); c.ellipse(x, 60 + (i % 3) * 30, 90, 26, 0, 0, 7); c.ellipse(x + 40, 44 + (i % 3) * 30, 60, 24, 0, 0, 7); c.fillStyle = fl > .3 ? "#5A5288" : pick("#120E24", "#2A2450"); c.fill(); ink(c, 2); }
      if (fl > .3 && o.bolt) { c.strokeStyle = "#F2EEFF"; c.lineWidth = 3; c.shadowColor = "#BFA8FF"; c.shadowBlur = pick(18, 0); c.beginPath(); o.bolt.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y)); c.stroke(); c.shadowBlur = 0; }
    }
    cityLayer(c, L1, off * .15, 472, storm ? "#120E26" : "#1A1232", storm ? "#28224A" : "#2A2058", t, .6);
    cityLayer(c, L2, off * .32, 472, storm ? "#18122E" : "#24183F", storm ? "#342A60" : "#3C2E70", t, .8);
    if (!comic()) { c.fillStyle = lg(c, 0, 360, 0, 472, [[0, "rgba(60,30,80,0)"], [1, storm ? "rgba(50,40,90,.6)" : "rgba(90,50,110,.55)"]]); c.fillRect(0, 360, LW, 112); }
    cityLayer(c, L3, off * .55, 472, storm ? "#1E1838" : "#2C1E4C", storm ? "#40347A" : "#4A3A88", t, 1);
    street(c, off, storm ? 1 : .3);
    const look = o.look ? o.look(t) : "fwd";
    car(c, { x: 84, b: ROADB + (Math.sin(t * 11) > .8 ? -1 : 0), wheel: off / 19, lights: 1, door: 0, look, speedLines: true });
  }
  // 2. Башня корпорации «Арго»: камера поднимается вверх
  function shotTower(c, t, o = {}) {
    const pan = o.pan != null ? o.pan : ease((t - 1.0) / 3.4), cy = pan * 880;
    c.fillStyle = pick(lg(c, 0, 0, 0, LH, [[0, "#06041A"], [1, "#1E0D2E"]]), "#1A1238"); c.fillRect(0, 0, LW, LH);
    if (!comic()) { c.fillStyle = "#CFC6F0"; for (let i = 0; i < 50; i++) { const x = (i * 73) % LW, y = (i * 131) % 380; if (Math.sin(t * 2 + i) > -.4) c.fillRect(x, y, 1.4, 1.4); } }
    c.save(); c.translate(0, cy);
    cityLayer(c, L1, 120, 472, "#140E2A", "#2A2058", t, .5); cityLayer(c, L2, 300, 472, "#1C1436", "#3C2E70", t, .6);
    const x0 = 70, w = 220, top = -800;
    // прожекторы
    for (const sgn of [-1, 1]) { const a = -Math.PI / 2 + Math.sin(t * .9 * sgn + 1) * .55; c.globalAlpha = pick(.13, .22); c.fillStyle = pick("#FF6A78", "#FF8A96"); c.beginPath(); c.moveTo(180, top - 150); c.lineTo(180 + Math.cos(a - .1) * 900, top - 150 + Math.sin(a - .1) * 900); c.lineTo(180 + Math.cos(a + .1) * 900, top - 150 + Math.sin(a + .1) * 900); c.fill(); c.globalAlpha = 1; }
    // корпус: стекло, рёбра, красные огни
    const body = cc => { cc.beginPath(); cc.moveTo(x0, 472); cc.lineTo(x0, top + 260); cc.lineTo(x0 + 30, top + 200); cc.lineTo(x0 + 30, top); cc.lineTo(x0 + w - 30, top); cc.lineTo(x0 + w - 30, top + 200); cc.lineTo(x0 + w, top + 260); cc.lineTo(x0 + w, 472); cc.closePath(); };
    body(c); c.fillStyle = pick(lg(c, x0, 0, x0 + w, 0, [[0, "#1C1430"], [.45, "#0C0A1C"], [1, "#05040C"]]), "#1A1430"); c.fill(); ink(c, 3);
    c.save(); body(c); c.clip();
    for (let x = x0 + 14; x < x0 + w; x += 18) { c.fillStyle = pick("rgba(120,100,180,.12)", "rgba(80,70,140,.6)"); c.fillRect(x, top, 1.5, 472 - top); }
    for (let y = top + 20; y < 460; y += 16) for (let x = x0 + 18; x < x0 + w - 12; x += 18) { const on = ((x * 7 + y * 3) % 13) < 3; if (on) { c.fillStyle = Math.sin(t * 2 + x + y) > .85 ? "#FF8A96" : "#FF2A3D"; c.fillRect(x + 3, y, 8, 5); } }
    c.restore();
    for (const sx of [x0 + 40, x0 + w - 42]) { c.fillStyle = "#FF2A3D"; c.fillRect(sx, top + 210, 3, 262 - top - 210 + 0); if (!comic()) { c.globalAlpha = .25; c.fillRect(sx - 4, top + 210, 11, 262 - top - 210); c.globalAlpha = 1; } }
    // шпиль и глаз-логотип
    c.beginPath(); c.moveTo(170, top); c.lineTo(180, top - 160); c.lineTo(190, top); c.closePath(); c.fillStyle = pick("#0C0A1C", "#1A1430"); c.fill(); ink(c, 2);
    if (Math.sin(t * 4) > 0) { c.fillStyle = "#FF2A3D"; c.beginPath(); c.arc(180, top - 162, 4, 0, 7); c.fill(); }
    const ey = top + 110;
    if (!comic()) { c.fillStyle = rg(c, 180, ey, 4, 120, [[0, "rgba(255,42,61,.55)"], [1, "rgba(255,42,61,0)"]]); c.fillRect(60, ey - 120, 240, 240); }
    c.beginPath(); c.ellipse(180, ey, 66, 32, 0, 0, 7); c.fillStyle = "#FF2A3D"; c.fill(); ink(c, 3);
    c.beginPath(); c.ellipse(180, ey, 56, 24, 0, 0, 7); c.fillStyle = "#0B0816"; c.fill();
    const lk = Math.sin(t * .8) * 22;
    c.beginPath(); c.arc(180 + lk, ey, 16, 0, 7); c.fillStyle = "#FF2A3D"; c.fill(); c.beginPath(); c.arc(180 + lk, ey, 6, 0, 7); c.fillStyle = "#0B0816"; c.fill(); c.fillStyle = "#FFE0E4"; c.fillRect(184 + lk, ey - 8, 4, 4);
    c.font = "900 34px Rubik, sans-serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillStyle = "#FF2A3D";
    if (!comic()) { c.shadowColor = "#FF2A3D"; c.shadowBlur = 16; } c.fillText("А Р Г О", 180, ey + 64); c.shadowBlur = 0;
    if (comic()) { c.lineWidth = 1.5; c.strokeStyle = INK; c.strokeText("А Р Г О", 180, ey + 64); }
    street(c, 0, 0, false);
    const cx = lerp(-230, 420, clamp(t / 2.8));
    car(c, { x: cx, wheel: cx / 19, lights: 1, door: 0, look: "up", speedLines: true });
    c.restore();
    if (!comic()) { c.globalAlpha = .28 * pan; c.fillStyle = "#3A0010"; c.fillRect(0, 0, LW, LH); c.globalAlpha = 1; }
  }
  // 3. Салон: дорога за лобовым стеклом, датчик бензина падает до E, мотор глохнет
  function shotFuel(c, t, o = {}) {
    const st = 2.0, dur = 2.3, ph = t < st ? t : t < st + dur ? st + (t - st) - (t - st) ** 2 / (2 * dur) : st + dur / 2;
    const dead = t > 4.5, dimA = dead ? (t < 4.8 && Math.sin(t * 60) > 0 ? .4 : .85) : 0;
    const head = dead ? clamp(1 - (t - 4.5) / .3) : 1;
    // за стеклом: ночная улица уходит к горизонту
    const H0 = 236;
    c.fillStyle = pick(lg(c, 0, 0, 0, H0, [[0, "#05040F"], [1, "#2A1A3A"]]), "#1E1A3A"); c.fillRect(0, 0, LW, 400);
    for (let i = 0; i < 26; i++) { const x = i * 15 - 10, h = 18 + (i * 37) % 46; c.beginPath(); c.rect(x, H0 - h, 14, h); c.fillStyle = pick("#140E2A", "#2A2058"); c.fill(); ink(c, 1.2); for (let y = H0 - h + 4; y < H0 - 3; y += 6) if ((i * 7 + y) % 3 === 0) { c.fillStyle = WINC[(i + y) % 3]; c.fillRect(x + 4, y, 3, 3); } }
    c.beginPath(); c.moveTo(180, H0); c.lineTo(-160, 400); c.lineTo(520, 400); c.closePath(); c.fillStyle = pick(lg(c, 0, H0, 0, 400, [[0, "#1D1830"], [1, "#0E0B18"]]), "#2A2448"); c.fill(); ink(c, 2);
    c.fillStyle = pick("#2C2440", "#5A4A80"); c.beginPath(); c.moveTo(180, H0); c.lineTo(-160, 400); c.lineTo(-400, 400); c.lineTo(-400, H0); c.closePath(); c.fill(); c.beginPath(); c.moveTo(180, H0); c.lineTo(520, 400); c.lineTo(800, 400); c.lineTo(800, H0); c.closePath(); c.fill();
    const zy = z => H0 + 150 / z, zx = (z, side) => 180 + side * 340 / z;
    // разметка
    for (let k = 0; k < 14; k++) { let z = 12 - ((ph * 3 + k) % 14); if (z < .9) continue; const z2 = z + .45; c.fillStyle = pick("rgba(230,225,255,.7)", "#FFF4E0"); c.beginPath(); c.moveTo(180 - 6 / z, zy(z)); c.lineTo(180 + 6 / z, zy(z)); c.lineTo(180 + 6 / z2, zy(z2)); c.lineTo(180 - 6 / z2, zy(z2)); c.fill(); }
    // фонари вдоль дороги
    const lamps = [];
    for (let k = 0; k < 6; k++) { const z = 9 - ((ph * 1.6 + k * 1.5) % 9); if (z > .7) lamps.push(z); }
    lamps.sort((a, b) => b - a).forEach(z => { for (const side of [-1, 1]) { const x = zx(z, side), y = zy(z), h = 240 / z; c.fillStyle = pick("#2E2840", "#3A3266"); c.fillRect(x - 2.5 / z * 3, y - h, 5 / z * 3, h); c.fillStyle = "#FFE6A8"; c.fillRect(x - 10 / z * 3 * (side > 0 ? 1 : 0), y - h, 10 / z * 3, 3 / z * 3); if (!comic()) { c.fillStyle = rg(c, x, y - h, 1, 60 / z * 3, [[0, "rgba(255,220,150,.5)"], [1, "rgba(255,220,150,0)"]]); c.fillRect(x - 60 / z * 3, y - h - 60 / z * 3, 120 / z * 3, 120 / z * 3); } } });
    // свет фар на дороге
    if (head > 0) { c.globalAlpha = pick(.3, .35) * head; c.fillStyle = pick(rg(c, 180, 360, 10, 170, [[0, "#FFF2C8"], [1, "rgba(255,242,200,0)"]]), "#FFF4C8"); c.beginPath(); c.ellipse(180, 350, 170, 52, 0, 0, 7); c.fill(); c.globalAlpha = 1; }
    // капли на стекле и дворник
    c.fillStyle = pick("rgba(190,205,255,.5)", "rgba(255,255,255,.7)");
    for (let i = 0; i < 40; i++) { const x = (i * 97) % LW, y = ((i * 53 + t * (14 + i % 7 * 6)) % 380); c.beginPath(); c.ellipse(x, y, 1.6, 2.6, 0, 0, 7); c.fill(); if (i % 3 === 0) c.fillRect(x - .5, y - 12, 1, 12); }
    const wa = Math.sin(t * 3.4) * 1.05 - .1;
    for (const px of [110, 262]) { c.save(); c.translate(px, 396); c.rotate(wa); c.fillStyle = "#0B0A14"; c.fillRect(-3, -290, 6, 290); c.restore(); }
    // рама стекла
    c.fillStyle = pick("#0B0814", "#1A1236"); c.beginPath(); c.moveTo(0, 0); c.lineTo(44, 0); c.lineTo(0, 400); c.closePath(); c.fill(); c.beginPath(); c.moveTo(LW, 0); c.lineTo(LW - 44, 0); c.lineTo(LW, 400); c.closePath(); c.fill(); c.fillRect(0, 0, LW, 14);
    // приборная панель
    c.beginPath(); c.moveTo(0, 400); c.quadraticCurveTo(180, 372, LW, 400); c.lineTo(LW, LH); c.lineTo(0, LH); c.closePath(); c.fillStyle = pick(lg(c, 0, 380, 0, LH, [[0, "#241C38"], [1, "#0B0814"]]), "#3A3060"); c.fill(); ink(c, 3);
    function gauge(cx, cy, val, isFuel) {
      c.beginPath(); c.arc(cx, cy, 64, 0, 7); c.fillStyle = pick("#2A2440", "#4A4080"); c.fill(); ink(c, 3);
      c.beginPath(); c.arc(cx, cy, 56, 0, 7); c.fillStyle = pick(rg(c, cx, cy, 4, 56, [[0, "#152038"], [1, "#0A0E1C"]]), "#F4EDE4"); c.fill(); ink(c, 2);
      if (isFuel) { c.beginPath(); c.arc(cx, cy, 46, Math.PI * .75, Math.PI * .95); c.strokeStyle = "#E0283C"; c.lineWidth = 7; c.stroke(); }
      c.strokeStyle = pick("#9FE8FF", INK); c.lineWidth = 2;
      for (let i = 0; i <= 8; i++) { const a = Math.PI * .75 + i * Math.PI * 1.5 / 8; c.beginPath(); c.moveTo(cx + Math.cos(a) * 50, cy + Math.sin(a) * 50); c.lineTo(cx + Math.cos(a) * (i % 2 ? 44 : 40), cy + Math.sin(a) * (i % 2 ? 44 : 40)); c.stroke(); }
      c.font = "900 15px Rubik, sans-serif"; c.textAlign = "center"; c.textBaseline = "middle";
      if (isFuel) { c.fillStyle = "#FF3A4E"; c.fillText("E", cx - 30, cy + 26); c.fillStyle = pick("#9FE8FF", INK); c.fillText("F", cx + 30, cy + 26); c.font = "800 9px Rubik"; c.fillText("БЕНЗИН", cx, cy + 40); }
      else { c.fillStyle = pick("#9FE8FF", INK); c.font = "800 10px Rubik"; c.fillText("0", cx - 30, cy + 28); c.fillText("120", cx + 28, cy + 28); c.fillText("км/ч", cx, cy + 40); }
      const a = Math.PI * .75 + val * Math.PI * 1.5;
      c.strokeStyle = isFuel ? "#FFB040" : "#FF5CA8"; c.lineWidth = 4; c.lineCap = "round"; c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(a) * 42, cy + Math.sin(a) * 42); c.stroke(); c.lineCap = "butt";
      c.beginPath(); c.arc(cx, cy, 6, 0, 7); c.fillStyle = pick("#9FE8FF", INK); c.fill();
    }
    const speed = t < st ? .55 : lerp(.55, 0, clamp((t - st) / (dur + .3)));
    gauge(96, 500, speed, false);
    gauge(264, 500, lerp(.1, 0, clamp(t / 1.6)), true);
    const blink = t > 1.2 && t < 4.6 && Math.floor(t * 2.6) % 2 === 0;
    c.save(); c.translate(180, 446);
    c.beginPath(); c.roundRect(-26, -16, 52, 32, 7); c.fillStyle = blink ? "#FF2A3D" : pick("#3A1520", "#7A2A3A"); c.fill(); ink(c, 2);
    if (blink && !comic()) { c.fillStyle = rg(c, 0, 0, 2, 60, [[0, "rgba(255,42,61,.55)"], [1, "rgba(255,42,61,0)"]]); c.fillRect(-60, -60, 120, 120); }
    c.fillStyle = "#fff"; c.fillRect(-12, -9, 13, 18); c.fillRect(1, -6, 7, 3); c.fillRect(6, -6, 3, 12); c.fillStyle = blink ? "#FF2A3D" : "#3A1520"; c.fillRect(-9, -6, 7, 5);
    c.restore();
    // руль
    c.beginPath(); c.arc(180, 820, 240, Math.PI * 1.22, Math.PI * 1.78); c.strokeStyle = pick("#14101F", "#2A2448"); c.lineWidth = 30; c.stroke();
    if (comic()) { c.lineWidth = 34; c.strokeStyle = INK; c.globalCompositeOperation = "destination-over"; c.stroke(); c.globalCompositeOperation = "source-over"; }
    if (dimA) { c.fillStyle = `rgba(0,0,0,${dimA})`; c.fillRect(0, 380, LW, 260); }
  }
  // 4. Старое кафе: машина глохнет, герой выходит, Коробкин с табличкой
  function cafe(c, t, s) {   // фон с домом (без машины)
    c.beginPath(); c.moveTo(102, 238); c.lineTo(230, 158); c.lineTo(358, 238); c.closePath(); c.fillStyle = pick(lg(c, 0, 158, 0, 238, [[0, "#3A2034"], [1, "#24121F"]]), "#5A2A44"); c.fill(); ink(c);
    c.beginPath(); c.rect(292, 170, 24, 52); c.fillStyle = pick("#4A2A2A", "#7A3A30"); c.fill(); ink(c);
    const wall = cc => { cc.beginPath(); cc.rect(118, 232, 224, 240); };
    wall(c); c.fillStyle = pick(lg(c, 118, 0, 342, 0, [[0, "#9A5442"], [1, "#6C3529"]]), "#B5583E"); c.fill(); ink(c);
    c.save(); wall(c); c.clip();
    if (!comic()) { c.strokeStyle = "rgba(40,10,10,.28)"; c.lineWidth = 1; for (let y = 236; y < 472; y += 9) { c.beginPath(); c.moveTo(118, y); c.lineTo(342, y); c.stroke(); for (let x = 118 + ((y / 9) % 2) * 11; x < 342; x += 22) { c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + 9); c.stroke(); } } }
    else halftone(c, 262, 232, 82, 240, "rgba(20,10,22,.35)");
    c.restore();
    c.beginPath(); c.rect(150, 252, 42, 44); c.fillStyle = pick("#1C1630", "#2A2050"); c.fill(); ink(c);
    c.beginPath(); c.rect(268, 252, 42, 44); c.fillStyle = pick(lg(c, 0, 252, 0, 296, [[0, "#FFD98C"], [1, "#F59A4A"]]), "#FFC94D"); c.fill(); ink(c);
    c.fillStyle = pick("#6C3529", INK); c.fillRect(287, 252, 4, 44); c.fillRect(268, 272, 42, 3);
    c.beginPath(); c.rect(134, 348, 98, 96); c.fillStyle = pick(lg(c, 0, 348, 0, 444, [[0, "#FFD98C"], [1, "#EE8A3C"]]), "#FFB547"); c.fill(); ink(c);
    c.fillStyle = pick("rgba(120,50,20,.55)", "#B5602A"); c.fillRect(140, 414, 86, 30); c.fillRect(148, 396, 4, 18); c.fillRect(150, 392, 16, 5); c.fillRect(196, 396, 4, 18); c.fillRect(198, 392, 16, 5);
    for (const lx of [160, 205]) { c.fillRect(lx, 348, 1.5, 18); c.beginPath(); c.arc(lx + 1, 370, 6, Math.PI, 0); c.fill(); }
    c.strokeStyle = pick("#EADCC8", INK); c.lineWidth = pick(4, 3); c.strokeRect(134, 348, 98, 96); c.beginPath(); c.moveTo(183, 348); c.lineTo(183, 444); c.stroke();
    c.beginPath(); c.rect(262, 352, 54, 120); c.fillStyle = pick(lg(c, 262, 0, 316, 0, [[0, "#6A3B26"], [1, "#4A2618"]]), "#7A4228"); c.fill(); ink(c);
    c.fillStyle = pick("#FFC277", "#FFC94D"); c.fillRect(272, 364, 34, 40); c.fillStyle = pick("rgba(90,40,20,.5)", "#B5602A"); c.fillRect(272, 384, 34, 3);
    c.fillStyle = "#FFD86B"; c.beginPath(); c.arc(306, 418, 3, 0, 7); c.fill();
    const aw = cc => { cc.beginPath(); cc.moveTo(124, 318); cc.lineTo(336, 318); cc.lineTo(342, 342); for (let i = 7; i >= 0; i--) { const x = 124 + i * 31; cc.quadraticCurveTo(x + 15, 352, x, 342); } cc.closePath(); };
    c.save(); aw(c); c.clip(); for (let i = 0; i < 14; i++) { c.fillStyle = i % 2 ? pick("#F1E4D3", "#FFF4E0") : pick("#B83F78", "#FF5CA8"); c.fillRect(124 + i * 16, 316, 16, 40); } c.restore(); aw(c); ink(c);
    c.beginPath(); c.rect(168, 280, 126, 30); c.fillStyle = "#2A1622"; c.fill(); ink(c);
    c.font = "900 22px Rubik, sans-serif"; c.textAlign = "center"; c.textBaseline = "middle";
    ["C", "A", "F", "E"].forEach((ch, i) => { const off = i === 1 && Math.sin(t * 17) > .75; c.fillStyle = off ? "#5A3020" : "#FFC277"; if (!comic() && !off) { c.shadowColor = "#FF9A3C"; c.shadowBlur = 10; } c.fillText(ch, 196 + i * 23, 296); c.shadowBlur = 0; });
    if (!comic()) {
      c.fillStyle = rg(c, 183, 470, 10, 140, [[0, "rgba(255,180,90,.42)"], [1, "rgba(255,180,90,0)"]]); c.fillRect(40, 440, 300, 100);
      c.globalAlpha = .26; c.fillStyle = lg(c, 0, 500, 0, 620, [[0, "#FFB547"], [1, "rgba(255,181,71,0)"]]); for (let i = 0; i < 6; i++) c.fillRect(138 + i * 16, 502, 9, 110); c.globalAlpha = 1;
    }
  }
  function shotArrive(c, t, o = {}) {
    const fl = flashAt(t, [.4]);
    const arrive = easeOut(t / 2.6), carX = lerp(-300, -70, arrive);
    const zoom = o.noCam ? 0 : ease((t - 5.5) / 1.4), FX = 222, FY = 418, k = 1 + .95 * zoom;
    nightSky(c, true, fl);
    c.save(); c.translate(lerp(0, LW / 2 - FX * k, zoom), lerp(0, LH * .5 - FY * k, zoom)); c.scale(k, k);
    cityLayer(c, L1, 200, 472, "#120E26", "#28224A", t, .5); cityLayer(c, L2, 420, 472, "#18122E", "#342A60", t, .6);
    if (!comic()) { c.fillStyle = lg(c, 0, 360, 0, 472, [[0, "rgba(60,30,80,0)"], [1, "rgba(50,40,90,.6)"]]); c.fillRect(-100, 360, 560, 112); }
    street(c, 160, 1, false);
    // фонарь у дома
    c.beginPath(); c.rect(56, 330, 6, 142); c.fillStyle = pick("#2E2840", "#3A3266"); c.fill(); ink(c, 2);
    c.beginPath(); c.moveTo(48, 330); c.lineTo(70, 330); c.lineTo(64, 318); c.lineTo(54, 318); c.closePath(); c.fill(); ink(c, 2);
    if (!comic()) { c.fillStyle = rg(c, 59, 334, 2, 110, [[0, "rgba(255,230,170,.85)"], [.12, "rgba(255,210,130,.3)"], [1, "rgba(255,200,120,0)"]]); c.fillRect(-60, 220, 240, 260); }
    cafe(c, t);
    const heroT = (t - 3.6) / 2.0;
    const lookAtHero = t > 4.6 ? 1.6 : t > 2.4 ? -1 : 0;
    kitty(c, 205, 472, { blink: (t > 6.4 && t < 6.55) || (t > 1.1 && t < 1.22), look: lookAtHero });
    heartP(c, 236, 400 - clamp((t - 7) / .4) * 10, 1.1, clamp((t - 7) / .3));
    car(c, { x: carX, wheel: carX / 19, lights: t < 2.9 ? 1 : lerp(1, .12, clamp((t - 2.9) / .4)), door: ease((t - 3.0) / .5), look: t > 2.6 && t < 3.0 ? "cam" : "fwd", speedLines: t < 2.4 });
    if (t > 3.4) {   // герой выходит из машины и идёт к коту
      const p1 = ease((t - 3.6) / 1.5), p2 = ease((t - 5.1) / .6);
      const hx = lerp(lerp(carX + 150, 262, p1), 268, p2), hb = lerp(604, 484, p2), s = lerp(1.05, .92, p2);
      const walking = t > 3.6 && t < 5.7;
      hero(c, hx, hb, s, walking ? t * 9 : 0, t > 5.75 ? -1 : 1);
    }
    c.restore();
  }
  // 5. Объявления: рука клеит листовку на мокрый столб, потом камера отъезжает
  function poster(c, x, y, w, h, t, sc = 1) {
    c.save(); c.translate(x, y); c.scale(sc, sc);
    c.beginPath(); c.rect(0, 0, w, h); c.fillStyle = pick(lg(c, 0, 0, w, h, [[0, "#FBF6EC"], [1, "#E8DFD0"]]), "#FFFFFF"); c.fill(); ink(c, 2.5);
    if (!comic()) { c.strokeStyle = "rgba(120,100,80,.15)"; c.lineWidth = 1; c.beginPath(); c.moveTo(0, h * .3); c.lineTo(w, h * .36); c.moveTo(w * .6, 0); c.lineTo(w * .52, h * .7); c.stroke(); }
    c.textAlign = "center"; c.textBaseline = "middle";
    c.font = `900 ${w * .2}px Rubik, sans-serif`; c.fillStyle = "#C2316E"; c.fillText("ИЩЕМ", w / 2, h * .1); c.fillText("КОТОВ", w / 2, h * .2);
    c.save(); c.translate(w / 2, h * .43); const cs = w / 170; c.scale(cs, cs);
    c.beginPath(); c.ellipse(0, 0, 34, 30, 0, 0, 7); c.moveTo(-30, -12); c.lineTo(-34, -46); c.lineTo(-10, -26); c.moveTo(30, -12); c.lineTo(34, -46); c.lineTo(10, -26); c.fillStyle = "#9AA3B5"; c.fill(); c.lineWidth = 3; c.strokeStyle = "#2A1A30"; c.stroke();
    c.fillStyle = "#FFD23F"; c.beginPath(); c.arc(-12, -2, 6, 0, 7); c.arc(12, -2, 6, 0, 7); c.fill(); c.fillStyle = "#2A1A30"; c.fillRect(-13, -7, 2.4, 10); c.fillRect(11, -7, 2.4, 10);
    c.fillStyle = "#FF8FC4"; c.beginPath(); c.moveTo(-4, 8); c.lineTo(4, 8); c.lineTo(0, 12); c.fill(); c.restore();
    c.font = `900 ${w * .15}px Rubik, sans-serif`; c.fillStyle = "#2A1A30"; c.fillText("В КОМАНДУ!", w / 2, h * .65);
    c.font = `600 ${w * .065}px Rubik, sans-serif`; c.fillStyle = "#5A4A60"; c.fillText("Старое кафе, Дождевая ул.", w / 2, h * .73);
    for (let k = 0; k < 7; k++) { const sw = Math.sin(t * 6 + k) * (k % 2 ? 2 : 3); c.save(); c.translate(w * (.07 + k * .135), h * .8); c.rotate(sw * .03); c.beginPath(); c.rect(-w * .055, 0, w * .11, h * .2); c.fillStyle = pick(k % 2 ? "#F1EADF" : "#FBF6EC", "#FFFFFF"); c.fill(); ink(c, 1.6); c.rotate(Math.PI / 2); c.font = `800 ${w * .05}px Rubik`; c.fillStyle = "#C2316E"; c.fillText("МЯУ", h * .1, 0); c.restore(); }
    c.restore();
  }
  function hand(c, x, y, a = 0) {
    c.save(); c.translate(x, y); c.rotate(a);
    c.beginPath(); c.roundRect(10, -22, 260, 46, 18); c.fillStyle = pick(lg(c, 0, -22, 0, 24, [[0, "#3B3F7A"], [1, "#262A55"]]), "#3B3F7A"); c.fill(); ink(c);
    c.fillStyle = "#21E6FF"; c.fillRect(40, -22, 6, 46);
    c.beginPath(); c.roundRect(-34, -20, 52, 40, 14); c.fillStyle = "#F2C9A6"; c.fill(); ink(c, 2);
    for (let i = 0; i < 4; i++) { c.beginPath(); c.roundRect(-62, -18 + i * 10, 34, 9, 4.5); c.fillStyle = "#F2C9A6"; c.fill(); ink(c, 1.6); }
    c.beginPath(); c.roundRect(-30, 14, 26, 10, 5); c.fill(); ink(c, 1.6);
    c.restore();
  }
  function shotPoster(c, t, o = {}) {
    const wide = o.wideOnly ? 1 : o.closeOnly ? 0 : ease((t - 3.1) / 1.0);
    // ---- общий план: улица в перспективе, объявления на каждом столбе ----
    if (wide > 0) {
      c.save(); c.globalAlpha = wide;
      c.fillStyle = pick(lg(c, 0, 0, 0, 300, [[0, "#06051A"], [1, "#24163A"]]), "#1E1A3A"); c.fillRect(0, 0, LW, LH);
      const VX = 250, VY = 300;
      c.beginPath(); c.moveTo(VX, VY); c.lineTo(LW + 200, LH); c.lineTo(-200, LH); c.closePath(); c.fillStyle = pick(lg(c, 0, VY, 0, LH, [[0, "#1D1830"], [1, "#0E0B18"]]), "#2A2448"); c.fill();
      c.beginPath(); c.moveTo(VX, VY); c.lineTo(LW + 200, LH); c.lineTo(LW + 200, VY); c.closePath(); c.fillStyle = pick("#3E3350", "#5A4A80"); c.fill(); ink(c, 2);
      // дома справа уходят к горизонту
      for (let i = 0; i < 6; i++) { const z = 1 + i * .9, x = VX + 220 / z, h = 320 / z; c.beginPath(); c.rect(x, VY - h, 200 / z, h + 40 / z); c.fillStyle = pick(i ? "#2A1A34" : "#3A2030", "#4A3060"); c.fill(); ink(c, 1.6); c.fillStyle = "#FFC94D"; if (i % 2) c.fillRect(x + 30 / z, VY - h * .6, 30 / z, 30 / z); }
      // кафе вдали светится
      c.fillStyle = pick(rg(c, VX + 10, VY - 30, 2, 70, [[0, "rgba(255,180,90,.7)"], [1, "rgba(255,180,90,0)"]]), "#FFC94D"); if (comic()) { c.fillRect(VX - 4, VY - 40, 26, 22); } else c.fillRect(VX - 60, VY - 100, 140, 140);
      c.font = "900 12px Rubik"; c.fillStyle = "#FFC277"; c.textAlign = "center"; c.fillText("CAFE", VX + 10, VY - 46);
      // столбы с объявлениями
      for (let i = 4; i >= 0; i--) { const z = 1 + i * 1.7, x = VX + (40 - 250) / z * 1.0 + (i === 0 ? 0 : 0) - 10, xb = lerp(VX, 70, 1 / z * 1.0), yb = VY + 340 / z, h = 420 / z;
        c.beginPath(); c.rect(xb - 4 / z * 2, yb - h, 8 / z * 2, h); c.fillStyle = pick("#3A3550", "#4A4580"); c.fill(); ink(c, 1.4);
        poster(c, xb - 30 / z * 2, yb - h * .62, 60 / z * 2, 92 / z * 2, t);
        if (!comic()) { c.fillStyle = rg(c, xb, yb - h, 1, 60 / z * 2, [[0, "rgba(255,230,170,.6)"], [1, "rgba(255,230,170,0)"]]); c.fillRect(xb - 60 / z * 2, yb - h - 60 / z * 2, 120 / z * 2, 120 / z * 2); } }
      c.restore();
    }
    if (wide >= 1) return;
    // ---- крупный план: столб, рука, листовка; при отъезде уменьшается к первому столбу ----
    c.save(); c.globalAlpha = 1 - wide;
    const k = lerp(1, .32, wide); c.translate(lerp(0, 70 - 175 * .32, wide), lerp(0, 300, wide)); c.scale(k, k);
    c.fillStyle = pick(lg(c, 0, 0, 0, LH, [[0, "#0A0820"], [1, "#1A1030"]]), "#2A2458"); c.fillRect(-20, -20, 400, 680);
    for (let i = 0; i < 14; i++) { const x = (i * 67) % LW, y = 60 + (i * 113) % 520, r = 18 + (i % 4) * 10; if (comic()) { c.globalAlpha = .45 * (1 - wide); c.fillStyle = WINC[i % 3]; c.beginPath(); c.arc(x, y, r * .6, 0, 7); c.fill(); c.globalAlpha = 1 - wide; } else { c.fillStyle = rg(c, x, y, 0, r, [[0, ["rgba(255,201,77,.35)", "rgba(33,230,255,.3)", "rgba(255,143,196,.3)"][i % 3]], [1, "rgba(0,0,0,0)"]]); c.fillRect(x - r, y - r, r * 2, r * 2); } }
    // столб
    c.beginPath(); c.rect(146, -20, 66, 680); c.fillStyle = pick(lg(c, 146, 0, 212, 0, [[0, "#26213A"], [.35, "#6A6290"], [.55, "#4A4468"], [1, "#1A1628"]]), "#5A5490"); c.fill(); ink(c, 3);
    for (const y of [60, 560]) { c.fillStyle = pick("#8A84B0", "#2A2448"); c.beginPath(); c.arc(179, y, 4, 0, 7); c.fill(); }
    c.fillStyle = pick("rgba(200,210,255,.25)", "rgba(255,255,255,.5)"); for (let i = 0; i < 6; i++) c.fillRect(160 + i * 9, ((i * 90 + t * 60) % 700) - 60, 2, 50);
    c.fillStyle = pick("rgba(240,230,210,.5)", "#E8E0D0"); c.fillRect(150, 470, 40, 18); c.fillRect(170, 130, 30, 10);   // обрывки старых бумажек
    // листовка: прилетает в руке, шлёп, разглаживается, скотч
    const inP = easeOut(t / .9), slap = t > .9 ? Math.max(0, 1 - (t - .9) / .18) : 0;
    const px = lerp(260, 0, inP), rot = lerp(.32, -.03, inP), sq = 1 + slap * .05;
    c.save(); c.translate(180 + px, 285); c.rotate(rot); c.scale(sq, 1 / sq);
    poster(c, -88, -140, 176, 280, t);
    const tape = (tx, ty, a, at) => { if (t < at) return; c.save(); c.translate(tx, ty); c.rotate(a); c.globalAlpha = (1 - wide) * .85; c.fillStyle = pick("rgba(230,225,200,.85)", "#FFF4C8"); c.fillRect(-18, -6, 36, 12); ink(c, 1.4); c.restore(); c.globalAlpha = 1 - wide; };
    tape(-84, -136, -.6, 1.45); tape(84, -136, .6, 1.7); tape(-84, 136, .6, 2.15); tape(84, 136, -.6, 2.35);
    c.restore();
    if (comic() && t > .9 && t < 1.4) { c.strokeStyle = INK; c.lineWidth = 3; for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; c.beginPath(); c.moveTo(180 + Math.cos(a) * 150, 285 + Math.sin(a) * 190); c.lineTo(180 + Math.cos(a) * 175, 285 + Math.sin(a) * 215); c.stroke(); } }
    // рука: держит, прижимает, разглаживает сверху вниз и уходит
    let hx, hy, ha = 0;
    if (t < .9) { hx = 180 + px + 70; hy = 285 + 20; ha = rot; }
    else if (t < 1.2) { hx = 250; hy = 300; }
    else if (t < 2.5) { const p = ease((t - 1.2) / 1.3); hx = 236 + Math.sin(t * 9) * 6; hy = lerp(170, 400, p); }
    else { const p = easeIn((t - 2.5) / .5); hx = lerp(236, 520, p); hy = 400; }
    if (t < 3.05) hand(c, hx, hy, ha);
    c.restore();
  }
  // 6. Название
  function shotTitle(c, t) {
    c.fillStyle = pick(lg(c, 0, 0, 0, LH, [[0, "#05031A"], [1, "#160A30"]]), "#1A1238"); c.fillRect(0, 0, LW, LH);
    cityLayer(c, L2, 80, 640, "#0E0A20", "#2A2058", t, .35);
    const on = t > .5 && !(t > .8 && t < .95) && !(t > 1.25 && t < 1.33);
    c.textAlign = "center"; c.textBaseline = "middle";
    const word = (s, y, size, col, off) => {
      c.font = comic() ? `${size}px ${SFXF}` : `900 ${size}px Rubik, sans-serif`;
      if (!on) { c.fillStyle = off; c.fillText(s, LW / 2, y); return; }
      if (comic()) { c.lineWidth = 8; c.strokeStyle = INK; c.strokeText(s, LW / 2, y); c.fillStyle = col; c.fillText(s, LW / 2, y); return; }
      c.shadowColor = col; c.shadowBlur = 26; c.fillStyle = col; c.fillText(s, LW / 2, y); c.shadowBlur = 8; c.fillStyle = "#FFFFFF"; c.globalAlpha = .55; c.fillText(s, LW / 2, y); c.globalAlpha = 1; c.shadowBlur = 0;
    };
    word("MEOW", 270, 86, "#21E6FF", "#10283A"); word("CAFE", 350, 70, "#FF5CA8", "#3A1530");
    if (t > 1.8) { c.globalAlpha = clamp((t - 1.8) / .6); c.font = "700 16px Rubik, sans-serif"; c.fillStyle = "#CFC6F0"; c.fillText("История начинается", LW / 2, 420); c.globalAlpha = 1; }
  }

  // ======================= ЗВУК =======================
  const A = { on: false, muted: false };
  function audioInit() {
    if (A.ac) { if (A.ac.state === "suspended") A.ac.resume(); return; }
    try {
      const ac = new (window.AudioContext || window.webkitAudioContext)(); A.ac = ac;
      A.master = ac.createGain(); A.master.gain.value = A.muted ? 0 : .9; A.master.connect(ac.destination);
      const buf = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate), d = buf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; A.noise = buf;
      const rs = ac.createBufferSource(); rs.buffer = buf; rs.loop = true; const hp = ac.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 900; const lp = ac.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 7000;
      A.rain = ac.createGain(); A.rain.gain.value = 0; rs.connect(hp).connect(lp).connect(A.rain).connect(A.master); rs.start();
      const eo = ac.createOscillator(); eo.type = "sawtooth"; eo.frequency.value = 46; const el = ac.createBiquadFilter(); el.type = "lowpass"; el.frequency.value = 170;
      A.eng = ac.createGain(); A.eng.gain.value = 0; eo.connect(el).connect(A.eng).connect(A.master); eo.start();
      A.on = true;
    } catch (e) { A.on = false; }
  }
  const aset = (n, v) => { if (A.on) n.gain.setTargetAtTime(v, A.ac.currentTime, .25); };
  function burst(freq, dur, vol, type = "lowpass") { if (!A.on) return; const ac = A.ac, s = ac.createBufferSource(); s.buffer = A.noise; const f = ac.createBiquadFilter(); f.type = type; f.frequency.value = freq; const g = ac.createGain(); g.gain.setValueAtTime(vol, ac.currentTime); g.gain.exponentialRampToValueAtTime(.001, ac.currentTime + dur); s.connect(f).connect(g).connect(A.master); s.start(); s.stop(ac.currentTime + dur); }
  function tone(freq, dur, vol, type = "sine", to) { if (!A.on) return; const ac = A.ac, o = ac.createOscillator(); o.type = type; o.frequency.setValueAtTime(freq, ac.currentTime); if (to) { o.frequency.linearRampToValueAtTime(to[0], ac.currentTime + dur * .4); o.frequency.linearRampToValueAtTime(to[1], ac.currentTime + dur); } const g = ac.createGain(); g.gain.setValueAtTime(.0001, ac.currentTime); g.gain.exponentialRampToValueAtTime(vol, ac.currentTime + .03); g.gain.exponentialRampToValueAtTime(.0001, ac.currentTime + dur); o.connect(g).connect(A.master); o.start(); o.stop(ac.currentTime + dur + .05); }
  const SND = {
    thunder: () => { burst(220, 2.8, .9); setTimeout(() => burst(110, 2.2, .7), 180); },
    beep: () => tone(1046, .09, .08), meow: () => tone(560, .75, .2, "triangle", [880, 470]),
    door: () => burst(320, .25, .4), slap: () => { burst(900, .12, .6, "bandpass"); burst(200, .2, .5); }, tape: () => burst(2500, .18, .15, "highpass"),
    hum: () => tone(110, 1.4, .07, "square"), stepL: () => burst(500, .08, .12, "bandpass"),
    sput: () => { aset(A.eng, .05); setTimeout(() => aset(A.eng, .3), 260); setTimeout(() => aset(A.eng, .03), 650); setTimeout(() => aset(A.eng, .25), 900); },
    off: () => { aset(A.eng, 0); burst(150, .5, .45); },
  };

  // ======================= ВАРИАНТ 1: ФИЛЬМ-ИЛЛЮСТРАЦИЯ =======================
  const BOLT = [[220, 0], [200, 50], [232, 92], [196, 150], [226, 200], [204, 250]], BOLT2 = [[90, 0], [112, 60], [80, 110], [106, 170]];
  const FILM = [
    { d: 6.5, rain: .1, eng: .45, draw: (c, t) => shotDrive(c, t, { look: t => t > 2 && t < 3.1 ? "cam" : t > 3.6 && t < 4.4 ? "back" : t > 5.2 ? "up" : "fwd" }) },
    { d: 5.5, rain: .05, eng: .3, draw: (c, t) => shotTower(c, t) },
    { d: 4.5, rain: 1, eng: .5, draw: (c, t) => shotDrive(c, t, { storm: true, t0: 600, flashes: [.8, 3.0], bolt: t < 2 ? BOLT : BOLT2 }), cues: [[.95, "thunder"], [3.3, "thunder"]] },
    { d: 5.6, rain: 0, eng: .35, draw: (c, t) => shotFuel(c, t), cues: [[1.25, "beep"], [2.0, "beep"], [2.75, "beep"], [3.5, "beep"], [2.4, "sput"], [4.5, "off"]] },
    { d: 9, rain: .8, eng: 0, draw: (c, t) => shotArrive(c, t), cues: [[.55, "thunder"], [3.0, "door"], [3.9, "stepL"], [4.4, "stepL"], [4.9, "stepL"], [7.0, "meow"]] },
    { d: 7, rain: .6, eng: 0, draw: (c, t) => shotPoster(c, t), cues: [[.9, "slap"], [1.45, "tape"], [1.7, "tape"], [2.15, "tape"], [2.35, "tape"]] },
    { d: 4.2, rain: .3, eng: 0, draw: (c, t) => shotTitle(c, t), cues: [[.5, "hum"]] },
  ];

  // ======================= ПРОИГРЫВАТЕЛЬ В ИГРЕ =======================
  // Prolog.play({ onEnd }) — полноэкранная заставка поверх игры. Сначала экран «Смотреть», потому что звук
  // в браузере можно включить только после касания. «Пропустить» есть всегда.
  const TOTAL = FILM.reduce((s, x) => s + x.d, 0);
  function play(opts = {}) {
    if (document.getElementById("prolog")) return;
    const root = document.createElement("div");
    root.id = "prolog";
    root.style.cssText = "position:fixed;inset:0;z-index:9999;background:#000;display:grid;place-items:center;opacity:0;transition:opacity .5s";
    root.innerHTML = `<canvas style="display:block"></canvas>
      <div data-start style="position:absolute;inset:0;display:grid;place-items:center;background:rgba(7,4,26,.55)">
        <div style="display:flex;flex-direction:column;gap:12px;align-items:center;text-align:center;padding:24px;max-width:300px">
          <b style="font-size:22px;color:#EEE8FF">Пролог</b>
          <span style="font-size:14px;color:#A096CC;line-height:1.45">Как всё началось. Около 40 секунд — лучше со звуком.</span>
          <button data-go style="font:800 16px system-ui,sans-serif;border:0;border-radius:16px;min-height:52px;padding:0 26px;background:#FF5CA8;color:#2A0618">▶ Смотреть</button>
          <button data-skip2 style="font:700 14px system-ui,sans-serif;border:0;background:none;color:#A096CC;min-height:40px">Пропустить</button></div></div>
      <button data-skip hidden style="position:absolute;top:calc(12px + env(safe-area-inset-top,0px));right:12px;font:700 13px system-ui,sans-serif;color:#EEE8FF;background:rgba(22,15,51,.75);border:1px solid rgba(160,148,210,.35);border-radius:999px;padding:0 14px;min-height:40px">Пропустить ›</button>`;
    document.body.appendChild(root);
    requestAnimationFrame(() => root.style.opacity = 1);
    cv = root.querySelector("canvas"); ctx = cv.getContext("2d");
    function fit() {
      const w = Math.min(innerWidth, innerHeight * 9 / 16), h = w * 16 / 9, dpr = Math.min(2, devicePixelRatio || 1);
      cv.style.width = w + "px"; cv.style.height = h + "px"; cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    }
    fit(); addEventListener("resize", fit);
    let T = 27, playing = false, last = performance.now(), fired = new Set(), seg = -1, done = false, raf = 0;
    function frame(now) {
      const dt = Math.min(.05, (now - last) / 1000); last = now;
      if (playing) { T += dt; stepRain(dt); }
      const TT = Math.min(T, TOTAL - .001);
      let acc = 0, i = 0; while (i < FILM.length - 1 && TT >= acc + FILM[i].d) { acc += FILM[i].d; i++; }
      const S = FILM[i], lt = TT - acc;
      if (playing && seg !== i) { seg = i; aset(A.rain, S.rain * .22); aset(A.eng, S.eng * .5); }
      ctx.setTransform(cv.width / LW, 0, 0, cv.height / LH, 0, 0); ctx.clearRect(0, 0, LW, LH);
      MODE = "vec"; S.draw(ctx, lt); rain(ctx, S.rain);
      for (const [at, name] of S.cues || []) { const key = i + ":" + at + name; if (playing && lt >= at && !fired.has(key)) { fired.add(key); try { SND[name](); } catch (e) {} } }
      const fade = Math.max(i ? clamp(1 - lt / .4) : clamp(1 - lt / .8), i < FILM.length - 1 ? clamp(1 - (S.d - lt) / .4) : 0);
      if (fade > 0) { ctx.fillStyle = `rgba(0,0,0,${fade})`; ctx.fillRect(0, 0, LW, LH); }
      const v = ctx.createRadialGradient(LW / 2, LH / 2, LH * .3, LW / 2, LH / 2, LH * .75); v.addColorStop(0, "rgba(0,0,0,0)"); v.addColorStop(1, "rgba(0,0,0,.5)"); ctx.fillStyle = v; ctx.fillRect(0, 0, LW, LH);
      if (playing && T >= TOTAL + .6) return finish();
      raf = requestAnimationFrame(frame);
    }
    function finish() {
      if (done) return; done = true; playing = false;
      cancelAnimationFrame(raf); removeEventListener("resize", fit);
      if (A.on) { aset(A.rain, 0); aset(A.eng, 0); setTimeout(() => { try { A.ac.close(); } catch (e) {} A.ac = null; A.on = false; }, 700); }
      root.style.opacity = 0;
      setTimeout(() => { root.remove(); opts.onEnd && opts.onEnd(); }, 500);
    }
    root.querySelector("[data-go]").onclick = () => {
      A.muted = window.Snd ? !(Snd.sfxOn || Snd.musicOn) : false;
      audioInit(); root.querySelector("[data-start]").remove(); root.querySelector("[data-skip]").hidden = false;
      T = 0; fired = new Set(); seg = -1; playing = true;
    };
    root.querySelector("[data-skip]").onclick = finish;
    root.querySelector("[data-skip2]").onclick = finish;
    raf = requestAnimationFrame(frame);
  }
  window.Prolog = { play, duration: TOTAL };
})();
