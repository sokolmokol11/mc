"""
Обслуживание гостей: столики приводят гостей, кухня готовит заказы, меню задаёт чек.
Продажи в секунду = меньшее из (гостей в секунду, заказов кухни в секунду) × средний чек.
Это просто ещё одна часть дохода в секунду, поэтому копилка и «доход, пока тебя нет» считают её так же, как доход котов.
"""
from config import (DISH_MAX, DISH_PRICE_GROWTH, DISH_UP, DISH_UP_GROWTH, DISHES, KITCHEN_CAT_BONUS, KITCHEN_MAX,
                    KITCHEN_RATE, KITCHEN_RATE_GROWTH, KITCHEN_UP, KITCHEN_UP_GROWTH, MAX_LEVEL, MENU_VARIETY, TABLE_BUY,
                    TABLE_BUY_GROWTH, TABLE_MAX, TABLE_RATE, TABLE_RATE_GROWTH, TABLE_SEATS, TABLE_UP, TABLE_UP_GROWTH)

DEFAULT_TABLES = ";".join(",".join("1" if (room == 0 and i == 0) else "0" for i in range(n)) for room, n in TABLE_SEATS.items())
ROOM_KEYS = list(TABLE_SEATS)          # порядок частей в строке: сначала Кафе, потом Зал


def parse_tables(s: str | None) -> dict[int, list[int]]:
    parts = (s or DEFAULT_TABLES).split(";")
    out = {}
    for k, room in enumerate(ROOM_KEYS):
        vals = [int(x) for x in parts[k].split(",")] if k < len(parts) and parts[k] else []
        vals = (vals + [0] * TABLE_SEATS[room])[:TABLE_SEATS[room]]
        out[room] = vals
    return out


def dump_tables(t: dict[int, list[int]]) -> str:
    return ";".join(",".join(str(v) for v in t[room]) for room in ROOM_KEYS)


def table_rate(level: int) -> float:
    return 0 if level <= 0 else TABLE_RATE * TABLE_RATE_GROWTH ** (level - 1)


def guests_per_sec(tables: dict[int, list[int]], rooms_open: int) -> float:
    return sum(table_rate(l) for room, levels in tables.items() if room < rooms_open for l in levels)


def kitchen_cats_bonus(cats) -> float:
    """cats = [(rarity, level), ...] — коты, которые стоят на кухне (комната 1)."""
    return sum(KITCHEN_CAT_BONUS[r] * (1 + 0.1 * (min(lvl, MAX_LEVEL) - 1)) for r, lvl in cats)


def kitchen_per_sec(level: int, cat_bonus: float) -> float:
    return KITCHEN_RATE * KITCHEN_RATE_GROWTH ** (level - 1) * (1 + cat_bonus)


def dish_price(key: str, level: int) -> float:
    return DISHES[key][1] * DISH_PRICE_GROWTH ** (level - 1)


def avg_check(dish_levels: dict[str, int]) -> float:
    have = [dish_price(k, l) for k, l in dish_levels.items() if l > 0]
    if not have:
        return 0.0
    return sum(have) / len(have) * (1 + MENU_VARIETY * (len(have) - 1))


def sales_per_sec(tables, rooms_open, kitchen_level, cat_bonus, dish_levels) -> float:
    return min(guests_per_sec(tables, rooms_open), kitchen_per_sec(kitchen_level, cat_bonus)) * avg_check(dish_levels)


def table_buy_cost(tables: dict[int, list[int]]) -> int:
    bought = sum(1 for levels in tables.values() for l in levels if l > 0)
    return int(round(TABLE_BUY * TABLE_BUY_GROWTH ** max(0, bought - 1), -2))


def table_up_cost(level: int) -> int:
    return int(round(TABLE_UP * TABLE_UP_GROWTH ** (level - 1), -2))


def kitchen_up_cost(level: int) -> int:
    return int(round(KITCHEN_UP * KITCHEN_UP_GROWTH ** (level - 1), -2))


def dish_up_cost(key: str, level: int) -> int:
    return int(round(DISHES[key][1] * DISH_UP * DISH_UP_GROWTH ** (level - 1), -2))


__all__ = ["DEFAULT_TABLES", "TABLE_MAX", "KITCHEN_MAX", "DISH_MAX"]

from config import DISHES as DISHES  # noqa: E402,F401  (для player.service_view)
