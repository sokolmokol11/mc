"""
Обслуживание гостей.
  POST /api/tables/buy      — купить столик на свободное место: {"room": 0 | 2, "seat": 0..}
  POST /api/tables/upgrade  — прокачать столик: {"room": 0 | 2, "seat": 0..}
  POST /api/kitchen/upgrade — прокачать кухню
  POST /api/menu/upgrade    — прокачать блюдо: {"dish": "coffee" | "bun"}
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import levels
import service as sv
from config import LOCATIONS
from db import get_db
from deps import telegram_data
from models import utcnow
from routers.player import get_user, spend, state

router = APIRouter(prefix="/api", tags=["service"])


class SeatRequest(BaseModel):
    room: int
    seat: int


class DishRequest(BaseModel):
    dish: str


def _seat(user, req: SeatRequest):
    tables = sv.parse_tables(user.tables)
    if req.room not in tables or not 0 <= req.seat < len(tables[req.room]):
        raise HTTPException(status_code=400, detail="Нет такого места")
    if req.room >= (user.locations_open or 1):
        raise HTTPException(status_code=400, detail=f"Сначала открой комнату «{LOCATIONS[req.room][0]}»")
    return tables


@router.post("/tables/buy")
def buy_table(req: SeatRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    tables = _seat(user, req)
    if tables[req.room][req.seat] > 0:
        raise HTTPException(status_code=400, detail="Здесь уже стоит столик")
    spend(db, user, sv.table_buy_cost(tables), now)   # spend сначала собирает копилку по старому доходу
    tables[req.room][req.seat] = 1
    user.tables = sv.dump_tables(tables)
    levels.add(user, "table")
    db.commit()
    return state(user, now)


@router.post("/tables/upgrade")
def upgrade_table(req: SeatRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    tables = _seat(user, req)
    lvl = tables[req.room][req.seat]
    if lvl <= 0:
        raise HTTPException(status_code=400, detail="Сначала купи столик")
    if lvl >= sv.TABLE_MAX:
        raise HTTPException(status_code=400, detail="Максимальный уровень")
    spend(db, user, sv.table_up_cost(lvl), now)
    tables[req.room][req.seat] = lvl + 1
    user.tables = sv.dump_tables(tables)
    levels.add(user, "upgrade")
    db.commit()
    return state(user, now)


@router.post("/kitchen/upgrade")
def upgrade_kitchen(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    lvl = user.kitchen_level or 1
    if lvl >= sv.KITCHEN_MAX:
        raise HTTPException(status_code=400, detail="Максимальный уровень")
    spend(db, user, sv.kitchen_up_cost(lvl), now)
    user.kitchen_level = lvl + 1
    levels.add(user, "upgrade")
    db.commit()
    return state(user, now)


@router.post("/menu/upgrade")
def upgrade_dish(req: DishRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if req.dish not in sv.DISHES:
        raise HTTPException(status_code=400, detail="Нет такого блюда")
    user = get_user(db, tg)
    now = utcnow()
    field = f"dish_{req.dish}"
    lvl = getattr(user, field)
    lvl = 1 if lvl is None else lvl
    if lvl <= 0:
        raise HTTPException(status_code=400, detail="Рецепт ещё не открыт")
    if lvl >= sv.DISH_MAX:
        raise HTTPException(status_code=400, detail="Максимальный уровень")
    spend(db, user, sv.dish_up_cost(req.dish, lvl), now)
    setattr(user, field, lvl + 1)
    levels.add(user, "upgrade")
    db.commit()
    return state(user, now)
