"""
Шаг 5: развитие кафе.
  POST /api/locations/open  — открыть следующую локацию
  POST /api/upgrades/buy    — {"kind": "cash" | "bank" | "coffee" | "tables"}
  POST /api/cats/move       — {"cat_id": 8, "location": 0..4 или null (в запас)}
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import economy as eco
from config import LOCATIONS, UPGRADE_MAX
from db import get_db
from deps import telegram_data
from models import utcnow
from routers.player import UPGRADE_INFO, collect, get_user, location_counts, spend, state

router = APIRouter(prefix="/api", tags=["progress"])


class UpgradeRequest(BaseModel):
    kind: str


class MoveRequest(BaseModel):
    cat_id: int
    location: int | None = None


@router.post("/locations/open")
def open_location(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    nxt = user.locations_open
    if nxt >= len(LOCATIONS):
        raise HTTPException(status_code=400, detail="Все локации уже открыты")
    spend(db, user, LOCATIONS[nxt][1], now)
    user.locations_open = nxt + 1
    db.commit()
    return {**state(user, now), "opened": LOCATIONS[nxt][0]}


@router.post("/upgrades/buy")
def buy_upgrade(req: UpgradeRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if req.kind not in UPGRADE_INFO:
        raise HTTPException(status_code=400, detail="Нет такого улучшения")
    user = get_user(db, tg)
    now = utcnow()
    field = f"{req.kind}_level"
    level = getattr(user, field) or 1
    if level >= UPGRADE_MAX[req.kind]:
        raise HTTPException(status_code=400, detail="Максимальный уровень")
    # Касса меняет доход, а копилка — лимит: spend() сначала собирает накопленное по старым правилам.
    spend(db, user, eco.upgrade_cost(req.kind, level), now)
    setattr(user, field, level + 1)
    db.commit()
    return {**state(user, now), "upgraded": UPGRADE_INFO[req.kind][0], "level": level + 1}


@router.post("/cats/move")
def move_cat(req: MoveRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    cat = next((c for c in user.cats if c.cat_id == req.cat_id), None)
    if cat is None:
        raise HTTPException(status_code=404, detail="У тебя нет такого кота")
    if req.location is not None:
        if not 0 <= req.location < user.locations_open:
            raise HTTPException(status_code=400, detail="Эта локация ещё закрыта")
        if cat.location != req.location and location_counts(user).get(req.location, 0) >= LOCATIONS[req.location][2]:
            raise HTTPException(status_code=400, detail=f"{LOCATIONS[req.location][0]}: все места заняты")
    collect(user, now)  # доход меняется — сначала собираем по старому
    cat.location = req.location
    if req.location != 0 and user.barista_cat_id == cat.cat_id:
        user.barista_cat_id = None
    db.commit()
    return state(user, now)
