"""
Шаг 6: Десертопад.
  GET  /api/game         — попытки, рекорд, сколько стоит 1 очко
  POST /api/game/start   — списать попытку, получить seed партии
  POST /api/game/finish  — {"session_id": 1, "taps": [[t_ms, x_pct, y_pct], ...]} → очки и награда
"""
import secrets
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import economy as eco
import game_logic as gl
from config import CENTS, COFFEE_PER_LEVEL, GAME_ATTEMPTS_MAX, GAME_REGEN_HOURS, MIN_PER_POINT, SEC_PER_POINT
from db import get_db
from deps import telegram_data
from models import GameSession, User, utcnow
from routers.player import get_user, income_of, mark_activity, state

router = APIRouter(prefix="/api/game", tags=["game"])

FLAGGED_SCORE_CAP = 15        # подозрительной партии засчитываем не больше 15 очков и не пускаем в рейтинг
MIN_REAL_SECONDS = 29         # партия не может закончиться быстрее реального времени (30 с)
MAX_REAL_SECONDS = 180        # и не может длиться бесконечно


class FinishRequest(BaseModel):
    session_id: int
    taps: list[list[float]] = []


def refresh_attempts(user: User, now: datetime) -> int:
    """+1 попытка каждые 3 часа, максимум 3. Возвращает секунды до следующей попытки (0 — полные)."""
    period = timedelta(hours=GAME_REGEN_HOURS)
    if user.game_attempts is None:
        user.game_attempts = GAME_ATTEMPTS_MAX
    if user.game_attempts >= GAME_ATTEMPTS_MAX:
        user.attempts_at = None
        return 0
    since = eco.as_utc(user.attempts_at or now)
    gained = int((eco.as_utc(now) - since) / period)
    if gained:
        user.game_attempts = min(GAME_ATTEMPTS_MAX, user.game_attempts + gained)
        since += gained * period
        user.attempts_at = None if user.game_attempts >= GAME_ATTEMPTS_MAX else since
    if user.game_attempts >= GAME_ATTEMPTS_MAX:
        return 0
    return max(0, int((since + period - eco.as_utc(now)).total_seconds()))


def per_point(user: User) -> float:
    """Сколько мяуконов стоит одно очко: 15 секунд дохода кафе × бонус кофемашины, но не меньше минимума."""
    coffee = 1 + COFFEE_PER_LEVEL * ((user.coffee_level or 1) - 1)
    return max(MIN_PER_POINT, income_of(user) * SEC_PER_POINT) * coffee


def game_view(user: User, now: datetime) -> dict:
    next_in = refresh_attempts(user, now)
    return {"attempts": user.game_attempts, "attempts_max": GAME_ATTEMPTS_MAX, "next_attempt_in": next_in,
            "best": user.game_best or 0, "per_point": round(per_point(user), 2),
            "points_season": user.game_points_season or 0, "duration_ms": gl.DURATION_MS}


@router.get("")
def get_game(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    view = game_view(user, now)
    db.commit()
    from routers.ads import ads_left  # здесь, чтобы не было круговой зависимости модулей
    return {**state(user, now), "game": view, "ads_left": ads_left(db, user.tg_id, now)}


@router.post("/start")
def start_game(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    refresh_attempts(user, now)
    if user.game_attempts <= 0:
        raise HTTPException(status_code=400, detail="Попытки закончились — новая через несколько часов")
    if user.game_attempts >= GAME_ATTEMPTS_MAX:
        user.attempts_at = now   # с этой минуты пошёл отсчёт до новой попытки
    user.game_attempts -= 1
    session = GameSession(user_id=user.tg_id, seed=secrets.randbits(31), started_at=now)
    db.add(session)
    db.commit()
    return {"session_id": session.id, "seed": session.seed, "duration_ms": gl.DURATION_MS,
            "game": game_view(user, now)}


@router.post("/finish")
def finish_game(req: FinishRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if len(req.taps) > 2 * gl.MAX_TAPS:
        raise HTTPException(status_code=400, detail="Слишком много тапов")
    user = get_user(db, tg)
    now = utcnow()
    session = db.get(GameSession, req.session_id)
    if session is None or session.user_id != user.tg_id:
        raise HTTPException(status_code=404, detail="Игра не найдена")
    if session.finished_at is not None:
        raise HTTPException(status_code=400, detail="Эта игра уже засчитана")

    real = (eco.as_utc(now) - eco.as_utc(session.started_at)).total_seconds()
    if real < MIN_REAL_SECONDS:
        raise HTTPException(status_code=400, detail="Игра ещё не закончилась")

    res = gl.verify(session.seed, req.taps)
    if real > MAX_REAL_SECONDS:
        res["flagged"], res["reasons"] = True, sorted(set(res["reasons"] + ["too_long"]))

    paid_score = min(res["score"], FLAGGED_SCORE_CAP) if res["flagged"] else res["score"]
    reward = int(paid_score * per_point(user) * CENTS)
    session.finished_at = now
    session.score, session.hits, session.misses = res["score"], res["hits"], res["misses"]
    session.flagged, session.reasons, session.reward = res["flagged"], ",".join(res["reasons"]), reward

    user.coins += reward
    user.coins_earned_season += reward
    new_record = False
    if not res["flagged"]:
        user.game_points_season = (user.game_points_season or 0) + res["score"]
        user.games_played = (user.games_played or 0) + 1
        if res["score"] > (user.game_best or 0):
            user.game_best, new_record = res["score"], True
        mark_activity(user, now)
    db.commit()
    # Игроку показываем одинаковый ответ, даже если партия подозрительная: бот не узнает, что пойман.
    return {**state(user, now), "game": game_view(user, now), "score": paid_score, "session_id": session.id,
            "hits": res["hits"], "rocks": res["rocks"], "reward": reward / CENTS, "new_record": new_record}
