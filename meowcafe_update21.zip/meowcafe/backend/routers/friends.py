"""
Шаг 8: друзья.
  GET  /api/friends          — реферальная ссылка, банк друзей, список друзей
  POST /api/friends/collect  — забрать банк (раз в час)

Как работает: друг заходит по ссылке t.me/<бот>?startapp=ref_<id> — при первом входе у него записывается referrer_id.
Каждый раз, когда друг собирает доход, 10% падает в банк пригласившего (у друга ничего не отнимается).
«Активный друг» — заходил в 3 разных дня и сыграл 3 засчитанные мини-игры. Только такие идут в рейтинг рефоводов.
"""
import asyncio
import time
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session, selectinload

import economy as eco
import tg_api
from config import (BOT_USERNAME, CENTS, REF_ACTIVE_DAYS, REF_ACTIVE_GAMES, REF_COLLECT_CAP_HOURS, REF_COLLECT_HOURS,
                    REF_COLLECT_MIN, REF_SHARE)
from db import get_db
from deps import telegram_data
from models import User, utcnow
from routers.player import display_name, get_user, income_of, state

router = APIRouter(prefix="/api/friends", tags=["friends"])
LIST_LIMIT = 100
_bot_username = BOT_USERNAME
_bot_retry_at = 0.0


def bot_username() -> str:
    """Имя бота для ссылки. Если не задано в .env — один раз спрашиваем у Telegram и запоминаем."""
    global _bot_username, _bot_retry_at
    if not _bot_username and time.time() >= _bot_retry_at:
        try:
            _bot_username = asyncio.run(tg_api.call("getMe")).get("username", "")
        except tg_api.TelegramError as e:
            _bot_retry_at = time.time() + 60          # не долбим Telegram на каждом запросе
            print("[friends] getMe:", e)
    return _bot_username


def collect_cap(user: User) -> int:
    """Сколько можно забрать из банка друзей за один раз (в сотых)."""
    return int(max(REF_COLLECT_MIN, income_of(user) * 3600 * REF_COLLECT_CAP_HOURS) * CENTS)


def collect_in(user: User, now) -> int:
    if user.ref_collect_at is None:
        return 0
    ready = eco.as_utc(user.ref_collect_at) + timedelta(hours=REF_COLLECT_HOURS)
    return max(0, int((ready - eco.as_utc(now)).total_seconds()))


def friends_view(db: Session, user: User, now, username: str) -> dict:
    base = select(User).where(User.referrer_id == user.tg_id)
    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    active = db.scalar(select(func.count()).select_from(
        base.where(User.is_active_ref.is_(True)).subquery())) or 0
    rows = db.scalars(base.options(selectinload(User.cats))
                      .order_by(User.is_active_ref.desc(), User.ref_given.desc()).limit(LIST_LIMIT)).all()
    friends, per_hour = [], 0.0
    for f in rows:
        inc = income_of(f)
        per_hour += inc * 3600 * REF_SHARE
        owned = {c.cat_id for c in f.cats}
        friends.append({
            "name": display_name(f),
            "avatar": f.avatar_cat_id if f.avatar_cat_id in owned else max(owned, default=None),
            "decor": f.avatar_decor or "",
            "active": bool(f.is_active_ref),
            "days": min(f.days_active or 0, REF_ACTIVE_DAYS), "games": min(f.games_played or 0, REF_ACTIVE_GAMES),
            "given": (f.ref_given or 0) / CENTS,
        })
    link = f"https://t.me/{username}?startapp=ref_{user.tg_id}" if username else ""
    return {
        "link": link, "bank": (user.ref_bank or 0) / CENTS, "collect_in": collect_in(user, now),
        "collect_cap": collect_cap(user) / CENTS,
        "per_hour": round(per_hour, 1), "total": total, "active": active, "friends": friends,
        "share_pct": round(REF_SHARE * 100), "need_days": REF_ACTIVE_DAYS, "need_games": REF_ACTIVE_GAMES,
    }


@router.get("")
def get_friends(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    name = bot_username()                # сеть — до блокировки игрока
    user = get_user(db, tg)
    now = utcnow()
    return {**state(user, now), "friends": friends_view(db, user, now, name)}


@router.post("/collect")
def collect_bank(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    name = bot_username()
    user = get_user(db, tg)
    now = utcnow()
    if collect_in(user, now) > 0:
        raise HTTPException(status_code=400, detail="Банк можно забирать раз в час")
    db.refresh(user)
    bank = user.ref_bank or 0
    if bank <= 0:
        raise HTTPException(status_code=400, detail="В банке пока пусто — пригласи друзей")
    # За раз — не больше часа своего дохода: друзья максимум удваивают доход. Остаток ждёт следующего сбора.
    amount = min(bank, collect_cap(user))
    # Мяуконы от друзей не идут в рейтинг «Игроки» — там только свой заработок (для друзей есть свой рейтинг).
    db.execute(update(User).where(User.tg_id == user.tg_id)
               .values(ref_bank=User.ref_bank - amount, coins=User.coins + amount, ref_collect_at=now)
               .execution_options(synchronize_session=False))
    db.commit()
    db.refresh(user)
    return {**state(user, now), "friends": friends_view(db, user, now, name),
            "collected": amount / CENTS}
