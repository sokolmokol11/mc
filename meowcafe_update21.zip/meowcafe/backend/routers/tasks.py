"""
Шаг 7: задания.
  GET  /api/tasks          — ежедневный вход, спонсоры, квесты
  POST /api/tasks/daily    — забрать награду за сегодня
  POST /api/tasks/claim    — забрать награду квеста: {"id": "q_box10"}
  POST /api/tasks/sponsor  — проверить подписку и забрать награду: {"channel": "@канал"}
"""
import asyncio

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

import quests as qs
import tg_api
from config import CENTS, DAILY_REWARDS, SPONSOR_REWARD, SPONSORS
from db import get_db
from deps import telegram_data
from models import BoxOpening, User, UserTask, utcnow
from routers.boxes import give_box
from routers.player import get_user, income_of, state

router = APIRouter(prefix="/api/tasks", tags=["tasks"])


class ClaimRequest(BaseModel):
    id: str


class SponsorRequest(BaseModel):
    channel: str


def claimed_ids(db: Session, user_id: int) -> set[str]:
    return set(db.scalars(select(UserTask.task_id).where(UserTask.user_id == user_id)))


def boxes_opened(db: Session, user_id: int) -> int:
    return db.scalar(select(func.count()).select_from(BoxOpening).where(BoxOpening.user_id == user_id)) or 0


def channel_url(channel: str) -> str:
    return f"https://t.me/{channel.lstrip('@')}" if channel.startswith("@") else channel


def tasks_view(db: Session, user: User, now) -> dict:
    inc = income_of(user)
    claimed = claimed_ids(db, user.tg_id)
    today = qs.day_index(now)
    day, done_today = qs.daily_next(user.daily_streak or 0, user.daily_last_day or 0, today)
    daily = {
        "day": day, "claimed_today": done_today, "next_in": qs.seconds_to_next_day(now),
        "rewards": [qs.scaled_reward(inc, coins) / CENTS for coins, _box in DAILY_REWARDS],
        "boxes": [qs.box_name(box) for _coins, box in DAILY_REWARDS],
    }
    sponsors = [{"channel": ch, "title": title, "url": channel_url(ch),
                 "reward": qs.scaled_reward(inc, SPONSOR_REWARD) / CENTS,
                 "done": f"sp_{ch}" in claimed} for ch, title in SPONSORS]
    friends_active = db.scalar(select(func.count()).select_from(User)
                               .where(User.referrer_id == user.tg_id, User.is_active_ref.is_(True))) or 0
    quests = qs.quests_view(qs.progress_values(user, boxes_opened(db, user.tg_id), friends_active), claimed, inc)
    ready = (0 if done_today else 1) + sum(q["status"] == "ready" for q in quests) \
        + sum(not s["done"] for s in sponsors)
    return {"daily": daily, "sponsors": sponsors, "quests": quests, "ready": ready}


def give(db: Session, user: User, task_id: str, reward: int) -> None:
    """Записать награду. Повторный запрос (двойной тап) упрётся в первичный ключ и ничего не начислит."""
    db.add(UserTask(user_id=user.tg_id, task_id=task_id, reward=reward, claimed_at=utcnow()))
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Награда уже получена")
    user.coins += reward
    user.coins_earned_season += reward


@router.get("")
def get_tasks(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    return {**state(user, now), "tasks": tasks_view(db, user, now)}


@router.post("/daily")
def claim_daily(tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    today = qs.day_index(now)
    day, done_today = qs.daily_next(user.daily_streak or 0, user.daily_last_day or 0, today)
    if done_today:
        raise HTTPException(status_code=400, detail="Сегодня награда уже получена")
    # Ключ с номером дня: два одновременных запроса не дадут награду дважды.
    coins_rule, box = DAILY_REWARDS[day - 1]
    reward = qs.scaled_reward(income_of(user), coins_rule)
    give(db, user, f"d_{today}", reward)
    user.daily_streak, user.daily_last_day = day, today
    results = give_box(db, user, box, now)
    db.commit()
    return {**state(user, now), "tasks": tasks_view(db, user, now), "reward": reward / CENTS, "day": day,
            "results": results, "box_name": qs.box_name(box)}


@router.post("/claim")
def claim_quest(req: ClaimRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if req.id not in qs.QUEST_IDS:
        raise HTTPException(status_code=400, detail="Нет такого задания")
    user = get_user(db, tg)
    now = utcnow()
    quest = next(q for q in tasks_view(db, user, now)["quests"] if q["id"] == req.id)
    if quest["status"] == "claimed":
        raise HTTPException(status_code=400, detail="Награда уже получена")
    if quest["status"] != "ready":
        raise HTTPException(status_code=400, detail="Задание ещё не выполнено")
    reward = int(round(quest["reward"] * CENTS))
    give(db, user, req.id, reward)
    results = give_box(db, user, quest["box"], now)
    db.commit()
    return {**state(user, now), "tasks": tasks_view(db, user, now), "reward": reward / CENTS,
            "results": results, "box_name": quest["box_name"]}


@router.post("/sponsor")
def claim_sponsor(req: SponsorRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    if req.channel not in {ch for ch, _ in SPONSORS}:
        raise HTTPException(status_code=400, detail="Нет такого канала")
    uid = tg["user"]["id"]
    if f"sp_{req.channel}" in claimed_ids(db, uid):
        raise HTTPException(status_code=400, detail="Награда уже получена")
    try:   # спрашиваем Telegram ДО блокировки игрока: сеть может думать несколько секунд
        ok = asyncio.run(tg_api.is_subscribed(req.channel, uid))
    except tg_api.TelegramError as e:
        print(f"[sponsor] {req.channel}: {e}")  # чаще всего: бот не админ канала
        raise HTTPException(status_code=503, detail="Не получилось проверить подписку, попробуй позже")
    if not ok:
        raise HTTPException(status_code=400, detail="Подписка не найдена — подпишись и проверь ещё раз")
    user = get_user(db, tg)
    now = utcnow()
    reward = qs.scaled_reward(income_of(user), SPONSOR_REWARD)
    give(db, user, f"sp_{req.channel}", reward)
    db.commit()
    return {**state(user, now), "tasks": tasks_view(db, user, now), "reward": reward / CENTS}
