"""
Шаг 4: живая комната.
  POST /api/guests/serve  — обслужить гостя с заказом: {"key": "w123456"}
  POST /api/cats/barista  — поставить кота за стойку: {"cat_id": 8}
Гулять, перетаскивать котов и обычных гостей рисует фронт — на экономику это не влияет.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

import economy as eco
from config import BOT_TOKEN, CENTS, GUEST_REWARD_SEC
from db import get_db
from deps import telegram_data
from models import utcnow
from routers.player import get_user, income_of, state

router = APIRouter(prefix="/api", tags=["cafe"])


class ServeRequest(BaseModel):
    key: str


class BaristaRequest(BaseModel):
    cat_id: int


@router.post("/guests/serve")
def serve_guest(req: ServeRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    now = utcnow()
    w = eco.guest_window(now)

    # Заказ должен быть текущим, существующим и ещё не обслуженным.
    if req.key != f"w{w}":
        raise HTTPException(status_code=400, detail="Гость уже ушёл")
    if w <= (user.last_served_window or 0):
        raise HTTPException(status_code=400, detail="Этого гостя ты уже обслужил")
    want = eco.guest_order(user.tg_id, w, BOT_TOKEN)
    if want is None:
        raise HTTPException(status_code=400, detail="Сейчас нет гостя с заказом")

    best = max((eco.cat_rarity(c.cat_id) for c in user.cats if c.location == 0), default=-1)
    if best < want:
        raise HTTPException(status_code=400, detail="Нужен кот этой редкости или выше")

    reward = int(income_of(user) * GUEST_REWARD_SEC[want] * CENTS)
    user.coins += reward
    user.coins_earned_season += reward
    user.last_served_window = w
    user.guests_served = (user.guests_served or 0) + 1
    db.commit()
    return {**state(user, now), "reward": reward / CENTS}


@router.post("/cats/barista")
def set_barista(req: BaristaRequest, tg: dict = Depends(telegram_data), db: Session = Depends(get_db)):
    user = get_user(db, tg)
    if not any(c.cat_id == req.cat_id and c.location == 0 for c in user.cats):
        raise HTTPException(status_code=400, detail="За стойку можно поставить только кота из кафе")
    user.barista_cat_id = req.cat_id
    db.commit()
    return state(user, utcnow())
