// Звук MeowCafe: эффекты синтезируются кодом (Web Audio), музыка — файлы из папки music (см. ниже).
//   Snd.music(true|false), Snd.sfx(true|false) — включить/выключить (запоминается)
//   Snd.scene("game"|"cafe") — переключить музыку на мини-игру и обратно
//   Snd.play("coin" | "meow" | "purr" | "charge" | "burst" | "catch" | "rock" | "click" | "upgrade" | "reward", арг)
// Браузер разрешает звук только после первого касания экрана — поэтому всё стартует на первом pointerdown.
(function (root) {
  let ctx = null, master = null, musicBus = null, sfxBus = null, started = false, ambientOn = false;
  const store = {
    get(k, d) { try { const v = localStorage.getItem("mc_" + k); return v === null ? d : v === "1"; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem("mc_" + k, v ? "1" : "0"); } catch (e) {} },
  };
  let musicOn = store.get("music", true), sfxOn = store.get("sfx", true);

  function ensure() {
    if (ctx) { if (ctx.state === "suspended") ctx.resume(); return true; }
    const AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.9;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 4;
    master.connect(comp); comp.connect(ctx.destination);
    musicBus = ctx.createGain(); musicBus.gain.value = musicOn ? 0.55 : 0; musicBus.connect(master);
    sfxBus = ctx.createGain(); sfxBus.gain.value = sfxOn ? 0.7 : 0; sfxBus.connect(master);
    return true;
  }
  let tOff = 0;                                   // сдвиг времени — только для демо-записи
  const now = () => ctx.currentTime + tOff;
  const midi = (n) => 440 * Math.pow(2, (n - 69) / 12);

  // ---------- кирпичики ----------
  let noiseBuf = null;
  function noise() {
    if (!noiseBuf) {
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0;                       // «розовый» шум — мягче белого, как дождь
      for (let i = 0; i < d.length; i++) {
        const w = Math.random() * 2 - 1;
        b0 = 0.99765 * b0 + w * 0.099; b1 = 0.963 * b1 + w * 0.2965; b2 = 0.57 * b2 + w * 1.0526;
        d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.18;
      }
    }
    const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true; return s;
  }
  function env(g, t, a, peak, d, sustain = 0) {
    g.gain.cancelScheduledValues(t);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0001, sustain), t + a + d);
  }
  function tone(freq, t, dur, { type = "sine", vol = 0.3, a = 0.005, bus = sfxBus, glideTo = null, detune = 0 } = {}) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t); o.detune.value = detune;
    if (glideTo) o.frequency.exponentialRampToValueAtTime(glideTo, t + dur);
    env(g, t, a, vol, dur);
    o.connect(g); g.connect(bus); o.start(t); o.stop(t + a + dur + 0.05);
    return o;
  }

  // ---------- музыка кафе: весёлый лаунж-джаз 104 BPM + гомон посетителей ----------
  // Гармония I–vi–ii–V (Cmaj7 → Am7 → Dm7 → G7), по такту на аккорд. Мелодия — короткие мотивы,
  // которые повторяются с вариациями, поэтому запоминаются, но не надоедают.
  const BPM = 104, STEP = 60 / BPM / 4;                  // шестнадцатая
  const CHORDS = [[48, 52, 55, 59], [45, 48, 52, 55], [50, 53, 57, 60], [43, 47, 50, 53]];
  const BASS = [[36, 43, 40, 43], [33, 40, 36, 40], [38, 45, 41, 45], [31, 38, 35, 38]];
  const SCALE = [72, 74, 76, 79, 81, 84, 86, 88];       // до-мажорная пентатоника: весело и без фальши
  let step = 0, nextStepAt = 0, timer = null, crowd = null, motif = [];
  function newMotif() {             // 8 нот на 2 такта: [шаг 0..31, нота] — ритм «вопрос-ответ»
    const rhythm = [[0, 3, 6, 8, 10, 14], [0, 2, 4, 8, 11, 12, 14], [2, 4, 6, 10, 12]][Math.floor(Math.random() * 3)];
    let idx = 2 + Math.floor(Math.random() * 3);
    motif = rhythm.map(st => { idx = Math.max(0, Math.min(SCALE.length - 1, idx + [-2, -1, 1, 1, 2][Math.floor(Math.random() * 5)])); return [st, SCALE[idx]]; });
  }
  function kick(t) { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(130, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.14); env(g, t, 0.003, 0.5, 0.18); o.connect(g); g.connect(musicBus); o.start(t); o.stop(t + 0.25); }
  function hit(t, f, q, vol, dur, type = "bandpass") {   // шумовые: хэт, щелчок, шейкер
    const n = noise(), fl = ctx.createBiquadFilter(), g = ctx.createGain();
    fl.type = type; fl.frequency.value = f; fl.Q.value = q; env(g, t, 0.002, vol, dur);
    n.connect(fl); fl.connect(g); g.connect(musicBus); n.start(t, Math.random()); n.stop(t + dur + 0.05);
  }
  function ep(notes, t, dur, vol = 0.06) {                // электропиано: синус + «колокольчик» сверху
    for (const m of notes) { tone(midi(m), t, dur, { type: "sine", vol, a: 0.004, bus: musicBus }); tone(midi(m) * 3, t, dur * 0.35, { type: "sine", vol: vol * 0.18, a: 0.002, bus: musicBus }); }
  }
  function marimba(m, t, vol = 0.11) { tone(midi(m), t, 0.32, { type: "sine", vol, a: 0.002, bus: musicBus }); tone(midi(m) * 4, t, 0.06, { type: "sine", vol: vol * 0.3, a: 0.001, bus: musicBus }); }
  function clink(t) {            // звон чашки на фоне
    const f = 2400 + Math.random() * 1400;
    tone(f, t, 0.25, { type: "sine", vol: 0.03, a: 0.001, bus: musicBus }); tone(f * 1.51, t, 0.18, { type: "sine", vol: 0.015, a: 0.001, bus: musicBus });
  }
  function startCrowd() {        // гомон посетителей: шум через «гласные» фильтры, громкость гуляет
    const out = ctx.createGain(); out.gain.value = 0.11; out.connect(musicBus);
    const nodes = [];
    for (const f of [420, 900, 1500, 2600]) {
      const n = noise(), bp = ctx.createBiquadFilter(), g = ctx.createGain(), lfo = ctx.createOscillator(), lg = ctx.createGain();
      bp.type = "bandpass"; bp.frequency.value = f; bp.Q.value = 6; g.gain.value = 0.5;
      lfo.frequency.value = 0.6 + Math.random() * 2.2; lg.gain.value = 0.45; lfo.connect(lg); lg.connect(g.gain);
      n.connect(bp); bp.connect(g); g.connect(out); n.start(0, Math.random()); lfo.start(); nodes.push(n, lfo);
    }
    return nodes;
  }
  function scheduleStep(i, t) {
    const sw = (i % 2 === 1) ? STEP * 0.18 : 0;            // свинг: каждая вторая шестнадцатая чуть позже
    const tt = t + sw, bar = Math.floor(i / 16), s16 = i % 16, ch = bar % 4;
    if (s16 === 0 && bar % 2 === 0) newMotif();
    // ударные
    if (s16 === 0 || s16 === 8 || (s16 === 10 && bar % 2)) kick(tt);
    if (s16 === 4 || s16 === 12) { hit(tt, 1800, 0.8, 0.12, 0.09); hit(tt, 5000, 1, 0.05, 0.05); }
    if (s16 % 2 === 0) hit(tt, 8500, 1.2, s16 % 4 === 2 ? 0.07 : 0.035, 0.03, "highpass");
    if (s16 % 4 === 3) hit(tt, 6000, 2, 0.025, 0.06);
    // бас: «прыгающий», на каждую четверть
    if (s16 % 4 === 0) tone(midi(BASS[ch][s16 / 4]), tt, 0.28, { type: "triangle", vol: 0.2, a: 0.004, bus: musicBus });
    if (s16 === 14 && Math.random() < 0.5) tone(midi(BASS[(ch + 1) % 4][0] + 1), tt, 0.12, { type: "triangle", vol: 0.12, a: 0.004, bus: musicBus });
    // аккорды: короткие «стабы» на слабые доли — пружинят
    if (s16 === 2 || s16 === 10) ep(CHORDS[ch].map(n => n + 12), tt, 0.3);
    if (s16 === 7 && Math.random() < 0.5) ep(CHORDS[ch].slice(1).map(n => n + 12), tt, 0.18, 0.04);
    // мелодия: мотив на 2 такта; каждые 4 такта — пауза-«ответ» гармонии
    if (bar % 8 < 6) for (const [st, m] of motif) if (st === s16) marimba(bar % 2 ? m - 5 : m, tt);   // нечётный такт — «ответ» ниже
    // кафе вокруг
    if (s16 === 0 && Math.random() < 0.35) clink(t + Math.random() * 1.5);
  }
  // Фоновая музыка — настоящие треки из папки frontend/music:
  //   кафе:      cafe.mp3, cafe2.mp3 … cafe6.mp3 — играют по очереди вперемешку (сколько положишь, столько и будет)
  //   мини-игра: game.mp3 — включается на время Десертопада, потом снова кафе с того же места
  // Каких-то файлов нет — они просто пропускаются. Нет game.mp3 — в игре продолжает играть кафе.
  const CH = {
    cafe: { list: ["music/cafe.mp3", "music/cafe2.mp3", "music/cafe3.mp3", "music/cafe4.mp3", "music/cafe5.mp3", "music/cafe6.mp3"], vol: 0.35 },
    game: { list: ["music/game.mp3"], vol: 0.42 },
  };
  let scene = "cafe", track = null;   // track — элемент, который сейчас должен звучать
  function pick(c) {
    if (!c.list.length) return null;
    if (!c.cur) return c.list[0];
    const other = c.list.filter((u) => u !== c.cur);
    return other.length ? other[Math.floor(Math.random() * other.length)] : c.cur;
  }
  function want() { return !ambientOn ? null : scene === "game" && CH.game.list.length ? CH.game : CH.cafe.list.length ? CH.cafe : null; }
  function load(c, url) {
    if (!c.el) {
      c.el = new Audio(); c.el.preload = "auto"; c.el.volume = 0;
      c.el.addEventListener("ended", () => { const n = pick(c); if (n) { load(c, n); if (want() === c) c.el.play().catch(() => {}); } });
      c.el.addEventListener("error", () => {      // файла нет — выкидываем из списка и берём следующий
        c.list = c.list.filter((u) => u !== c.cur); c.cur = null;
        const n = pick(c);
        if (n) load(c, n);
        refresh();
      });
    }
    c.cur = url; c.el.src = url;
  }
  function fadeEl(el, v) {
    clearInterval(el._fade);
    if (v > 0 && el.paused) el.play().catch(() => {});
    el._fade = setInterval(() => {
      const d = v - el.volume;
      if (Math.abs(d) < 0.02) { el.volume = v; clearInterval(el._fade); if (v === 0) el.pause(); return; }
      el.volume = Math.max(0, Math.min(1, el.volume + Math.sign(d) * 0.02));
    }, 40);
  }
  function refresh() {
    const w = want();
    for (const c of Object.values(CH)) {
      if (c === w) {
        if (!c.el || !c.cur) load(c, pick(c));
        c.el.play().then(() => fadeEl(c.el, c.vol)).catch(() => {});
      } else if (c.el) fadeEl(c.el, 0);
    }
    track = w ? w.el : null;
  }
  function startAmbient() { if (ambientOn || typeof Audio === "undefined") return; ambientOn = true; refresh(); }
  function stopAmbient() { ambientOn = false; refresh(); }
  function setScene(name) {
    if (name === scene) return;
    scene = name;
    if (name === "game" && CH.game.el && CH.game.list.length) { try { CH.game.el.currentTime = 0; } catch (e) {} }
    refresh();
  }
  const PENTA = SCALE;

  // ---------- звуки ----------
  const SFX = {
    click() { tone(1400, now(), 0.04, { type: "triangle", vol: 0.08 }); },
    coin() {
      const t = now();
      [0, 0.07, 0.14].forEach((d, i) => { tone(midi(88 + i * 3), t + d, 0.25, { type: "square", vol: 0.05 }); tone(midi(100 + i * 3), t + d, 0.18, { type: "sine", vol: 0.08 }); });
    },
    reward() { const t = now(); [72, 76, 79, 84].forEach((m, i) => tone(midi(m), t + i * 0.08, 0.35, { type: "triangle", vol: 0.12 })); },
    upgrade() { const t = now(); tone(midi(60), t, 0.5, { type: "sawtooth", vol: 0.06, glideTo: midi(84) }); tone(midi(84), t + 0.45, 0.4, { type: "sine", vol: 0.12 }); },
    meow() {          // «мяу»: пила через полосовой фильтр, тон вверх-вниз
      const t = now(), o = ctx.createOscillator(), bp = ctx.createBiquadFilter(), g = ctx.createGain();
      o.type = "sawtooth";
      const base = 520 + Math.random() * 200;
      o.frequency.setValueAtTime(base, t); o.frequency.linearRampToValueAtTime(base * 1.45, t + 0.12); o.frequency.exponentialRampToValueAtTime(base * 0.8, t + 0.42);
      bp.type = "bandpass"; bp.Q.value = 4; bp.frequency.setValueAtTime(900, t); bp.frequency.linearRampToValueAtTime(1800, t + 0.15); bp.frequency.linearRampToValueAtTime(1000, t + 0.42);
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.32, t + 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.48);
      o.connect(bp); bp.connect(g); g.connect(sfxBus); o.start(t); o.stop(t + 0.5);
    },
    purr() {          // мурчание: низкий шум, пульсирующий 24 раза в секунду
      const t = now(), n = noise(), lp = ctx.createBiquadFilter(), g = ctx.createGain(), am = ctx.createOscillator(), amg = ctx.createGain();
      lp.type = "lowpass"; lp.frequency.value = 300;
      am.frequency.value = 24; amg.gain.value = 0.25; am.connect(amg); amg.connect(g.gain);
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.35, t + 0.15); g.gain.linearRampToValueAtTime(0.0001, t + 1.1);
      n.connect(lp); lp.connect(g); g.connect(sfxBus); n.start(t); am.start(t); n.stop(t + 1.2); am.stop(t + 1.2);
    },
    charge(step = 0) {       // коробка заряжается: каждый шаг выше
      const t = now(), m = 48 + step * 5;
      tone(midi(m), t, 0.35, { type: "sawtooth", vol: 0.06, glideTo: midi(m + 4) });
      tone(midi(m + 24), t, 0.25, { type: "sine", vol: 0.05 + step * 0.02 });
    },
    burst(rarity = 0) {      // взрыв света + аккорд; у легендарок и мификов — длиннее и ярче
      const t = now(), n = noise(), hp = ctx.createBiquadFilter(), g = ctx.createGain();
      hp.type = "highpass"; hp.frequency.setValueAtTime(800, t); hp.frequency.exponentialRampToValueAtTime(6000, t + 0.6);
      g.gain.setValueAtTime(0.4, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.8);
      n.connect(hp); hp.connect(g); g.connect(sfxBus); n.start(t); n.stop(t + 0.9);
      tone(55, t, 0.5, { type: "sine", vol: 0.4, glideTo: 30 });
      const chord = rarity >= 4 ? [72, 76, 79, 83, 86, 91] : rarity >= 3 ? [72, 76, 79, 84, 88] : rarity >= 2 ? [69, 72, 76, 81] : [72, 76, 79];
      chord.forEach((m, i) => { tone(midi(m), t + 0.05 + i * 0.06, rarity >= 3 ? 2.2 : 1.1, { type: "triangle", vol: 0.09 }); tone(midi(m) * 2, t + 0.05 + i * 0.06, 0.8, { type: "sine", vol: 0.03 }); });
      if (rarity >= 3) for (let i = 0; i < 10; i++) tone(midi(PENTA[i % PENTA.length] + 12), t + 0.4 + i * 0.07, 0.3, { type: "sine", vol: 0.05 });
    },
    catch(pts = 1) { const t = now(); tone(midi(79 + Math.min(pts, 5) * 2), t, 0.12, { type: "triangle", vol: 0.12, glideTo: midi(91) }); },
    rock() { const t = now(); tone(120, t, 0.25, { type: "square", vol: 0.12, glideTo: 50 }); },
  };

  function play(name, arg) {
    if (!sfxOn || !started || !ctx || !SFX[name]) return;
    try { SFX[name](arg); } catch (e) {}
  }
  function music(on) {
    musicOn = on; store.set("music", on);
    if (!started) return;
    if (on) startAmbient(); else stopAmbient();
  }
  function sfx(on) {
    sfxOn = on; store.set("sfx", on);
    if (ctx) sfxBus.gain.setTargetAtTime(on ? 0.7 : 0, now(), 0.05);
  }
  function start() {
    if (started) { if (ctx && ctx.state === "suspended") ctx.resume(); return; }
    if (!ensure()) return;
    started = true;
    if (musicOn) startAmbient();
  }
  if (typeof document !== "undefined") {
    document.addEventListener("pointerdown", start, { capture: true });
    // свернули Telegram — тишина, вернулись — звук обратно
    document.addEventListener("visibilitychange", () => {
      if (ctx) { if (document.hidden) ctx.suspend(); else ctx.resume(); }
      if (track && ambientOn) { if (document.hidden) track.pause(); else track.play().catch(() => {}); }
    });
  }
  // Демо-запись в WAV (для проверки звука без телефона): Snd._demo(25).then(base64)
  async function demo(secs = 25) {
    const saved = [ctx, master, musicBus, sfxBus, noiseBuf, ambientOn, sfxOn, musicOn];
    ctx = new OfflineAudioContext(2, 44100 * secs, 44100); noiseBuf = null;
    master = ctx.createGain(); master.gain.value = 0.9;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 4;
    master.connect(comp); comp.connect(ctx.destination);
    musicBus = ctx.createGain(); musicBus.gain.value = 0.55; musicBus.connect(master);
    sfxBus = ctx.createGain(); sfxBus.gain.value = 0.7; sfxBus.connect(master);
    startCrowd();
    for (let i = 0, t = 0.1; t < secs; i++, t += STEP) scheduleStep(i, t);
    const at = (t, f) => { tOff = t; f(); tOff = 0; };
    at(3, () => SFX.coin()); at(5, () => SFX.meow()); at(6.5, () => SFX.purr());
    [0, 1, 2, 3, 4].forEach(k => at(9 + k * 0.52, () => SFX.charge(k))); at(11.8, () => SFX.burst(4));
    [15, 15.35, 15.7].forEach((t, k) => at(t, () => SFX.catch(k + 1))); at(16.1, () => SFX.rock()); at(18, () => SFX.reward()); at(19.5, () => SFX.upgrade());
    const buf = await ctx.startRendering();
    [ctx, master, musicBus, sfxBus, noiseBuf, ambientOn, sfxOn, musicOn] = saved;
    // WAV 16 бит
    const L = buf.getChannelData(0), R = buf.getChannelData(1), len = L.length, out = new DataView(new ArrayBuffer(44 + len * 4));
    const str = (o, t) => { for (let i = 0; i < t.length; i++) out.setUint8(o + i, t.charCodeAt(i)); };
    str(0, "RIFF"); out.setUint32(4, 36 + len * 4, true); str(8, "WAVEfmt "); out.setUint32(16, 16, true); out.setUint16(20, 1, true); out.setUint16(22, 2, true);
    out.setUint32(24, 44100, true); out.setUint32(28, 44100 * 4, true); out.setUint16(32, 4, true); out.setUint16(34, 16, true); str(36, "data"); out.setUint32(40, len * 4, true);
    for (let i = 0; i < len; i++) { out.setInt16(44 + i * 4, Math.max(-1, Math.min(1, L[i])) * 32767, true); out.setInt16(46 + i * 4, Math.max(-1, Math.min(1, R[i])) * 32767, true); }
    let bin = ""; const u8 = new Uint8Array(out.buffer); for (let i = 0; i < u8.length; i += 32768) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 32768));
    return btoa(bin);
  }
  root.Snd = { _demo: demo, play, music, sfx, scene: setScene, get musicOn() { return musicOn; }, get sfxOn() { return sfxOn; }, stopAmbient };
})(typeof window !== "undefined" ? window : globalThis);
